// ─── ASSISTANT IA ───────────────────────────────────────────────
var AI_MESSAGES = [];
var AI_LOADING = false;


// ═══════════════════════════════════════════════════════════════
// ONBOARDING — premier lancement (4 étapes)
// ═══════════════════════════════════════════════════════════════
var APP_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MTIiIGhlaWdodD0iNTEyIiB2aWV3Qm94PSIwIDAgNTEyIDUxMiI+CjxkZWZzPjxyYWRpYWxHcmFkaWVudCBpZD0iZyIgY3g9IjUwJSIgY3k9IjM4JSIgcj0iNjUlIj4KPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iIzJGM0E2MCIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iIzBFMTMyMiIvPjwvcmFkaWFsR3JhZGllbnQ+CjxsaW5lYXJHcmFkaWVudCBpZD0iZ29sZCIgeDE9IjAiIHkxPSIwIiB4Mj0iMSIgeTI9IjEiPgo8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjRUZENzlBIi8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdG9wLWNvbG9yPSIjQzlBMjRCIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+CjxyZWN0IHdpZHRoPSI1MTIiIGhlaWdodD0iNTEyIiByeD0iMTE2IiBmaWxsPSJ1cmwoI2cpIi8+CjxwYXRoIGQ9Ik0zMjggMTY4YTExMiAxMTIgMCAxIDAgMCAxNzYgODggODggMCAxIDEgMC0xNzZ6IiBmaWxsPSJ1cmwoI2dvbGQpIi8+CjxwYXRoIGQ9Ik0zNTYgMTk2bDEzIDM0IDM2IDMtMjcgMjQgOCAzNS0zMC0xOS0zMCAxOSA4LTM1LTI3LTI0IDM2LTN6IiBmaWxsPSJ1cmwoI2dvbGQpIi8+Cjwvc3ZnPg==';
var OB_STEP = 0;

function obNext() {
  if (OB_STEP === 2) {
    var nEl = document.getElementById('OB_NAME');
    if (nEl) { S.profil.nom = nEl.value.trim(); save(); }
  }
  if (OB_STEP === 3) {
    var cEl = document.getElementById('OB_CITY');
    if (cEl && cEl.value.trim()) { S.profil.salatCity = cEl.value.trim(); save(); }
    finishOnboarding();
    return;
  }
  OB_STEP++;
  render();
}
function obSkip() { finishOnboarding(); }
function obSetGenre(g) {
  S.profil.genre = g;
  if (!S.profil.theme) S.profil.theme = (g === 'femme') ? 'rose' : 'emeraude';
  save(); OB_STEP = 2; render();
}

function finishOnboarding() {
  S.profil.onboarded = true;
  save();
  if (S.profil.salatCity) { try { fetchSalat(); } catch(e) {} }
  S.page = 'accueil';
  render();
}

function installPWA() {
  var dp = window.deferredPrompt;
  if (dp) {
    dp.prompt();
    dp.userChoice.then(function(){ window.deferredPrompt = null; render(); });
  } else if (window.isIOS) {
    S.profil.showIOSInstall = !S.profil.showIOSInstall;
    render();
  } else {
    toast('Menu du navigateur → « Installer l\'application »');
  }
}

function pageOnboarding() {
  var dots = '<div style="display:flex;gap:7px;justify-content:center;margin:18px 0 0">'
    + [0,1,2,3].map(function(i){
        return '<div style="width:'+(i===OB_STEP?'22':'7')+'px;height:7px;border-radius:4px;background:'+(i===OB_STEP?gold():(i<OB_STEP?hexA(gold(),.5):br()))+';transition:all .3s"></div>';
      }).join('')
    + '</div>';

  var body;
  if (OB_STEP === 0) {
    body = '<div style="text-align:center;animation:fadeUp .5s">'
      + '<div style="width:96px;height:96px;margin:0 auto 22px;position:relative">'
        + '<div style="position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle at 50% 35%,#D9C26A,#7A6A1E);box-shadow:0 8px 40px rgba(138,107,29,.45)"></div>'
        + '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center"><span style="font-size:44px;color:#FFFDF0;text-shadow:0 2px 6px rgba(26,58,42,.4)">☾</span></div>'
      + '</div>'
      + '<p style="font-size:34px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-bottom:4px">Nûraya</p>'
      + '<p style="font-size:20px;font-family:Fraunces,Georgia,serif;color:'+gold()+';direction:rtl;margin-bottom:14px">نورايا</p>'
      + '<p style="font-size:18px;color:'+tx2()+';line-height:1.7;max-width:300px;margin:0 auto">Ta lumière au quotidien.<br>Le Coran, le tafsir d\'Ibn Kathir, tes prières et tes routines — réunis dans un espace pensé pour toi.</p>'
    + '</div>';
  } else if (OB_STEP === 1) {
    body = '<div style="text-align:center;animation:fadeUp .4s">'
      + '<p style="font-size:30px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-bottom:6px">Bienvenue 🌙</p>'
      + '<p style="font-size:18px;color:'+tx2()+';line-height:1.6;margin-bottom:26px">Pour adapter l\'expérience, dis-nous qui tu es.</p>'
      + '<div style="display:flex;flex-direction:column;gap:12px;max-width:300px;margin:0 auto">'
        + [['femme','🌸','Femme'],['homme','🤲','Homme']].map(function(g){
            return '<button onclick="obSetGenre(\''+g[0]+'\')" style="display:flex;align-items:center;gap:14px;padding:16px 20px;border-radius:16px;border:1.5px solid '+br()+';background:'+bg2()+';cursor:pointer;font-family:inherit;transition:all .2s">'
              + '<span style="font-size:30px">'+g[1]+'</span>'
              + '<span style="font-size:20px;font-weight:600;color:'+tx()+';flex:1;text-align:left">'+g[2]+'</span>'
              + '<span style="font-size:18px;color:'+gold()+'">›</span>'
            + '</button>';
          }).join('')
      + '</div>';
  } else if (OB_STEP === 2) {
    body = '<div style="text-align:center;animation:fadeUp .4s">'
      + '<p style="font-size:46px;margin-bottom:10px">✨</p>'
      + '<p style="font-size:30px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-bottom:6px">Comment t\'appelles-tu ?</p>'
      + '<p style="font-size:18px;color:'+tx2()+';line-height:1.6;margin-bottom:24px">Pour t\'accueillir chaque jour par ton prénom.</p>'
      + '<input id="OB_NAME" value="'+esc(S.profil.nom||'')+'" placeholder="Ton prénom" autocomplete="given-name" style="width:100%;max-width:300px;padding:14px 16px;border-radius:14px;border:1.5px solid '+br()+';background:'+bg2()+';color:'+tx()+';font-size:19px;text-align:center;font-family:inherit;box-sizing:border-box">'
    + '</div>';
  } else {
    body = '<div style="text-align:center;animation:fadeUp .4s">'
      + '<p style="font-size:46px;margin-bottom:10px">🕌</p>'
      + '<p style="font-size:30px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-bottom:6px">Tes horaires de prière</p>'
      + '<p style="font-size:18px;color:'+tx2()+';line-height:1.6;margin-bottom:24px">Indique ta ville pour voir la prochaine salât dès l\'accueil. Tu pourras changer plus tard.</p>'
      + '<input id="OB_CITY" value="'+esc(S.profil.salatCity||'')+'" placeholder="Ville, Pays (ex. Bangi, Malaysia)" style="width:100%;max-width:320px;padding:14px 16px;border-radius:14px;border:1.5px solid '+br()+';background:'+bg2()+';color:'+tx()+';font-size:18px;text-align:center;font-family:inherit;box-sizing:border-box">'
      + '<p style="font-size:15px;color:'+tx2()+';opacity:.7;margin-top:10px">Laisse vide pour utiliser ta position GPS</p>'
    + '</div>';
  }

  var lastBtn = OB_STEP === 3 ? 'Commencer 🌙' : (OB_STEP === 0 ? 'Découvrir' : 'Continuer');
  var showNext = OB_STEP !== 1; // l'étape genre avance via les boutons eux-mêmes

  return '<div style="min-height:100%;display:flex;flex-direction:column;padding:calc(env(safe-area-inset-top,0px) + 20px) 24px calc(env(safe-area-inset-bottom,0px) + 20px);background:'+bg()+'">'
    + '<div style="display:flex;justify-content:flex-end">'
      + (OB_STEP < 3 ? '<button onclick="obSkip()" style="background:none;border:none;color:'+tx2()+';font-size:17px;cursor:pointer;font-family:inherit;padding:6px">Passer</button>' : '<div style="height:30px"></div>')
    + '</div>'
    + '<div style="flex:1;display:flex;align-items:center;justify-content:center">'+body+'</div>'
    + dots
    + (showNext
        ? '<button class="btn-gold" onclick="obNext()" style="width:100%;max-width:340px;margin:18px auto 0;padding:15px;border-radius:16px;border:none;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');color:#FFFDF0;font-size:18px;font-weight:700;cursor:pointer;font-family:inherit;box-shadow:0 5px 18px rgba(138,107,29,.35);min-height:52px">'+lastBtn+'</button>'
        : '<div style="height:70px"></div>')
  + '</div>';
}

// ═══════════════════════════════════════════════════════════════
// QIBLA — direction de la Kaaba (Makkah : 21.4225, 39.8262)
// Calcul du grand cercle + boussole live (capteur d'orientation)
// ═══════════════════════════════════════════════════════════════
var KAABA = { lat: 21.4225, lng: 39.8262 };
var QIBLA_HEADING = null; // cap boussole de l'appareil

function qiblaBearing(lat, lng) {
  var toR = Math.PI / 180, toD = 180 / Math.PI;
  var dLng = (KAABA.lng - lng) * toR;
  var y = Math.sin(dLng) * Math.cos(KAABA.lat * toR);
  var x = Math.cos(lat * toR) * Math.sin(KAABA.lat * toR)
        - Math.sin(lat * toR) * Math.cos(KAABA.lat * toR) * Math.cos(dLng);
  var b = Math.atan2(y, x) * toD;
  return (b + 360) % 360;
}

function qiblaResolveCoords(cb) {
  // 1. Coordonnées déjà mémorisées (depuis la salât)
  if (S.profil.qiblaLat != null && S.profil.qiblaLng != null) {
    cb(S.profil.qiblaLat, S.profil.qiblaLng); return;
  }
  // 2. GPS
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(pos) {
      S.profil.qiblaLat = pos.coords.latitude;
      S.profil.qiblaLng = pos.coords.longitude;
      save();
      cb(pos.coords.latitude, pos.coords.longitude);
    }, function() { cb(null, null); }, { timeout: 8000 });
  } else { cb(null, null); }
}

function qiblaHandler(e) {
  var h = (e.webkitCompassHeading != null) ? e.webkitCompassHeading
        : (e.alpha != null ? 360 - e.alpha : null);
  if (h != null) {
    QIBLA_HEADING = h;
    var needle = document.getElementById('QIBLA_DIAL');
    var arrow  = document.getElementById('QIBLA_ARROW');
    if (needle) needle.style.transform = 'rotate(' + (-h) + 'deg)';
    if (arrow && S.profil.qiblaBearing != null) {
      var rel = (S.profil.qiblaBearing - h + 360) % 360;
      arrow.style.transform = 'rotate(' + rel + 'deg)';
      var aligned = Math.min(rel, 360 - rel) < 6;
      arrow.style.filter = aligned ? 'drop-shadow(0 0 10px '+hexA(gold(),.9)+')' : 'none';
      var lbl = document.getElementById('QIBLA_ALIGN');
      if (lbl) lbl.style.opacity = aligned ? '1' : '0';
    }
  }
}

function qiblaNeedsPermission() {
  return typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function';
}

function attachCompass() {
  // addEventListener déduplique une même fonction nommée : pas de double abonnement
  window.addEventListener('deviceorientationabsolute', qiblaHandler, true);
  window.addEventListener('deviceorientation', qiblaHandler, true);
  S.qiblaCompassOn = true;
}

// Appelé UNIQUEMENT depuis un tap (geste utilisateur) — obligatoire pour l'autorisation iOS
function enableCompass() {
  if (qiblaNeedsPermission()) {
    DeviceOrientationEvent.requestPermission().then(function(p) {
      if (p === 'granted') { attachCompass(); render(); }
      else { S.qiblaPermDenied = true; render(); toast('Boussole refusée — Réglages › Safari › Mouvement et orientation'); }
    }).catch(function(){ toast('Impossible d\'activer la boussole'); });
  } else {
    attachCompass();
    render();
  }
}

function initQibla() {
  var go = function() {
    // Sur les appareils sans demande d'autorisation (Android, etc.), on branche directement.
    // Sur iOS, on attend le tap sur « Activer la boussole » (geste requis).
    if (!qiblaNeedsPermission() && !S.qiblaCompassOn) attachCompass();
  };
  if (S.profil.qiblaBearing != null) { go(); return; }
  qiblaResolveCoords(function(lat, lng) {
    if (lat == null) { S.qiblaError = true; render(); return; }
    S.profil.qiblaBearing = qiblaBearing(lat, lng);
    save();
    render();
    go();
  });
}

function pageQibla() {
  var b = S.profil.qiblaBearing;
  var dial = (function() {
    if (b == null && S.qiblaError) {
      return '<div style="text-align:center;padding:30px 10px"><p style="font-size:46px;margin-bottom:10px">🧭</p>'
        + '<p style="font-size:18px;color:'+tx2()+';line-height:1.6;max-width:280px;margin:0 auto 16px">Active ta position pour calculer la direction de la Kaaba.</p>'
        + '<button class="btn-gold" onclick="S.qiblaError=false;S.profil.qiblaLat=null;S.profil.qiblaLng=null;initQibla()" style="padding:12px 22px;border-radius:13px;border:none;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');color:#FFFDF0;font-size:16px;font-weight:700;cursor:pointer;font-family:inherit">Réessayer</button></div>';
    }
    if (b == null) {
      return '<div style="text-align:center;padding:40px 10px"><div style="width:30px;height:30px;border-radius:15px;border:3px solid '+hexA(gold(),.25)+';border-top-color:'+gold()+';animation:spin 1s linear infinite;margin:0 auto 14px"></div><p style="font-size:17px;color:'+tx2()+'">Calcul de la direction…</p></div>';
    }
    return '<div style="text-align:center;padding:8px 10px 18px">'
      // Cadran
      + '<div style="position:relative;width:250px;height:250px;margin:0 auto">'
        + '<div id="QIBLA_DIAL" style="position:absolute;inset:0;border-radius:50%;border:2px solid '+br()+';background:'+bg2()+';transition:transform .12s linear">'
          + ['N','E','S','O'].map(function(d,i){
              return '<span style="position:absolute;left:50%;top:8px;transform:translateX(-50%) rotate('+(i*90)+'deg);transform-origin:50% 117px;font-size:17px;font-weight:700;color:'+(i===0?gold():tx2())+'">'+d+'</span>';
            }).join('')
        + '</div>'
        // Flèche Qibla (tourne vers la Kaaba relativement au cap)
        + '<div id="QIBLA_ARROW" style="position:absolute;inset:0;display:flex;align-items:flex-start;justify-content:center;transition:transform .12s linear,filter .2s">'
          + '<div style="display:flex;flex-direction:column;align-items:center;margin-top:18px">'
            + '<span style="font-size:30px">🕋</span>'
            + '<div style="width:0;height:0;border-left:9px solid transparent;border-right:9px solid transparent;border-bottom:74px solid '+gold()+';margin-top:2px;opacity:.9"></div>'
          + '</div>'
        + '</div>'
        // Centre
        + '<div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:16px;height:16px;border-radius:8px;background:'+gold()+';box-shadow:0 0 0 4px '+bg()+'"></div>'
      + '</div>'
      + '<p id="QIBLA_ALIGN" style="font-size:18px;font-weight:700;color:'+gold()+';margin-top:14px;opacity:0;transition:opacity .3s">✓ Tu fais face à la Qibla</p>'
      + '<p style="font-size:34px;font-weight:300;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-top:6px">'+Math.round(b)+'°</p>'
      + '<p style="font-size:16px;color:'+tx2()+'">depuis le Nord géographique</p>'
      + (!S.qiblaCompassOn
          ? '<button onclick="enableCompass()" style="margin-top:14px;padding:12px 22px;border-radius:13px;border:none;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');color:#FFFDF0;font-size:16px;font-weight:700;cursor:pointer;font-family:inherit">🧭 Activer la boussole</button>'
            + (S.qiblaPermDenied ? '<p style="font-size:14px;color:#E57373;margin-top:8px;line-height:1.5">Autorisation refusée. Sur iPhone : Réglages › Safari › Mouvement &amp; orientation, puis réessaie.</p>' : '<p style="font-size:13px;color:'+tx2()+';opacity:.7;margin-top:8px">Touche le bouton pour orienter la flèche en direct.</p>')
          : '')
    + '</div>';
  })();

  return '<div style="padding:12px 16px 24px">'
    + card(dial)
    + card(
        '<p style="font-size:16px;color:'+tx2()+';line-height:1.7">📱 Tiens ton téléphone à plat et tourne-toi jusqu\'à ce que la flèche 🕋 pointe vers le haut. Le repère devient lumineux quand tu es aligné·e.</p>'
        + '<p style="font-size:14px;color:'+tx2()+';opacity:.7;margin-top:7px">La boussole dépend du magnétomètre de ton appareil — éloigne-toi des objets métalliques. En cas de doute, vérifie avec ta mosquée.</p>'
      )
  + '</div>';
}

