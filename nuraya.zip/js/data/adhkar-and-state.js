// ═══════════════════════════════════════════════════════════════
// DHIKR DU MATIN ET DU SOIR COMPLETS
// ═══════════════════════════════════════════════════════════════

var ADHKAR_SABAH = [
  {
    titre: "Ayat al-Kursî",
    ar: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ",
    fr: "Allah ! Point de divinité à part Lui, le Vivant, Celui qui subsiste par Lui-même. Ni somnolence ni sommeil ne Le saisissent...",
    ref: "Al-Baqara 2:255",
    rep: 1,
    bienfait: "Celui qui la récite le matin est protégé jusqu'au soir. [Al-Bukhâri]"
  },
  {
    titre: "Al-Ikhlâs + Al-Falaq + An-Nâs",
    ar: "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ",
    fr: "Dis : Il est Allah Unique. Allah le Maître absolu. Il n'a pas engendré et n'a pas été engendré. Et nul n'est égal à Lui.",
    ref: "Al-Ikhlâs, Al-Falaq, An-Nâs",
    rep: 3,
    bienfait: "Réciter 3x le matin et le soir suffit pour tout. [Abu Dawud 5082]"
  },
  {
    titre: "Sayyid al-Istighfar",
    ar: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ خَلَقْتَنِي وَأَنَا عَبْدُكَ وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
    fr: "Ô Allah, Tu es mon Seigneur. Il n'y a de divinité que Toi. Tu m'as créé et je suis Ton serviteur. Je suis sur Ton pacte et Ta promesse autant que je le peux. Je cherche refuge en Toi contre le mal de ce que j'ai fait. Je reconnais Tes bienfaits sur moi et je reconnais mon péché. Pardonne-moi car nul ne pardonne les péchés que Toi.",
    ref: "Al-Bukhâri 6306",
    rep: 1,
    bienfait: "Quiconque le dit le matin avec certitude et meurt avant le soir est parmi les gens du Paradis. [Al-Bukhâri]"
  },
  {
    titre: "Du'a de protection",
    ar: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
    fr: "Au nom d'Allah avec lequel rien ne nuit sur terre ni dans le ciel. Et Il est l'Audient, l'Omniscient.",
    ref: "Abu Dawud 5088, At-Tirmidhi 3388",
    rep: 3,
    bienfait: "Rien ne lui nuira. [Abu Dawud]"
  },
  {
    titre: "Ridha bil Islam",
    ar: "رَضِيتُ بِاللَّهِ رَبًّا وَبِالْإِسْلَامِ دِينًا وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا",
    fr: "Je me satisfais d'Allah comme Seigneur, de l'Islam comme religion et de Muhammad ﷺ comme prophète.",
    ref: "Abu Dawud 5072, At-Tirmidhi 3389",
    rep: 3,
    bienfait: "Allah est garant de lui plaire. [Abu Dawud]"
  },
  {
    titre: "Subhânallah wa bihamdihi",
    ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    fr: "Gloire à Allah et louange à Lui.",
    ref: "Al-Bukhâri 6405",
    rep: 100,
    bienfait: "Ses péchés sont effacés même s'ils sont comme l'écume de la mer. [Al-Bukhâri]"
  },
  {
    titre: "Lâ ilâha illa Llâh",
    ar: "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
    fr: "Il n'y a de divinité qu'Allah Seul, sans associé. À Lui la royauté et la louange. Et Il est omnipotent.",
    ref: "Al-Bukhâri 3293",
    rep: 10,
    bienfait: "Équivaut à affranchir 10 esclaves, 100 bonnes actions et effacement de 100 mauvaises. [Al-Bukhâri]"
  },
  {
    titre: "Du'a du matin",
    ar: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ وَالْحَمْدُ لِلَّهِ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
    fr: "Nous voici au matin et le Royaume appartient à Allah. Louange à Allah. Il n'y a de divinité qu'Allah Seul sans associé.",
    ref: "Muslim 2723",
    rep: 1,
    bienfait: "Sunna du matin du Prophète ﷺ."
  },
];

var ADHKAR_MASAA = [
  {
    titre: "Ayat al-Kursî",
    ar: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ",
    fr: "Allah ! Point de divinité à part Lui, le Vivant, Celui qui subsiste par Lui-même. Ni somnolence ni sommeil...",
    ref: "Al-Baqara 2:255",
    rep: 1,
    bienfait: "Protégé jusqu'au matin. [Al-Bukhâri]"
  },
  {
    titre: "Du'a du soir",
    ar: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ وَالْحَمْدُ لِلَّهِ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
    fr: "Nous voici au soir et le Royaume appartient à Allah. Louange à Allah. Il n'y a de divinité qu'Allah Seul sans associé.",
    ref: "Muslim 2723",
    rep: 1,
    bienfait: "Sunna du soir du Prophète ﷺ."
  },
  {
    titre: "Sayyid al-Istighfar",
    ar: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ خَلَقْتَنِي وَأَنَا عَبْدُكَ",
    fr: "Ô Allah, Tu es mon Seigneur. Il n'y a de divinité que Toi. Tu m'as créé et je suis Ton serviteur...",
    ref: "Al-Bukhâri 6306",
    rep: 1,
    bienfait: "Quiconque le dit le soir et meurt dans la nuit est parmi les gens du Paradis."
  },
  {
    titre: "Protection de la famille",
    ar: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
    fr: "Je cherche refuge dans les Paroles parfaites d'Allah contre le mal de ce qu'Il a créé.",
    ref: "Muslim 2709",
    rep: 3,
    bienfait: "Rien ne lui nuira jusqu'au matin. [Muslim]"
  },
  {
    titre: "Al-Ikhlâs + Al-Falaq + An-Nâs",
    ar: "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ قُلْ أَعُوذُ بِرَبِّ النَّاسِ",
    fr: "Al-Ikhlâs, Al-Falaq et An-Nâs.",
    ref: "Abu Dawud 5082",
    rep: 3,
    bienfait: "Suffit pour tout le soir. [Abu Dawud]"
  },
  {
    titre: "Subhânallah wa bihamdihi",
    ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    fr: "Gloire à Allah et louange à Lui.",
    ref: "Al-Bukhâri 6405",
    rep: 100,
    bienfait: "Effacement des péchés comme l'écume de la mer."
  },
  {
    titre: "Du'a avant de dormir",
    ar: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
    fr: "En Ton nom, ô Allah, je meurs et je vis.",
    ref: "Al-Bukhâri 6324",
    rep: 1,
    bienfait: "Sunna avant le sommeil."
  },
  {
    titre: "Tasbih avant le sommeil",
    ar: "سُبْحَانَ اللَّهِ ۝ الْحَمْدُ لِلَّهِ ۝ اللَّهُ أَكْبَرُ",
    fr: "Soubhânallah (33x) · Alhamdulillah (33x) · Allahu Akbar (34x)",
    ref: "Al-Bukhâri 5362",
    rep: 1,
    bienfait: "Meilleur qu'un serviteur pour la fatigue. [Al-Bukhâri]"
  },
];








// Coran complet



// ═══════════════════════════════════════════════════════════════
// NÛRAYA — Core JS
// Architecture : état global → render() → innerHTML
// Toutes les fonctions sont sur window (accessibles depuis onclick)
// ═══════════════════════════════════════════════════════════════

// ─── ÉTAT GLOBAL ────────────────────────────────────────────────
var S = {
  page: 'accueil',
  dark: false,
  // Coran
  quranSurah: null,
  quranVerses: [],
  quranLoading: false,
  quranSearch: '',
  quranFont: 1, // 0=S 1=M 2=L
  quranMode: 'both', // 'arabic' | 'both'
  quranReciter: 'Alafasy_128kbps',
  quranMemory: {}, // {num: 'todo'|'learning'|'learned'}
  quranBookmarks: {}, // {num: verseNum}
  quranAudio: null,
  quranAudioVerse: null,
  quranCtxOpen: null,
  ikOpen: null,      // "surah:verse" du panneau Ibn Kathir ouvert
  ikLang: 'en',      // 'en' (abrégé) | 'ar' (original)
  ikCache: {},       // cache session des tafsirs API
  ikLoading: null,   // "surah:verse" en cours de chargement
  femmeTab: 'cycle',
  tarbiyaTab: 'intro',
  hifzTab: 'plan',
  hifzPlan: 'regulier',
  adhkarTab: 'sabah',
  adhkarIdx: 0,
  adhkarMode: null,
  adhkarDone: {},
  cachedSurahs: {},
  // Dhikr
  dhikrIdx: 0,
  dhikrCount: 0,
  dhikrTotal: 0,
  dhikrTab: 'counter',
  dhikrHistory: [],
  // Routine
  routineDots: [false,false,false,false,false,false,false,false,false,false],
  streak: 0,
  // Zakât
  zakatTab: 'def',
  // Ilm
  aqidaCours: null,
  tawhidTab: 'intro',
  siraTab: 'physique',
  propheteIdx: null,
  asmaIdx: null,
  // Profil
  profil: { nom: '', madhhab: 'Maliki' },
  // PIN / RGPD
  locked: true,
  pinEntry: '',
  pinError: '',
  consentGiven: false,
};

// ─── CONSTANTES ─────────────────────────────────────────────────
var SAVE_KEY = 'nuraya_v1_data';
var PIN_KEY  = 'nuraya_v1_pin';
var CONS_KEY = 'nuraya_v1_consent';
var SALT     = 'nuraya2025';
var SUPPORT_EMAIL  = 'ndaououmoupro@gmail.com';
var NURAYA_VERSION = 'v29';

var TAB_MAP = {
  accueil:'accueil', niyya:'accueil',
  coran:'coran',
  ai:'nur',
  profil:'profil',
  // 📖 Apprendre
  apprendre:'apprendre', aqida:'apprendre', tawhid:'apprendre', sira:'apprendre',
  prophetes:'apprendre', asma:'apprendre', cours:'apprendre', hifz:'apprendre', tarbiya:'apprendre',
  // 🕌 Adorer
  adorer:'adorer', salat:'adorer', qibla:'adorer', dhikr:'adorer', adhkar:'adorer', hajj:'adorer', zakat:'adorer',
  // 🌿 Mon quotidien
  quotidien:'quotidien', routine:'quotidien', planning:'quotidien', sunnafood:'quotidien',
  foyer:'quotidien', orga:'quotidien', femme:'quotidien'
};

var PILLS = {
  coran: [['coran','📖 Coran']],
};

