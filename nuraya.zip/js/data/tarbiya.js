// ─── 3. DONNÉES ÉDUCATION ISLAMIQUE ────────────────────────────
var TARBIYA_DATA = {
  intro: "La tarbiya islamique est une obligation parentale. Le Prophète ﷺ a dit : 'Chaque enfant naît dans la fitra. Ce sont ses parents qui en font un juif, un chrétien ou un mage.' [Bukhâri & Muslim]",
  verset_cle: { ar: "يَا أَيُّهَا الَّذِينَ آمَنُوا قُوا أَنفُسَكُمْ وَأَهْلِيكُمْ نَارًا", fr: "Ô les croyants ! Préservez-vous et préservez vos familles d'un Feu.", ref: "At-Tahrim 66:6" },
  naissance: [
    { etape: "À la naissance", sunna: "Adhan dans l'oreille droite", detail: "Dire l'appel à la prière dans l'oreille droite du nouveau-né. C'est la première parole qu'il entend : l'unicité d'Allah. [Abu Dawud, At-Tirmidhi]" },
    { etape: "À la naissance", sunna: "Iqama dans l'oreille gauche", detail: "Dire l'iqama dans l'oreille gauche. [At-Tirmidhi — avis des savants]" },
    { etape: "J-7", sunna: "Tahnik", detail: "Frotter du dattes mâchées sur le palais du nouveau-né. Si pas de dattes, quelque chose de sucré. Le Prophète ﷺ fit le tahnik des enfants de ses Compagnons. [Bukhâri & Muslim]" },
    { etape: "J-7", sunna: "Nomination", detail: "Choisir un beau prénom islamique. Les plus aimés d'Allah : Abdullah et Abdurrahman. [Muslim 2132] Éviter les prénoms des idoles ou aux significations négatives." },
    { etape: "J-7", sunna: "Rasage de la tête", detail: "Raser les cheveux du nouveau-né. Donner en sadaqa l'équivalent en argent du poids des cheveux. [Al-Muwatta]" },
    { etape: "J-7", sunna: "Aqiqa", detail: "Sacrifier 2 moutons pour un garçon, 1 pour une fille. Si impossible le J-7, le J-14 ou J-21. C'est une sunnah mu'akkada (fortement recommandée). [Tirmidhi 1522]" },
    { etape: "Circoncision (garçon)", sunna: "Khitan", detail: "Sunnah pour les garçons, obligatoire selon la majorité. Idéalement avant la puberté. Fait partie de la fitra (nature islamique). [Bukhâri & Muslim]" },
  ],
  education_par_age: [
    { age: "0-3 ans", titre: "La fitra — les fondations", points: [
      "Environnement islamique : Bismillah, Alhamdulillah dans la routine quotidienne",
      "Récitation du Coran autour de l'enfant — il absorbe les sons",
      "Du'a avant de le nourrir, de le coucher, de le laver",
      "L'enfant apprend par imitation — être soi-même le modèle",
      "Tendresse et amour : 'Allah est miséricordieux envers ceux qui sont miséricordieux' [Bukhâri]"
    ]},
    { age: "3-7 ans", titre: "L'éveil — planter les graines", points: [
      "Enseigner les courtes sourates (Al-Fatiha, Al-Ikhlas, Al-Falaq, An-Nas)",
      "Apprendre les du'as quotidiens (manger, dormir, sortir de chez soi...)",
      "Raconter les histoires des prophètes — de façon simple et vivante",
      "Apprendre les 5 piliers de l'Islam de façon ludique",
      "L'introduire à la prière en le mettant à côté de toi — sans obligation",
      "'Commandez à vos enfants de prier à 7 ans.' [Abu Dawud]"
    ]},
    { age: "7-10 ans", titre: "L'apprentissage — la prière et le Coran", points: [
      "Ordonner la prière à 7 ans — avec douceur et exemple",
      "Mémorisation systématique du Coran — commencer par le Juz 30",
      "Apprendre les règles de la prière (wudu, mouvements, récitations)",
      "Initiation au jeûne progressif (quelques heures, puis une journée)",
      "Histoire de l'Islam et vie du Prophète ﷺ plus en détail",
      "Distinguer halal et haram dans la vie quotidienne"
    ]},
    { age: "10-12 ans", titre: "La responsabilité — vers la maturité", points: [
      "Frappe légère si l'enfant abandonne la prière à 10 ans [Abu Dawud]",
      "Jeûne de Ramadan progressivement",
      "Apprendre les règles de la pureté (avant la puberté)",
      "Séparer les lits frères/sœurs [Abu Dawud]",
      "Conversations ouvertes sur la foi et les questions religieuses",
      "Renforcer la mémorisation du Coran avant la puberté"
    ]},
    { age: "Puberté et après", titre: "La responsabilité religieuse complète — Taklif", points: [
      "L'enfant devient mukallaf (responsable devant Allah)",
      "Toutes les obligations islamiques s'appliquent pleinement",
      "Renforcer l'identité islamique contre les influences extérieures",
      "Accompagner, ne pas imposer — la guidance vient d'Allah",
      "'Il n'y a pas de contrainte en religion' — mais l'éducation précoce est une grâce"
    ]},
  ],
  hadiths_tarbiya: [
    { texte: "Chaque enfant naît dans la fitra. Ce sont ses parents qui en font un juif, un chrétien ou un mage. Tout comme l'animal naît avec tous ses membres — y vois-tu un manque ?", src: "Al-Bukhâri & Muslim" },
    { texte: "Ordonnez à vos enfants de prier à sept ans, et frappez-les légèrement [s'ils ne prient pas] à dix ans, et séparez-les dans leurs lits.", src: "Abu Dawud 495 — Hadith hassan" },
    { texte: "L'homme est le gardien de sa famille et il est responsable de ses protégés.", src: "Al-Bukhâri 893" },
    { texte: "Lorsqu'un homme meurt, ses actions s'arrêtent sauf trois : une sadaqa jariya, une connaissance dont on bénéficie, ou un enfant pieux qui prie pour lui.", src: "Muslim 1631" },
    { texte: "Honorez vos enfants et améliorez leur éducation.", src: "Ibn Majah 3671" },
    { texte: "Aucun père n'a offert à son fils un meilleur cadeau que de bonnes manières.", src: "At-Tirmidhi 1952" },
  ],
  arabic_learning: [
    { titre: "Pourquoi apprendre l'arabe ?", desc: "L'arabe est la langue du Coran. Allah dit : 'Nous l'avons révélé en arabe afin que vous compreniez.' [Yûsuf 12:2]. Ibn Taymiya : 'L'arabe est une partie de la religion.'", emoji: "📖" },
    { titre: "Par où commencer pour son enfant", desc: "1. L'alphabet (alif ba ta) dès 3-4 ans avec des chansons. 2. Les mots du Coran les plus fréquents. 3. Noms d'Allah et leur sens. 4. Vocabulaire des prières et adhkar. 5. Lecture du Coran avec Tajwid.", emoji: "🔤" },
    { titre: "Méthodes recommandées", desc: "Noorani Qaida pour la lecture. Méthode Bilal pour les enfants. Application Arabee avec dessins. Chansons islamiques en arabe. Parler arabe à la maison même quelques phrases simples.", emoji: "🎵" },
    { titre: "La mémorisation du Coran pour l'enfant", desc: "Le meilleur âge : 4-12 ans (mémoire la plus vive). Commencer par Al-Fatiha + Juz 30. 15-20 minutes par jour suffit. Révision constante avant nouvelles sourates. Le Prophète ﷺ : 'Celui qui récite le Coran et agit selon lui, ses parents seront couronnés d'une lumière.' [Abu Dawud]", emoji: "🌟" },
  ],
};

// ─── 4. PLANNING MÉMORISATION CORAN ────────────────────────────
var HIFZ_PLANS = [
  { id: 'debutant', label: 'Débutante', desc: '1 sourate/semaine', verses_per_day: 3 },
  { id: 'regulier', label: 'Régulière', desc: '1 page/semaine', verses_per_day: 5 },
  { id: 'intensif', label: 'Intensive', desc: '1 page/2-3 jours', verses_per_day: 10 },
  { id: 'hafidha', label: 'Hafidha', desc: '1 hizb/semaine', verses_per_day: 20 },
];

// Ordre recommandé pour la mémorisation (du plus facile au plus difficile)
var HIFZ_ORDER = [
  // Juz 30 d'abord (les plus courtes)
  112,113,114,103,108,110,111,105,106,107,102,104,
  99,100,101,97,98,95,96,93,94,91,92,89,90,87,88,
  85,86,83,84,81,82,79,80,77,78,75,76,73,74,
  // Puis sourates moyennes importantes
  67,55,36,97,18,56,
  // Puis sourates plus longues
  1,2,3,
];

function getHifzPlan() {
  var plan = S.hifzPlan || 'regulier';
  var p = HIFZ_PLANS.find(function(x) { return x.id === plan; });
  var completed = S.quranMemory || {};
  var learned = Object.keys(completed).filter(function(k) { return completed[k] === 'learned'; }).map(Number);
  var remaining = HIFZ_ORDER.filter(function(n) { return learned.indexOf(n) === -1; });
  
  // Générer les 4 prochaines semaines
  var weeks = [];
  var idx = 0;
  for (var w = 0; w < 4; w++) {
    var weekSurahs = [];
    var verses = 0;
    while (idx < remaining.length) {
      var n = remaining[idx];
      var s = SURAHS.find(function(x) { return x.n === n; });
      if (!s) { idx++; continue; }
      verses += s.v;
      weekSurahs.push(n);
      idx++;
      if (verses >= p.verses_per_day * 7) break;
    }
    if (weekSurahs.length > 0) {
      weeks.push({ week: w + 1, surahs: weekSurahs, verses: verses });
    }
  }
  return { plan: p, learned: learned.length, total: 114, weeks: weeks };
}

// ─── PAGES NOUVELLES ────────────────────────────────────────────

// Page Espace Femme
// ═══════════════════════════════════════════════════════════════
// SUIVI DU CYCLE (Hayd) — privé, sur l'appareil
// Approche fiqh : pendant les règles la prière est LEVÉE (non due,
// pas à rattraper) ; le jeûne du Ramadan est à rattraper.
// Données conservées localement uniquement.
// ═══════════════════════════════════════════════════════════════
function cycleData() {
  if (!S.profil.cycle) S.profil.cycle = { periods: [], avgCycle: 28, avgPeriod: 6 };
  return S.profil.cycle;
}
function ymd(d) { return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
function parseYmd(s) { var p = s.split('-'); return new Date(+p[0], +p[1]-1, +p[2]); }
function daysBetween(a, b) { return Math.round((parseYmd(b) - parseYmd(a)) / 86400000); }

// periods = [{start:'YYYY-MM-DD', end:'YYYY-MM-DD'|null}]  (end null = en cours)
function currentPeriod() {
  var c = cycleData();
  var last = c.periods[c.periods.length - 1];
  return (last && !last.end) ? last : null;
}
function recalcAverages() {
  var c = cycleData();
  var done = c.periods.filter(function(p){ return p.end; });
  if (done.length >= 1) {
    var sum = 0, k = 0;
    done.forEach(function(p){ sum += daysBetween(p.start, p.end) + 1; k++; });
    c.avgPeriod = Math.max(3, Math.min(10, Math.round(sum / k)));
  }
  if (c.periods.length >= 2) {
    var gaps = 0, g = 0;
    for (var i = 1; i < c.periods.length; i++) {
      var d = daysBetween(c.periods[i-1].start, c.periods[i].start);
      if (d > 15 && d < 45) { gaps += d; g++; }
    }
    if (g) c.avgCycle = Math.round(gaps / g);
  }
}
function startPeriod() {
  haptic('light');
  var c = cycleData();
  if (currentPeriod()) return;
  c.periods.push({ start: ymd(new Date()), end: null });
  save(); render();
  toast('Début enregistré — tes prières sont levées 🌸');
}
function endPeriod() {
  haptic('success');
  var p = currentPeriod();
  if (!p) return;
  p.end = ymd(new Date());
  recalcAverages();
  save();
  toast('Fin enregistrée — pense au ghusl avant de reprendre la prière 🚿');
  render();
}
function predictNext() {
  var c = cycleData();
  if (!c.periods.length) return null;
  var last = c.periods[c.periods.length - 1];
  var base = parseYmd(last.start);
  base.setDate(base.getDate() + (c.avgCycle || 28));
  return base;
}

// Statut spirituel du jour
function cycleStatusToday() {
  var p = currentPeriod();
  if (p) {
    var dn = daysBetween(p.start, ymd(new Date())) + 1;
    return { state:'hayd', day:dn, label:'Jour '+dn+' des règles' };
  }
  return { state:'pure', label:'Période de pureté (tuhr)' };
}

function cycleDots() {
  // 6 derniers mois de marqueurs simples
  var c = cycleData();
  var marks = {};
  c.periods.forEach(function(p){
    var s = parseYmd(p.start);
    var e = p.end ? parseYmd(p.end) : new Date();
    for (var d = new Date(s); d <= e; d.setDate(d.getDate()+1)) marks[ymd(d)] = 'hayd';
  });
  return marks;
}

function pageCycleTracker() {
  var c = cycleData();
  var st = cycleStatusToday();
  var p = currentPeriod();
  var next = predictNext();
  var marks = cycleDots();

  // Mini-calendrier : 5 semaines glissantes centrées sur aujourd'hui
  var today = new Date(); today.setHours(0,0,0,0);
  var start = new Date(today); start.setDate(start.getDate() - 27 - today.getDay());
  var cal = '<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-top:8px">';
  ['D','L','M','M','J','V','S'].forEach(function(d){ cal += '<div style="text-align:center;font-size:13px;color:'+tx2()+';font-weight:700">'+d+'</div>'; });
  for (var i = 0; i < 35; i++) {
    var day = new Date(start); day.setDate(start.getDate() + i);
    var key = ymd(day);
    var isHayd = marks[key] === 'hayd';
    var isToday = key === ymd(today);
    var isPredict = next && Math.abs(daysBetween(key, ymd(next))) === 0;
    var isFuture = day > today;
    var bgc = isHayd ? '#E57373' : (isPredict ? 'rgba(229,115,115,.25)' : 'transparent');
    var col = isHayd ? '#fff' : (isFuture ? tx2() : tx());
    cal += '<div style="aspect-ratio:1;display:flex;align-items:center;justify-content:center;border-radius:9px;font-size:14px;background:'+bgc
      + ';color:'+col+';'+(isToday?'border:2px solid '+gold()+';font-weight:700':'border:1px solid '+(isHayd?'transparent':br()))
      + ';opacity:'+(isFuture && !isPredict ? '.55' : '1')+'">'+day.getDate()+'</div>';
  }
  cal += '</div>';

  return '<div style="padding:4px 0">'
    // Statut du jour
    + '<div style="background:'+(st.state==='hayd'?'linear-gradient(150deg,#C25B6B,#8E3F4C)':'linear-gradient(150deg,'+activeTheme().grad[0]+','+activeTheme().grad[1]+')')+';border-radius:18px;padding:18px;text-align:center;margin-bottom:12px">'
      + '<p style="font-size:38px">'+(st.state==='hayd'?'🌸':'🌿')+'</p>'
      + '<p style="font-size:21px;font-weight:700;color:#fff;margin-top:2px">'+esc(st.label)+'</p>'
      + (st.state==='hayd'
          ? '<p style="font-size:16px;color:rgba(255,255,255,.85);margin-top:4px">Tes prières sont levées. Continue le dhikr, l\'écoute du Coran et les invocations.</p>'
          : (next ? '<p style="font-size:16px;color:rgba(231,239,223,.8);margin-top:4px">Prochaines règles estimées le '+next.toLocaleDateString('fr-FR',{day:'numeric',month:'long'})+'</p>' : '<p style="font-size:16px;color:rgba(231,239,223,.8);margin-top:4px">Enregistre ton premier cycle pour activer les prédictions.</p>'))
    + '</div>'
    // Bouton principal
    + (p
        ? '<button onclick="endPeriod()" style="width:100%;padding:14px;border-radius:14px;border:none;background:linear-gradient(150deg,#81C784,#4CAF50);color:#fff;font-size:17px;font-weight:700;cursor:pointer;font-family:inherit;margin-bottom:10px;min-height:50px">✓ Marquer la fin des règles</button>'
        : '<button onclick="startPeriod()" style="width:100%;padding:14px;border-radius:14px;border:none;background:linear-gradient(150deg,#E57373,#C25B6B);color:#fff;font-size:17px;font-weight:700;cursor:pointer;font-family:inherit;margin-bottom:10px;min-height:50px">🌸 Marquer le début des règles</button>')
    // Calendrier
    + card('<p style="font-size:15px;font-weight:700;color:'+gold()+';letter-spacing:.06em;text-transform:uppercase;margin-bottom:2px">📅 Mon calendrier</p>'+cal
        + '<div style="display:flex;gap:14px;justify-content:center;margin-top:9px;font-size:13px;color:'+tx2()+'"><span><span style="display:inline-block;width:10px;height:10px;border-radius:5px;background:#E57373;vertical-align:middle"></span> Règles</span><span><span style="display:inline-block;width:10px;height:10px;border-radius:5px;background:rgba(229,115,115,.25);vertical-align:middle"></span> Prévu</span></div>')
    // Statistiques
    + (c.periods.length
        ? card('<p style="font-size:15px;font-weight:700;color:'+gold()+';letter-spacing:.06em;text-transform:uppercase;margin-bottom:7px">📊 Mes moyennes</p>'
            + '<div style="display:flex;gap:8px">'
              + '<div style="flex:1;text-align:center;padding:9px;border-radius:11px;background:'+(S.dark?hexA(gold(),.06):'rgba(122,106,30,.05)')+'"><p style="font-size:26px;font-weight:700;color:'+gold()+'">'+(c.avgCycle||28)+'</p><p style="font-size:13px;color:'+tx2()+'">jours de cycle</p></div>'
              + '<div style="flex:1;text-align:center;padding:9px;border-radius:11px;background:'+(S.dark?hexA(gold(),.06):'rgba(122,106,30,.05)')+'"><p style="font-size:26px;font-weight:700;color:'+gold()+'">'+(c.avgPeriod||6)+'</p><p style="font-size:13px;color:'+tx2()+'">jours de règles</p></div>'
              + '<div style="flex:1;text-align:center;padding:9px;border-radius:11px;background:'+(S.dark?hexA(gold(),.06):'rgba(122,106,30,.05)')+'"><p style="font-size:26px;font-weight:700;color:'+gold()+'">'+c.periods.length+'</p><p style="font-size:13px;color:'+tx2()+'">cycles suivis</p></div>'
            + '</div>'
            + '<p style="font-size:13px;color:'+tx2()+';opacity:.7;margin-top:8px;text-align:center">Plus tu enregistres, plus les prédictions s\'affinent.</p>')
        : '')
    // Rappel spirituel pendant hayd
    + (st.state==='hayd'
        ? card('<p style="font-size:15px;font-weight:700;color:'+gold()+';letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">🌿 Adoration pendant les règles</p>'
            + ['📿 Dhikr et tasbîh à volonté','🤲 Toutes les invocations (du\'â)','🎧 Écoute du Coran et des rappels','💚 Lecture du Coran sans le toucher directement (selon avis)','🍽️ Si Ramadan : tu ne jeûnes pas, les jours sont à rattraper après'].map(function(x){
                return '<p style="font-size:16px;color:'+tx()+';line-height:1.85">'+x+'</p>';
              }).join(''))
        : '')
    // Du'â adaptée au moment
    + (st.state==='hayd'
        ? card('<p style="font-size:15px;font-weight:700;color:'+gold()+';letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">🤲 Du\'â du moment</p>'
            + '<p style="font-size:22px;font-family:Fraunces,Georgia,serif;direction:rtl;text-align:right;line-height:2;color:'+tx()+'">اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَافِيَةَ</p>'
            + '<p style="font-size:16px;color:'+tx2()+';margin-top:4px;font-style:italic">Allâhumma innî as\'aluka l-\'âfiya — Ô Allah, je Te demande la santé et le bien-être.</p>')
        : card('<p style="font-size:15px;font-weight:700;color:'+gold()+';letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">🤲 Du\'â de reconnaissance</p>'
            + '<p style="font-size:22px;font-family:Fraunces,Georgia,serif;direction:rtl;text-align:right;line-height:2;color:'+tx()+'">الْحَمْدُ لِلَّهِ الَّذِي بِنِعْمَتِهِ تَتِمُّ الصَّالِحَات</p>'
            + '<p style="font-size:16px;color:'+tx2()+';margin-top:4px;font-style:italic">Al-hamdu lillâhi lladhî bi-ni\'matihi tatimmu s-sâlihât — Louange à Allah par la grâce de qui s\'accomplissent les bonnes œuvres.</p>'))
    // Bien-être physique
    + (st.state==='hayd'
        ? card('<p style="font-size:15px;font-weight:700;color:'+gold()+';letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">🌿 Bien-être & douceur</p>'
            + ['💧 Hydrate-toi bien et repose-toi sans culpabilité','🌡️ Chaleur sur le bas-ventre pour apaiser les crampes','🍵 Tisanes douces (gingembre, camomille)','🌴 Les dattes et le miel, recommandés dans la Sunna pour la force','😌 Sois indulgente avec toi-même : la fatigue est normale'].map(function(x){
                return '<p style="font-size:16px;color:'+tx()+';line-height:1.85">'+x+'</p>';
              }).join(''))
        : '')
    // Rappel ghusl à la fin
    + (st.state==='pure' && c.periods.length
        ? gcard('<p style="font-size:16px;color:'+tx()+';line-height:1.7">🚿 <b>Rappel :</b> la prière reprend après le <b>ghusl</b> (grand lavage rituel). Si des prières ont commencé pendant un jour de pureté avant les règles, seules celles-là étaient dues.</p>')
        : '')
    // Confidentialité
    + '<p style="text-align:center;font-size:13px;color:'+tx2()+';opacity:.7;margin-top:10px;line-height:1.6">🔒 Tes données de cycle restent uniquement sur ton appareil.<br>Pour les cas particuliers (istihâda, cycles irréguliers), consulte une savante de confiance.</p>'
  + '</div>';
}

function pageFemme() {
  var tabs = [['suivi','🌸 Suivi'],['cycle','Fiqh cycle'],['parure','Parure'],['grossesse','Grossesse'],['duas','Du\'as'],['modeles','Modèles']];
  var content = '';
  var t = S.femmeTab || 'suivi';
  var bullets = function(arr){ return arr.map(function(i){ return '<p style="font-size:18px;color:'+tx2()+';line-height:1.7;padding-left:8px">• '+esc(i)+'</p>'; }).join(''); };

  if (t === 'suivi') {
    content = pageCycleTracker();
  } else if (t === 'cycle') {
    var d = FEMME_DATA.cycle;
    content = '<p style="font-size:19px;color:'+tx()+';line-height:1.75;margin-bottom:10px">'+esc(d.intro)+'</p>'

    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">🔴 '+esc(d.haid.titre)+'</p>'
    + card('<p style="font-size:18px;color:'+tx()+';line-height:1.75">'+esc(d.haid.def)+'</p>', 'border-left:3px solid #E57373')

    + card(
        '<p style="font-size:18px;font-weight:700;color:#E57373;margin-bottom:5px">❌ Interdits</p>'
        + d.haid.interdits.map(function(i) { return '<p style="font-size:18px;color:'+tx2()+';line-height:1.7;padding-left:8px">• '+esc(i)+'</p>'; }).join('')
      )
    + card(
        '<p style="font-size:18px;font-weight:700;color:#81C784;margin-bottom:5px">✅ Autorisés</p>'
        + d.haid.permis.map(function(i) { return '<p style="font-size:18px;color:'+tx2()+';line-height:1.7;padding-left:8px">• '+esc(i)+'</p>'; }).join('')
      )
    + card('<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:4px">🚿 Purification</p><p style="font-size:18px;color:'+tx()+';line-height:1.75">'+esc(d.haid.taharah)+'</p>')
    + card('<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:4px">📿 Reprise &amp; rattrapage des prières</p><p style="font-size:18px;color:'+tx()+';line-height:1.75">'+esc(d.haid.rattrapage)+'</p>', 'border-left:3px solid '+gold())

    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px">🤱 '+esc(d.nifas.titre)+'</p>'
    + card('<p style="font-size:18px;color:'+tx()+';line-height:1.75;margin-bottom:6px">'+esc(d.nifas.def)+'</p>'+bullets(d.nifas.points), 'border-left:3px solid #CE93D8')

    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px">💊 '+esc(d.istihada.titre)+'</p>'
    + card('<p style="font-size:18px;color:'+tx()+';line-height:1.75">'+esc(d.istihada.def)+'</p>')
    + card(
        '<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:5px">🔍 Distinguer les deux sangs</p>'
        + '<p style="font-size:18px;color:'+tx()+';line-height:1.7;margin-bottom:4px">'+esc(d.istihada.caracteres.menstrues)+'</p>'
        + '<p style="font-size:18px;color:'+tx()+';line-height:1.7;margin-bottom:4px">'+esc(d.istihada.caracteres.metrorragie)+'</p>'
        + '<p style="font-size:16px;color:'+tx2()+';font-style:italic">'+esc(d.istihada.caracteres.note)+'</p>'
      )
    + d.istihada.situations.map(function(s){
        return card('<p style="font-size:18px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(s.t)+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(s.d)+'</p>');
      }).join('')
    + card('<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:5px">📋 Règles pratiques</p>'+bullets(d.istihada.regles))

    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px">🟡 '+esc(d.secretions.titre)+'</p>'
    + card('<p style="font-size:18px;color:'+tx()+';line-height:1.7;margin-bottom:6px">'+esc(d.secretions.def)+'</p>'+bullets(d.secretions.regles))

    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px">🤍 '+esc(d.purification.titre)+'</p>'
    + card('<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:5px">Signes de pureté</p>'+bullets(d.purification.signes)+'<p style="font-size:16px;color:'+tx2()+';font-style:italic;margin-top:4px">'+esc(d.purification.signes_note)+'</p>')
    + card('<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:5px">🚿 Le grand lavage (Ghusl)</p>'+bullets(d.purification.ghusl));

  } else if (t === 'parure') {
    var p = FEMME_DATA.parure;
    content = '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:4px">💎 '+esc(p.titre)+'</p>'
    + '<p style="font-size:18px;color:'+tx()+';line-height:1.75;margin-bottom:10px">'+esc(p.intro)+'</p>'
    + card('<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:5px">📐 Les 5 principes de la parure</p>'+bullets(p.principes))
    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px">👗 '+esc(p.vetements_titre)+'</p>'
    + p.vetements.map(function(c){
        return card('<p style="font-size:18px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(c.t)+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(c.d)+'</p>');
      }).join('')
    + card('<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:5px">📋 Règles du vêtement</p>'+bullets(p.regles_vetement))
    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px">💄 Visage, cheveux & soins</p>'
    + card('<p style="font-size:18px;font-weight:700;color:#81C784;margin-bottom:5px">✅ Permis</p>'+bullets(p.visage_permis))
    + card('<p style="font-size:18px;font-weight:700;color:#E57373;margin-bottom:5px">❌ Interdits</p>'+bullets(p.visage_interdit))
    + card('<p style="font-size:18px;font-weight:700;color:'+gold()+';margin-bottom:4px">🌸 Les parfums</p><p style="font-size:18px;color:'+tx()+';line-height:1.75">'+esc(p.parfums)+'</p>');

  } else if (t === 'grossesse') {
    var g = FEMME_DATA.grossesse;
    content = '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:8px">🤰 '+esc(g.titre)+'</p>'
    + '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:8px">'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:4px">'+g.items[1].ar+'</p>'
      + '<p style="font-size:18px;color:'+tx()+';font-style:italic;margin-bottom:2px">'+esc(g.items[1].fr)+'</p>'
      + '<p style="font-size:17px;color:'+bxT()+';font-weight:700">'+esc(g.items[1].ref)+'</p>'
    + '</div>'
    + g.items.filter(function(_,i){return i!==1;}).map(function(item) {
        return card(
          '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:4px">'+esc(item.titre)+'</p>'
          + '<p style="font-size:18px;color:'+tx2()+';line-height:1.75">'+esc(item.desc)+'</p>'
        );
      }).join('');

  } else if (t === 'duas') {
    content = FEMME_DATA.duas_femme.map(function(d) {
      return '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.18);border-radius:12px;padding:10px 12px;margin-bottom:8px">'
        + '<p style="font-size:17px;font-weight:700;color:'+gold()+';margin-bottom:5px">'+esc(d.titre)+'</p>'
        + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:5px">'+d.ar+'</p>'
        + '<p style="font-size:18px;color:'+tx()+';line-height:1.65;font-style:italic;margin-bottom:3px">'+esc(d.fr)+'</p>'
        + '<p style="font-size:17px;color:'+bxT()+';font-weight:600">'+esc(d.src)+'</p>'
      + '</div>';
    }).join('');

  } else if (t === 'modeles') {
    content = '<p style="font-size:18px;color:'+tx2()+';margin-bottom:10px;line-height:1.7">Allah nous a donné les meilleures des femmes comme modèles. Voici celles dont l\'histoire nous guide.</p>'
    + FEMME_DATA.modeles.map(function(m) {
        return card(
          '<p style="font-size:17px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(m.nom)+'</p>'
          + '<p style="font-size:18px;color:'+gold()+';margin-bottom:6px;font-weight:600">'+esc(m.titre)+'</p>'
          + '<p style="font-size:18px;color:'+tx2()+';line-height:1.75">'+esc(m.desc)+'</p>',
          'border-left:3px solid '+gold()
        );
      }).join('');
  }

  return hdr('Espace Femme 🌸', 'Cycle · Parure · Grossesse · Du\'as', "N('quotidien')")
    + pills(tabs, t, 'setFemmeTab')
    + '<div style="padding:10px 14px">' + content + '</div>';
}

function setFemmeTab(t) { S.femmeTab = t; render(); }

// Page Tarbiya (Éducation)
function pageTarbiya() {
  var tabs = [['intro','Fondements'],['naissance','Naissance'],['ages','Par âge'],['hadiths','Hadiths'],['arabe','Arabe & Coran']];
  var t = S.tarbiyaTab || 'intro';
  var content = '';

  if (t === 'intro') {
    content = '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:10px">'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:4px">'+TARBIYA_DATA.verset_cle.ar+'</p>'
      + '<p style="font-size:18px;color:'+tx()+';font-style:italic;margin-bottom:2px">'+esc(TARBIYA_DATA.verset_cle.fr)+'</p>'
      + '<p style="font-size:17px;color:'+bxT()+';font-weight:700">'+esc(TARBIYA_DATA.verset_cle.ref)+'</p>'
    + '</div>'
    + card('<p style="font-size:19px;color:'+tx()+';line-height:1.8">'+esc(TARBIYA_DATA.intro)+'</p>', 'border-left:3px solid '+bxT())
    + gcard('<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:5px">✦ Responsabilité parentale</p>'
      + '<p style="font-size:18px;color:'+tx()+';line-height:1.8">L\'éducation islamique n\'est pas optionnelle — c\'est une fard (obligation) pour les parents. Ibn al-Qayyim : "Quiconque néglige l\'éducation de son enfant le prive du bien dans cette vie et dans l\'au-delà."</p>')
    + card('<p style="font-size:18px;font-weight:700;color:'+tx()+';margin-bottom:6px">🌱 3 piliers de la tarbiya</p>'
      + [
          ['القدوة — Al-Qudwa', 'L\'exemple personnel. L\'enfant imite avant de comprendre. Sois toi-même ce que tu veux qu\'il soit.'],
          ['المحبة — Al-Mahabbah', 'L\'amour et la tendresse. Le Prophète ﷺ embrassa Al-Hasan et Al-Husayn devant une personne qui dit ne jamais embrasser ses enfants. Il dit : "Que puis-je faire si Allah a retiré la miséricorde de ton cœur ?" [Bukhâri]'],
          ['العلم — Al-\'Ilm', 'L\'enseignement progressif. Par étapes, selon l\'âge, avec patience.'],
        ].map(function(p) {
          return '<div style="margin-bottom:7px"><p style="font-size:19px;font-weight:700;color:'+bxT()+'">'+p[0]+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+p[1]+'</p></div>';
        }).join(''));

  } else if (t === 'naissance') {
    content = '<p style="font-size:18px;color:'+tx2()+';margin-bottom:8px">Les sunna de la naissance sont des actes confirmés du Prophète ﷺ — chacun a une sagesse profonde.</p>'
    + TARBIYA_DATA.naissance.map(function(item) {
        return card(
          '<div style="display:flex;gap:8px;align-items:flex-start">'
            + '<div style="background:'+bx()+';border-radius:8px;padding:3px 7px;flex-shrink:0"><p style="font-size:17px;color:#E2D38C;font-weight:700">'+esc(item.etape)+'</p></div>'
            + '<div>'
              + '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(item.sunna)+'</p>'
              + '<p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(item.detail)+'</p>'
            + '</div>'
          + '</div>'
        );
      }).join('');

  } else if (t === 'ages') {
    content = TARBIYA_DATA.education_par_age.map(function(age) {
      return '<div style="margin-bottom:10px">'
        + '<div style="background:'+bx()+';border-radius:10px;padding:6px 12px;margin-bottom:6px;display:inline-block">'
          + '<p style="font-size:19px;font-weight:700;color:#E2D38C">'+esc(age.age)+' — '+esc(age.titre)+'</p>'
        + '</div>'
        + age.points.map(function(p) {
            return '<div style="display:flex;gap:6px;align-items:flex-start;margin-bottom:4px">'
              + '<div style="width:5px;height:5px;border-radius:3px;background:'+gold()+';margin-top:5px;flex-shrink:0"></div>'
              + '<p style="font-size:18px;color:'+tx()+';line-height:1.7">'+esc(p)+'</p>'
            + '</div>';
          }).join('')
      + '</div>';
    }).join('');

  } else if (t === 'hadiths') {
    content = TARBIYA_DATA.hadiths_tarbiya.map(function(h) {
      return gcard(
        '<p style="font-size:19px;color:'+tx()+';line-height:1.8;font-style:italic;margin-bottom:4px">« '+esc(h.texte)+' »</p>'
        + '<p style="font-size:17px;color:'+gold()+';font-weight:600">'+esc(h.src)+'</p>'
      );
    }).join('');

  } else if (t === 'arabe') {
    content = TARBIYA_DATA.arabic_learning.map(function(item) {
      return card(
        '<div style="display:flex;gap:8px;align-items:flex-start">'
          + '<span style="font-size:28px;flex-shrink:0">'+item.emoji+'</span>'
          + '<div>'
            + '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:4px">'+esc(item.titre)+'</p>'
            + '<p style="font-size:18px;color:'+tx2()+';line-height:1.75">'+esc(item.desc)+'</p>'
          + '</div>'
        + '</div>'
      );
    }).join('');
  }

  return hdr('Tarbiya — التربية', 'Éducation islamique · Arabe · Coran enfant', "N('apprendre')")
    + pills(tabs, t, 'setTarbiyaTab')
    + '<div style="padding:10px 14px">' + content + '</div>';
}

function setTarbiyaTab(t) { S.tarbiyaTab = t; render(); }

// Page Planning Mémorisation
function pageHifz() {
  var tabs = [['plan','Mon Plan'],['tips','Méthode'],['dua','Du\'a Hifz']];
  var t = S.hifzTab || 'plan';
  var content = '';
  var hifzData = getHifzPlan();

  if (t === 'plan') {
    content = '<div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:10px">'
      + HIFZ_PLANS.map(function(p) {
          var on = (S.hifzPlan || 'regulier') === p.id;
          return '<button onclick="S.hifzPlan=\''+p.id+'\';render()" style="padding:5px 10px;border-radius:10px;border:1.5px solid '+(on?gold():br())+';background:'+(on?'rgba(191,174,85,.12)':'transparent')+';cursor:pointer">'
            + '<p style="font-size:18px;font-weight:'+(on?'700':'400')+';color:'+(on?gold():tx())+'">' + esc(p.label) + '</p>'
            + '<p style="font-size:17px;color:'+tx2()+'">'+esc(p.desc)+'</p>'
          + '</button>';
        }).join('')
    + '</div>'
    // Progression globale
    + card(
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">'
          + '<p style="font-size:19px;font-weight:700;color:'+tx()+'">Progression Hifz</p>'
          + '<p style="font-size:19px;font-weight:700;color:'+bxT()+'">'+hifzData.learned+'/114 🎯</p>'
        + '</div>'
        + '<div style="height:8px;background:rgba(26,58,42,.1);border-radius:4px;overflow:hidden">'
          + '<div style="height:100%;width:'+Math.round(hifzData.learned/114*100)+'%;background:linear-gradient(90deg,'+bx()+','+gold()+');border-radius:4px"></div>'
        + '</div>'
        + '<p style="font-size:17px;color:'+tx2()+';margin-top:5px">'+Math.round(hifzData.learned/114*100)+'% du Coran mémorisé</p>'
      )
    // Planning 4 semaines
    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.06em;margin-bottom:7px">Planning 4 prochaines semaines</p>'
    + (hifzData.weeks.length === 0
        ? card('<p style="font-size:19px;color:'+tx2()+';text-align:center">🎉 MashAllah ! Plan complété. Commence la révision !</p>')
        : hifzData.weeks.map(function(week) {
            var names = week.surahs.map(function(n) {
              var s = SURAHS.find(function(x){return x.n===n;});
              return s ? s.fr : '?';
            });
            return card(
              '<div style="display:flex;justify-content:space-between;align-items:flex-start">'
                + '<div>'
                  + '<p style="font-size:19px;font-weight:700;color:'+tx()+'">Semaine '+week.week+'</p>'
                  + '<p style="font-size:18px;color:'+tx2()+';margin-top:2px">'+esc(names.join(', '))+'</p>'
                  + '<p style="font-size:17px;color:'+gold()+';margin-top:3px">'+week.verses+' versets · '+Math.ceil(week.verses/7)+' versets/jour</p>'
                + '</div>'
                + '<div style="display:flex;flex-direction:column;gap:3px">'
                  + week.surahs.map(function(n) {
                      var mem = S.quranMemory && S.quranMemory[n];
                      return '<button onclick="cycleMem('+n+')" style="font-size:18px;padding:2px 7px;border-radius:6px;border:1px solid '+(mem==='learned'?'#81C784':mem==='learning'?gold():br())+';background:'+(mem==='learned'?'rgba(129,199,132,.15)':mem==='learning'?'rgba(191,174,85,.12)':'transparent')+';color:'+(mem==='learned'?'#81C784':mem==='learning'?gold():tx2())+';cursor:pointer">'
                        + (mem==='learned'?'✓ Su':mem==='learning'?'~ En cours':'+ Ajouter')
                      + '</button>';
                    }).join('')
                + '</div>'
              + '</div>'
            );
          }).join('')
      );

  } else if (t === 'tips') {
    content = [
      { titre: '1. La régularité avant la quantité', desc: '15-20 minutes par jour vaut mieux que 2h une fois par semaine. Le Prophète ﷺ aimait les actes réguliers même petits. [Bukhâri]', emoji: '⏰' },
      { titre: '2. Méthode de mémorisation', desc: 'Lis le verset 10x. Répète sans regarder. Lis le suivant. Combine les deux. Continue jusqu\'à la page. Révise le lendemain matin.', emoji: '📝' },
      { titre: '3. La révision est plus importante', desc: 'Ne passe au verset suivant que si le précédent est solide. 80% du temps = révision. 20% = nouvelle mémorisation.', emoji: '🔄' },
      { titre: '4. L\'environnement idéal', desc: 'Après Fajr — le meilleur moment. En état de pureté. Face à la Qibla. Voix audible (ne pas lire en silence). Même endroit chaque jour.', emoji: '🌅' },
      { titre: '5. Le Tajwid dès le début', desc: 'Apprends avec un correcteur (Moualima, sheikh, appli). Une mauvaise prononciation mémorisée = difficile à corriger. Qualité > quantité.', emoji: '🎵' },
      { titre: '6. Du\'a avant et après', desc: 'Demande l\'aide d\'Allah avant chaque session. Le Coran est un don d\'Allah — seul Lui peut le faire entrer dans le cœur.', emoji: '🤲' },
    ].map(function(tip) {
      return card(
        '<div style="display:flex;gap:8px">'
          + '<span style="font-size:28px;flex-shrink:0">'+tip.emoji+'</span>'
          + '<div>'
            + '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(tip.titre)+'</p>'
            + '<p style="font-size:18px;color:'+tx2()+';line-height:1.75">'+esc(tip.desc)+'</p>'
          + '</div>'
        + '</div>'
      );
    }).join('');

  } else if (t === 'dua') {
    content = [
      { ar: 'رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي', fr: 'Seigneur, dilate ma poitrine et facilite-moi ma tâche.', src: 'Tâ-Hâ 20:25-26' },
      { ar: 'رَبِّ زِدْنِي عِلْمًا', fr: 'Seigneur, accroîs mon savoir.', src: 'Tâ-Hâ 20:114' },
      { ar: 'اللَّهُمَّ انْفَعْنِي بِمَا عَلَّمْتَنِي وَعَلِّمْنِي مَا يَنفَعُنِي وَزِدْنِي عِلْمًا', fr: 'Ô Allah, fais-moi bénéficier de ce que Tu m\'as enseigné, enseigne-moi ce qui m\'est bénéfique et accroîs mon savoir.', src: 'Ibn Majah 251' },
      { ar: 'اللَّهُمَّ اجْعَلِ الْقُرْآنَ رَبِيعَ قَلْبِي وَنُورَ صَدْرِي', fr: 'Ô Allah, fais du Coran le printemps de mon cœur et la lumière de ma poitrine.', src: 'Ahmad 3712' },
      { ar: 'اللَّهُمَّ ذَكِّرْنِي مِنْهُ مَا نُسِّيتُ وَعَلِّمْنِي مِنْهُ مَا جَهِلْتُ', fr: 'Ô Allah, rappelle-moi ce que j\'ai oublié et enseigne-moi ce que j\'ignore de lui.', src: 'Sunnah' },
    ].map(function(d) {
      return '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.18);border-radius:12px;padding:10px 12px;margin-bottom:8px">'
        + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:5px">'+d.ar+'</p>'
        + '<p style="font-size:18px;color:'+tx()+';line-height:1.65;font-style:italic;margin-bottom:3px">'+esc(d.fr)+'</p>'
        + '<p style="font-size:17px;color:'+bxT()+';font-weight:600">'+esc(d.src)+'</p>'
      + '</div>';
    }).join('');
  }

  return hdr('Hifz — حِفظ', 'Planning mémorisation · Méthode · Du\'as', "N('apprendre')")
    + pills(tabs, t, 'setHifzTab')
    + '<div style="padding:10px 14px">' + content + '</div>';
}

function setHifzTab(t) { S.hifzTab = t; render(); }







