// ─── LOGO SVG ────────────────────────────────────────────────────
function logoSVG(size) {
  var s = size || 52;
  return '<svg width="'+s+'" height="'+s+'" viewBox="0 0 120 120" fill="none" style="filter:drop-shadow(0 0 8px rgba(191,174,85,.25))">'
    + '<circle cx="60" cy="60" r="54" fill="rgba(191,174,85,.06)" stroke="rgba(191,174,85,.25)" stroke-width="1.2" stroke-dasharray="4 8"/>'
    + '<circle cx="60" cy="60" r="42" fill="rgba(26,58,42,.2)" stroke="rgba(191,174,85,.1)" stroke-width=".6"/>'
    + '<text x="60" y="58" text-anchor="middle" font-family="serif" font-size="26" font-weight="700" fill="#BFAE55">نور</text>'
    + '<text x="60" y="75" text-anchor="middle" font-family="serif" font-size="16" fill="rgba(191,174,85,.65)">ايا</text>'
    + '<line x1="32" y1="84" x2="88" y2="84" stroke="rgba(191,174,85,.2)" stroke-width=".5"/>'
  + '</svg>';
}



// ═══════════════════════════════════════════════════════════════
// PAGE ACCUEIL
// ═══════════════════════════════════════════════════════════════

var VERSETS_JOUR = [
  {ar:"إِنَّ مَعَ الْعُسْرِ يُسْرًا", fr:"Avec la difficulté vient certes la facilité.", ref:"Al-Inshirah 94:6"},
  {ar:"وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ", fr:"Celui qui s'en remet à Allah, Il lui suffit.", ref:"At-Talaq 65:3"},
  {ar:"إِنَّ اللَّهَ مَعَ الصَّابِرِينَ", fr:"Allah est avec les patients.", ref:"Al-Baqara 2:153"},
  {ar:"رَبِّ إِنِّي لِمَا أَنزَلْتَ إِلَيَّ مِنْ خَيْرٍ فَقِيرٌ", fr:"Seigneur, je suis dans le besoin du bien que Tu m'accordes.", ref:"Al-Qasas 28:24"},
  {ar:"وَاللَّهُ يُحِبُّ الْمُحْسِنِينَ", fr:"Allah aime ceux qui font le bien.", ref:"Al-Imran 3:134"},
  {ar:"لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا", fr:"Allah n'impose à personne plus que ses capacités.", ref:"Al-Baqara 2:286"},
  {ar:"وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ", fr:"Il est avec vous où que vous soyez.", ref:"Al-Hadid 57:4"},
];

function pageAccueil() {
  var vj = VERSETS_JOUR[new Date().getDay()];
  ensureRoutine();
  var done = S.routineDots.filter(Boolean).length;
  var pct = Math.round(done / Math.max(1,S.routineDots.length) * 100);
  var nom = S.profil.nom ? S.profil.nom : (S.profil.genre==='homme'?'frère':'sœur');
  var hour = new Date().getHours();
  var greet = hour < 5 ? 'Bonne nuit' : hour < 12 ? 'Bonjour' : hour < 18 ? 'Bon après-midi' : 'Bonne soirée';
  var th = activeTheme();
  var acc = gold();

  // Grille réduite aux essentiels + "Tout voir"
  var QUICK = [
    {id:'coran',  e:'📖', l:'Coran'},
    {id:'salat',  e:'🕌', l:'Salât'},
    {id:'dhikr',  e:'📿', l:'Dhikr'},
    {id:'adhkar', e:'🌙', l:'Adhkâr'},
    {id:'qibla',  e:'🧭', l:'Qibla'},
    {id:'__more', e:'⋯',  l:'Tout voir'},
  ];

  return (
    '<div class="stagger" style="padding-bottom:18px">'

    // ══ Header raffiné avec ornement ══
    + '<div style="background:linear-gradient(155deg,'+th.grad[0]+' 0%,'+th.grad[1]+' 100%);padding:18px 16px 20px;position:relative;overflow:hidden;border-radius:0 0 26px 26px">'
      + '<div style="position:absolute;right:-22px;top:-22px;pointer-events:none">'+ornStar(150, hexA('#FFFFFF',1), .05)+'</div>'
      + '<div style="position:absolute;left:-30px;bottom:-40px;pointer-events:none">'+ornStar(110, hexA('#FFFFFF',1), .04)+'</div>'
      + '<div style="display:flex;justify-content:space-between;align-items:flex-start;position:relative">'
        + '<div style="display:flex;align-items:center;gap:11px">'
          + '<div style="animation:floatY 5s ease-in-out infinite">'+logoSVG(46)+'</div>'
          + '<div>'
            + '<p style="color:#F2E9D0;font-size:21px;letter-spacing:.2em;font-family:Fraunces,Georgia,serif;font-weight:500">Nûraya</p>'
            + '<p style="color:'+hexA('#F2E9D0',.6)+';font-size:15px;margin-top:1px">'+greet+', '+esc(nom)+'</p>'
          + '</div>'
        + '</div>'
        + '<div style="text-align:right">'
          + '<p id="HOME_CLOCK" style="color:#F2E9D0;font-size:32px;font-weight:300;font-family:Fraunces,Georgia,serif;line-height:1">' + nowTime() + '</p>'
          + '<div style="display:flex;gap:6px;justify-content:flex-end;margin-top:7px">'
            + '<span style="display:inline-flex;align-items:center;gap:4px;background:'+hexA('#F2E9D0',.12)+';border:1px solid '+hexA('#F2E9D0',.2)+';border-radius:20px;padding:3px 10px"><span style="font-size:15px">🔥</span><span style="font-size:15px;color:#F2E9D0;font-weight:600">' + S.streak + '</span></span>'
            + '<button onclick="N(\'profil\')" title="Profil" style="width:30px;height:30px;display:inline-flex;align-items:center;justify-content:center;background:'+hexA('#F2E9D0',.12)+';border:1px solid '+hexA('#F2E9D0',.2)+';border-radius:50%;cursor:pointer;font-size:15px">👤</button>'
          + '</div>'
        + '</div>'
      + '</div>'
      // ══ Météo spirituelle du jour ══
      + spiritualWeather()
    + '</div>'

    + '<div style="padding:14px 16px 0">'

      // ══ Cartes contextuelles (Niyya / Salât / reprise) ══
      + homeNiyyaCard()
      + homeSalatCard()
      + homeResumeCard()

      // ══ Verset du jour — encadré orné ══
      + '<div style="background:'+bg2()+';border:1px solid '+hexA(acc,.28)+';border-radius:18px;padding:16px 15px 14px;margin:10px 0 6px;position:relative;overflow:hidden">'
        + '<div style="position:absolute;right:8px;top:8px;pointer-events:none">'+ornStar(64, acc, .07)+'</div>'
        + '<div class="ornate-title" style="margin-bottom:10px"><span style="font-size:13px;color:'+acc+';font-weight:700;letter-spacing:.14em;text-transform:uppercase;white-space:nowrap">Verset du jour</span></div>'
        + '<p style="font-family:Amiri,serif;font-size:25px;color:'+tx()+';text-align:center;direction:rtl;line-height:2;margin-bottom:10px">' + esc(vj.ar) + '</p>'
        + '<p style="font-size:17px;color:'+tx2()+';line-height:1.6;text-align:center;font-style:italic;margin-bottom:5px">« ' + esc(vj.fr) + ' »</p>'
        + '<p style="font-size:14px;color:'+acc+';font-weight:600;text-align:center;letter-spacing:.03em">— ' + esc(vj.ref) + '</p>'
      + '</div>'

      // ══ Routine du jour — compacte ══
      + '<div class="press" onclick="N(\'routine\')" style="background:'+bg2()+';border:1px solid '+br()+';border-radius:16px;padding:13px 15px;margin-bottom:14px;cursor:pointer">'
        + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:9px">'
          + '<span style="font-size:16px;font-weight:600;color:'+tx()+'">☑ Routine du jour</span>'
          + '<span style="font-size:15px;font-weight:700;color:'+acc+'">' + done + '/' + S.routineDots.length + '</span>'
        + '</div>'
        + '<div style="height:7px;background:'+hexA(th.bx,.1)+';border-radius:4px;overflow:hidden">'
          + '<div style="height:100%;width:'+pct+'%;background:linear-gradient(90deg,'+acc+','+goldStrong()+');border-radius:4px;transition:width .6s cubic-bezier(.2,.7,.3,1)"></div>'
        + '</div>'
      + '</div>'

      // ══ Accès rapides — 6 essentiels ══
      + '<div class="ornate-title" style="margin:4px 0 12px"><span style="font-size:13px;color:'+tx2()+';font-weight:700;letter-spacing:.14em;text-transform:uppercase;white-space:nowrap">Accès rapides</span></div>'
      + '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:9px">'
        + QUICK.map(function(q) {
            var action = q.id==='__more' ? 'N(\'quotidien\')' : 'N(\''+q.id+'\')';
            return '<button class="press" onclick="'+action+'" style="background:'+bg2()+';border:1px solid '+br()+';border-radius:16px;padding:15px 5px 12px;display:flex;flex-direction:column;align-items:center;gap:9px;cursor:pointer">'
              + '<div style="background:'+hexA(acc,.1)+';border:1px solid '+hexA(acc,.18)+';border-radius:13px;width:48px;height:48px;display:flex;align-items:center;justify-content:center;font-size:25px">' + q.e + '</div>'
              + '<p style="font-size:14px;font-weight:600;color:'+tx2()+'">' + q.l + '</p>'
            + '</button>';
          }).join('')
      + '</div>'

      + ornSep()
      + '<p style="text-align:center;font-size:13px;color:'+tx2()+';opacity:.6;font-family:Amiri,serif;direction:rtl;padding-bottom:4px">وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ</p>'

    + '</div>'
    + '</div>'
  );
}

function tapStreak() {
  S.streak++;
  var el = document.getElementById('HOME_STREAK');
  if (el) el.textContent = S.streak + ' jours';
  save();
}


// ─── Routines personnalisées ───
function routineItems() {
  return ROUTINE_ITEMS.concat(S.profil.customRoutine || []);
}
function ensureRoutine() {
  // Remise à zéro quotidienne
  var today = salatToday();
  if (S.profil.routineDate !== today) {
    S.profil.routineDate = today;
    S.routineDots = routineItems().map(function(){ return false; });
    save();
  }
  // Synchroniser la longueur des coches avec le nombre d'items
  var n = routineItems().length;
  while (S.routineDots.length < n) S.routineDots.push(false);
  if (S.routineDots.length > n) S.routineDots = S.routineDots.slice(0, n);
}
function addRoutineItem() {
  var eEl = document.getElementById('CR_E'), lEl = document.getElementById('CR_L');
  var label = (lEl && lEl.value || '').trim();
  if (!label) { toast('Donne un nom à ton étape'); return; }
  var emoji = (eEl && eEl.value || '').trim() || '⭐';
  if (!S.profil.customRoutine) S.profil.customRoutine = [];
  if (routineItems().length >= 20) { toast('20 étapes maximum'); return; }
  S.profil.customRoutine.push({ e: emoji.slice(0,4), label: label.slice(0,40) });
  S.routineDots.push(false);
  save();
  toast('Étape ajoutée ✓');
  render();
}
function removeRoutineItem(j) {
  var idx = ROUTINE_ITEMS.length + j;
  S.profil.customRoutine.splice(j, 1);
  S.routineDots.splice(idx, 1);
  save();
  render();
}

function toggleDot(i) {
  S.routineDots[i] = !S.routineDots[i];
  var done = S.routineDots.filter(Boolean).length;
  if (S.routineDots[i] && done === S.routineDots.length) haptic('celebrate');
  else if (S.routineDots[i]) haptic('soft');
  var pct = Math.round(done / S.routineDots.length * 100);
  var bar = document.getElementById('HOME_BAR');
  var pEl = document.getElementById('HOME_PCT');
  var dot = document.getElementById('RD'+i);
  if (bar) bar.style.width = pct + '%';
  if (pEl) pEl.textContent = pct + '%';
  if (dot) {
    dot.style.background = S.routineDots[i] ? 'linear-gradient(90deg,'+bx()+','+gold()+')' : 'rgba(26,58,42,.1)';
    dot.style.transform = 'scaleY(2)';
    setTimeout(function() { dot.style.transform = 'scaleY(1)'; }, 200);
  }
  save();
}

function nowTime() {
  var d = new Date();
  return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
}


