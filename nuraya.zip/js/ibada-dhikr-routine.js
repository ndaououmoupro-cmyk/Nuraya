// ═══════════════════════════════════════════════════════════════
// PAGES IBADA — Dhikr, Routine, Zakât
// ═══════════════════════════════════════════════════════════════

var DHIKRS = [
  {ar:'سُبْحَانَ اللَّهِ',      fr:'Soubhâna Llâh',          max:33,  color:'#1A3A2A'},
  {ar:'الْحَمْدُ لِلَّهِ',      fr:'Al-Hamdu Lillâh',         max:33,  color:'#4A5E2A'},
  {ar:'اللَّهُ أَكْبَرُ',       fr:'Allâhu Akbar',            max:34,  color:'#1A3A5C'},
  {ar:'لَا إِلَهَ إِلَّا اللَّهُ', fr:'Lâ ilâha illa Llâh',   max:100, color:'#4A2E1A'},
  {ar:'أَسْتَغْفِرُ اللَّهَ',   fr:'Astaghfiru Llâh',         max:100, color:'#2A1A4A'},
  {ar:'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', fr:'Lâ hawla wa lâ quwwata illâ billâh', max:100, color:'#1A4A3A'},
];

// ─── DHIKR ──────────────────────────────────────────────────────
function pageDhikr() {
  var d = DHIKRS[S.dhikrIdx];
  var pct = Math.min(1, S.dhikrCount / d.max);
  var angle = pct * 283;
  var tabs = [['counter','Compteur'],['history','Historique']];

  if (S.dhikrTab === 'history') {
    return hdr('Dhikr · ذِكر', 'Compteur haptique')
      + pills(tabs, S.dhikrTab, 'setDhikrTab')
      + '<div style="padding:10px 14px">'
      + (S.dhikrHistory.length === 0
          ? '<p style="text-align:center;color:'+tx2()+';font-size:19px;padding:30px 0">Aucune session enregistrée</p>'
          : S.dhikrHistory.slice().reverse().map(function(h) {
              return card('<div style="display:flex;justify-content:space-between;align-items:center">'
                + '<div><p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+'">'+h.ar+'</p><p style="font-size:18px;color:'+tx2()+'">'+(h.name||h.fr)+'</p></div>'
                + '<div style="text-align:right"><p style="font-size:22px;font-weight:700;color:'+tx()+'">'+h.count+'</p><p style="font-size:17px;color:'+tx2()+'">'+esc(h.date)+'</p></div>'
              + '</div>');
            }).join('')
        )
      + '</div>';
  }

  return hdr('Dhikr · ذِكر', 'Compteur haptique')
    + pills(tabs, S.dhikrTab, 'setDhikrTab')
    + '<div style="padding:10px 14px">'
    // Sélecteur dhikr
    + '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:16px;justify-content:center">'
      + DHIKRS.map(function(d2, i) {
          var on = S.dhikrIdx === i;
          return '<button class="press" onclick="switchDhikr('+i+')" style="padding:5px 12px;border-radius:14px;border:1.5px solid '+(on?gold():br())+';background:'+(on?hexA(gold(),.12):'transparent')+';color:'+(on?gold():tx2())+';font-size:16px;cursor:pointer;font-family:inherit;font-weight:'+(on?'600':'400')+'">'
            + esc(d2.fr) + '</button>';
        }).join('')
    + '</div>'
    // ── Perle de tasbih centrale ──
    + '<div style="display:flex;flex-direction:column;align-items:center;margin:4px 0 16px">'
      + '<div id="DHIKR_TAP" onclick="tapDhikr()" style="position:relative;width:230px;height:230px;cursor:pointer;display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent;user-select:none">'
        // halo pulsant
        + '<div id="DHIKR_HALO" style="position:absolute;width:180px;height:180px;border-radius:50%;background:radial-gradient(circle,'+hexA(d.color,.22)+',transparent 70%);opacity:.7;transition:transform .4s,opacity .4s;pointer-events:none"></div>'
        // anneau de progression
        + '<svg width="230" height="230" viewBox="0 0 100 100" style="position:absolute;transform:rotate(-90deg)">'
          + '<circle cx="50" cy="50" r="44" fill="none" stroke="'+hexA(tx2(),.14)+'" stroke-width="4"/>'
          + '<circle id="DHIKR_RING" cx="50" cy="50" r="44" fill="none" stroke="'+d.color+'" stroke-width="4.5" stroke-linecap="round" stroke-dasharray="276.4" stroke-dashoffset="'+(276.4 - pct*276.4)+'" style="transition:stroke-dashoffset .45s cubic-bezier(.16,1,.3,1);filter:drop-shadow(0 0 4px '+hexA(d.color,.5)+')"/>'
        + '</svg>'
        // perle centrale
        + '<div id="DHIKR_BEAD" style="width:142px;height:142px;border-radius:50%;background:radial-gradient(circle at 38% 32%,'+hexA(gold(),.95)+','+goldStrong()+' 75%);box-shadow:0 10px 30px '+hexA(activeTheme().bx,.35)+',inset 0 -8px 18px '+hexA('#000000',.18)+',inset 0 6px 14px '+hexA('#FFFFFF',.3)+';display:flex;flex-direction:column;align-items:center;justify-content:center;transition:transform .14s cubic-bezier(.34,1.56,.64,1);position:relative">'
          + '<p id="DHIKR_COUNT" style="font-size:52px;font-weight:300;color:#FFFDF0;font-family:Fraunces,Georgia,serif;line-height:1;text-shadow:0 2px 6px '+hexA(activeTheme().bx,.4)+'">'+S.dhikrCount+'</p>'
          + '<p style="font-size:16px;color:'+hexA('#FFFDF0',.75)+'">/ '+d.max+'</p>'
        + '</div>'
      + '</div>'
      + '<p style="font-family:Amiri,serif;font-size:30px;color:'+gold()+';text-align:center;direction:rtl;margin:14px 0 4px;line-height:1.6">'+d.ar+'</p>'
      + '<p style="font-size:18px;color:'+tx2()+'">'+esc(d.fr)+'</p>'
    + '</div>'
    // Boutons
    + '<div style="display:flex;gap:8px">'
      + '<button class="press" onclick="tapDhikr()" style="flex:3;padding:15px;border-radius:15px;border:none;background:linear-gradient(150deg,'+activeTheme().grad[0]+','+activeTheme().grad[1]+');color:'+(S.dark?activeTheme().dark.goldT:'#FFFDF0')+';font-size:18px;font-family:Fraunces,Georgia,serif;cursor:pointer;box-shadow:0 4px 14px '+hexA(activeTheme().bx,.25)+'">Tasbîh ✦</button>'
      + '<button class="press" onclick="resetDhikr()" style="flex:1;padding:15px;border-radius:15px;border:1.5px solid '+br()+';background:transparent;color:'+tx2()+';font-size:20px;cursor:pointer">↺</button>'
    + '</div>'
    + '<p style="text-align:center;font-size:16px;color:'+tx2()+';margin-top:10px">Total de la session : <b style="color:'+gold()+'">'+S.dhikrTotal+'</b></p>'
    + '</div>';
}

function setDhikrTab(t) { S.dhikrTab = t; render(); }

function switchDhikr(i) {
  if (S.dhikrCount > 0) {
    S.dhikrHistory.push({ ar: DHIKRS[S.dhikrIdx].ar, fr: DHIKRS[S.dhikrIdx].fr, count: S.dhikrCount, date: new Date().toLocaleDateString('fr-FR') });
    save();
  }
  S.dhikrIdx = i; S.dhikrCount = 0; render();
}

// ─── Son doux du dhikr (Web Audio, généré, sans fichier) ───
var _actx = null;
function dhikrSound(complete) {
  if (S.profil && S.profil.noSound) return;
  try {
    _actx = _actx || new (window.AudioContext || window.webkitAudioContext)();
    var now = _actx.currentTime;
    var freqs = complete ? [523.25, 659.25, 783.99] : [659.25];
    freqs.forEach(function(f, k){
      var o = _actx.createOscillator(), g = _actx.createGain();
      o.type = 'sine'; o.frequency.value = f;
      var t0 = now + k*0.09;
      g.gain.setValueAtTime(0, t0);
      g.gain.linearRampToValueAtTime(complete?0.14:0.09, t0+0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + (complete?0.5:0.22));
      o.connect(g); g.connect(_actx.destination);
      o.start(t0); o.stop(t0 + (complete?0.55:0.26));
    });
  } catch(e) {}
}

function tapDhikr() {
  var d = DHIKRS[S.dhikrIdx];
  S.dhikrCount++;
  S.dhikrTotal++;
  var done = S.dhikrCount >= d.max;
  if (!S.profil || !S.profil.noHaptic) { if (navigator.vibrate) navigator.vibrate(done?[60,30,60]:14); }
  dhikrSound(done);
  // animations
  var bead = document.getElementById('DHIKR_BEAD');
  var halo = document.getElementById('DHIKR_HALO');
  var ring = document.getElementById('DHIKR_RING');
  var el = document.getElementById('DHIKR_COUNT');
  if (bead) { bead.style.transform = 'scale(.93)'; setTimeout(function(){ bead.style.transform = 'scale(1)'; }, 140); }
  if (halo) { halo.style.transform = 'scale(1.18)'; halo.style.opacity = '1'; setTimeout(function(){ halo.style.transform = 'scale(1)'; halo.style.opacity = '.7'; }, 380); }
  if (ring) { var pct = Math.min(1, S.dhikrCount / d.max); ring.style.strokeDashoffset = (276.4 - pct*276.4); }
  if (el) el.textContent = S.dhikrCount;
  if (done) {
    S.dhikrHistory.push({ ar: d.ar, fr: d.fr, count: d.max, date: new Date().toLocaleDateString('fr-FR') });
    S.dhikrCount = 0;
    save();
    setTimeout(function(){ render(); toast('Dhikr complété · '+d.max+' ✦'); }, 420);
  }
}

function resetDhikr() {
  if (S.dhikrCount > 0) {
    S.dhikrHistory.push({ ar: DHIKRS[S.dhikrIdx].ar, fr: DHIKRS[S.dhikrIdx].fr, count: S.dhikrCount, date: new Date().toLocaleDateString('fr-FR') });
  }
  S.dhikrCount = 0; save(); render();
}

// ─── ROUTINE ────────────────────────────────────────────────────
var ROUTINE_ITEMS = [
  {e:'🌅', label:'Fajr'},
  {e:'📿', label:'Adhkâr matin'},
  {e:'📖', label:'Révision Coran'},
  {e:'🕐', label:'Dohr'},
  {e:'📚', label:'Lecture 15min'},
  {e:'🕓', label:'Asr'},
  {e:'🌙', label:'Adhkâr soir'},
  {e:'🌆', label:'Maghrib'},
  {e:'🌃', label:'Icha'},
  {e:'🤲', label:'Dhikr du soir'},
];

function pageRoutine() {
  ensureRoutine();
  var done = S.routineDots.filter(Boolean).length;
  var pct = Math.round(done / S.routineDots.length * 100);

  return hdr('Routine · الرُّوتِين', 'Ta journée islâmique')
    + '<div style="padding:10px 14px">'
    // Barre
    + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">'
      + '<div style="flex:1;height:7px;background:rgba(26,58,42,.1);border-radius:4px;overflow:hidden">'
        + '<div style="height:100%;width:'+pct+'%;background:linear-gradient(90deg,'+bx()+','+gold()+');border-radius:4px;transition:width .5s"></div>'
      + '</div>'
      + '<span style="font-size:19px;font-weight:700;color:'+bxT()+';min-width:36px;text-align:right">'+pct+'%</span>'
    + '</div>'
    // Streak
    + '<div style="display:flex;align-items:center;justify-content:space-between;background:'+bg2()+';border:1px solid '+br()+';border-radius:12px;padding:10px 14px;margin-bottom:10px">'
      + '<div><p style="font-size:18px;color:'+tx2()+'">Série actuelle</p><p style="font-size:21px;font-weight:700;color:'+tx()+'">🔥 '+S.streak+' jours</p></div>'
      + '<button onclick="tapStreak()" style="padding:6px 14px;border-radius:10px;border:1.5px solid '+gold()+';background:rgba(191,174,85,.1);color:'+gold()+';font-size:18px;cursor:pointer;font-family:inherit">+1 jour</button>'
    + '</div>'
    // Items
    + routineItems().map(function(item, i) {
        var done = S.routineDots[i];
        var isCustom = i >= ROUTINE_ITEMS.length;
        return '<div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">'
          + '<button onclick="toggleDot('+i+')" style="flex:1;display:flex;align-items:center;gap:10px;padding:11px 12px;border-radius:12px;border:1.5px solid '+(done?gold():br())+';background:'+(done?'rgba(191,174,85,.07)':'transparent')+';cursor:pointer;transition:all .2s">'
            + '<span style="font-size:26px">'+esc(item.e)+'</span>'
            + '<span style="font-size:19px;font-weight:'+(done?'700':'400')+';color:'+(done?tx():tx2())+';flex:1;text-align:left">'+esc(item.label)+'</span>'
            + '<div style="width:20px;height:20px;border-radius:6px;border:2px solid '+(done?gold():'rgba(191,174,85,.3)')+';background:'+(done?gold():'transparent')+';display:flex;align-items:center;justify-content:center">'
              + (done ? '<span style="font-size:17px;color:#fff;font-weight:700">✓</span>' : '')
            + '</div>'
          + '</button>'
          + (isCustom ? '<button onclick="removeRoutineItem('+(i-ROUTINE_ITEMS.length)+')" title="Supprimer" style="width:34px;height:34px;border-radius:10px;border:1px solid '+br()+';background:transparent;color:'+tx2()+';font-size:17px;cursor:pointer;flex-shrink:0">✕</button>' : '')
        + '</div>';
      }).join('')
    // ── Ajouter une étape personnalisée ──
    + '<div style="border:1.5px dashed '+br()+';border-radius:12px;padding:10px 12px;margin-top:4px">'
      + '<p style="font-size:17px;font-weight:700;color:'+gold()+';letter-spacing:.06em;text-transform:uppercase;margin-bottom:7px">＋ Ma propre étape</p>'
      + '<div style="display:flex;gap:6px">'
        + '<input id="CR_E" placeholder="🌟" maxlength="4" style="width:52px;padding:9px 6px;border-radius:10px;border:1.5px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:19px;text-align:center;font-family:inherit">'
        + '<input id="CR_L" placeholder="Ex. Sport, Istighfâr 100x, Appeler maman…" maxlength="40" onkeydown="if(event.key===\'Enter\')addRoutineItem()" style="flex:1;padding:9px 11px;border-radius:10px;border:1.5px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:18px;font-family:inherit;min-width:0">'
        + '<button class="btn-gold" onclick="addRoutineItem()" style="width:44px;border-radius:10px;border:none;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');color:#FFFDF0;font-size:21px;font-weight:700;cursor:pointer;flex-shrink:0">+</button>'
      + '</div>'
      + '<p style="font-size:15px;color:'+tx2()+';opacity:.75;margin-top:6px">Tes étapes s\'ajoutent à ta routine quotidienne — coches remises à zéro chaque matin.</p>'
    + '</div>'
    + '</div>';
}

