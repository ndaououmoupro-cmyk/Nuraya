// ═══════════════════════════════════════════════════════════════
// PAGES ILM — Aqida, Tawhid, Sira, Prophètes, 99 Noms, Hajj
// ═══════════════════════════════════════════════════════════════

// ─── AQIDA ──────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════
// VIE SELON LA SUNNA — alimentation prophétique & gestion du foyer
// ═══════════════════════════════════════════════════════════════
var SUNNA_ALIMENTS = [
  { e:'🫒', nom:'Huile d\'olive', ar:'الزَّيْتُون',
    vertu:"« Mangez de l\'huile d\'olive et ointez-vous-en, car elle provient d\'un arbre béni. »",
    src:'At-Tirmidhî 1851 (hasan)', usage:"En assaisonnement cru, ou massée sur la peau et les cheveux." },
  { e:'🍯', nom:'Miel', ar:'العَسَل',
    vertu:"« Il y a une guérison pour les gens. » Le Prophète ﷺ aimait les sucreries et le miel.",
    src:'Coran An-Nahl 16:69 · Bukhârî 5682', usage:"Une cuillère à jeun, ou dilué dans de l\'eau tiède le matin." },
  { e:'🌿', nom:'Graine de nigelle', ar:'الحَبَّة السَّوْدَاء',
    vertu:"« Dans la graine noire, il y a un remède contre toute maladie, sauf la mort. »",
    src:'Sahîh al-Bukhârî 5688', usage:"Quelques graines avec du miel, ou en huile." },
  { e:'🌴', nom:'Dattes', ar:'التَّمْر',
    vertu:"« Celui qui mange 7 dattes \u2018ajwa le matin, ni poison ni sorcellerie ne lui nuiront ce jour-là. »",
    src:'Sahîh al-Bukhârî 5445', usage:"Rompre le jeûne avec, ou au petit-déjeuner." },
  { e:'🥛', nom:'Lait', ar:'اللَّبَن',
    vertu:"Le Prophète ﷺ disait après l\'avoir bu : « Ô Allah, bénis-nous en lui et augmente-nous-en. »",
    src:'Abû Dâwud 3730 (hasan)', usage:"La seule boisson pour laquelle cette du\'â est rapportée." },
  { e:'🎃', nom:'Courge (dubbâ)', ar:'الدُّبَّاء',
    vertu:"Anas rapporta que le Prophète ﷺ aimait la courge et la cherchait dans le plat.",
    src:'Sahîh al-Bukhârî 5379', usage:"En soupe ou cuite, un légume aimé du Prophète ﷺ." },
  { e:'🍇', nom:'Raisin', ar:'العِنَب',
    vertu:"Fruit mentionné dans le Coran parmi les bienfaits et les fruits du Paradis.",
    src:'Coran \u2018Abasa 80:28', usage:"Frais, ou sec en complément énergétique." },
  { e:'💧', nom:'Eau de Zamzam', ar:'مَاء زَمْزَم',
    vertu:"« L\'eau de Zamzam est selon l\'intention pour laquelle on la boit. »",
    src:'Ibn Mâjah 3062 (hasan)', usage:"Boire en faisant une intention (guérison, satiété…), face à la Qibla." },
];
var SUNNA_ADAB = [
  { e:'🤲', t:"Avant de manger", d:"Dire « Bismillah ». Si on oublie : « Bismillâhi awwalahu wa âkhirahu »." },
  { e:'✋', t:"Manger de la main droite", d:"« Mange de ta main droite et de ce qui est près de toi. » (Bukhârî 5376)" },
  { e:'🍽️', t:"Le tiers", d:"« Un tiers de nourriture, un tiers d\'eau, un tiers d\'air. » (At-Tirmidhî 2380)" },
  { e:'🪑', t:"S\'asseoir pour manger", d:"Le Prophète ﷺ ne mangeait pas accoudé ni debout par habitude." },
  { e:'🧎', t:"Ne pas critiquer la nourriture", d:"« Il ne dénigrait jamais un aliment : s\'il l\'aimait il en mangeait, sinon il le laissait. » (Muslim 2064)" },
  { e:'🙏', t:"Après le repas", d:"« Al-hamdu lillâhi lladhî at\'amanâ wa saqânâ wa ja\'alanâ muslimîn. » (Abû Dâwud 3850)" },
];

function pageSunnaFood() {
  var acc = gold();
  var tab = S.sunnaTab || 'aliments';
  var body = '';
  if (tab === 'aliments') {
    body = SUNNA_ALIMENTS.map(function(a){
      return '<div style="background:'+bg2()+';border:1px solid '+br()+';border-radius:16px;padding:14px;margin-bottom:9px;position:relative;overflow:hidden">'
        + '<div style="position:absolute;right:-10px;bottom:-10px;pointer-events:none">'+ornStar(54, acc, .06)+'</div>'
        + '<div style="display:flex;align-items:center;gap:11px;margin-bottom:7px">'
          + '<span style="font-size:30px">'+a.e+'</span>'
          + '<div><p style="font-size:18px;font-weight:700;color:'+tx()+';font-family:Fraunces,Georgia,serif">'+a.nom+'</p>'
          + '<p style="font-size:17px;color:'+acc+';direction:rtl;font-family:Amiri,serif">'+a.ar+'</p></div>'
        + '</div>'
        + '<p style="font-size:16px;color:'+tx()+';line-height:1.6;font-style:italic;margin-bottom:5px">'+esc(a.vertu)+'</p>'
        + '<p style="font-size:14px;color:'+acc+';font-weight:600;margin-bottom:6px">📚 '+esc(a.src)+'</p>'
        + '<div style="background:'+hexA(acc,.07)+';border-radius:9px;padding:7px 10px"><p style="font-size:14px;color:'+tx2()+';line-height:1.5">💡 '+esc(a.usage)+'</p></div>'
      + '</div>';
    }).join('');
  } else {
    body = SUNNA_ADAB.map(function(a){
      return '<div style="background:'+bg2()+';border:1px solid '+br()+';border-radius:14px;padding:13px 15px;margin-bottom:8px;display:flex;gap:12px">'
        + '<span style="font-size:26px;flex-shrink:0">'+a.e+'</span>'
        + '<div><p style="font-size:17px;font-weight:700;color:'+tx()+'">'+esc(a.t)+'</p>'
        + '<p style="font-size:15px;color:'+tx2()+';line-height:1.55;margin-top:2px">'+esc(a.d)+'</p></div>'
      + '</div>';
    }).join('');
  }
  return hdr('Alimentation prophétique', '🫒 Tayyibât · Sunna', "N('quotidien')")
    + pills([['aliments','Aliments bénis'],['adab','Adab du repas']], tab, 'setSunnaTab')
    + '<div class="stagger" style="padding:12px 16px 24px">' + body
    + '<p style="text-align:center;font-size:13px;color:'+tx2()+';opacity:.7;margin-top:8px;line-height:1.6">Ces aliments sont des bienfaits cités dans la Sunna — pour tout problème de santé, consulte un médecin.</p>'
    + '</div>';
}
function setSunnaTab(t){ S.sunnaTab = t; render(); }

// ═══════════════════════════════════════════════════════════════
// GESTION DU FOYER — bénédiction, rythme, checklist personnalisable
// ═══════════════════════════════════════════════════════════════
var FOYER_BARAKA = [
  { e:'🚪', t:"Entrer dans la maison", d:"Saluer (même vide) et mentionner Allah à l\'entrée : Shaytân n\'y passe pas la nuit. (Muslim 2018)" },
  { e:'📖', t:"Réciter Al-Baqara", d:"« Ne faites pas de vos maisons des tombes : Shaytân fuit la maison où on récite Al-Baqara. » (Muslim 780)" },
  { e:'🤲', t:"Du\'â du foyer", d:"« Rabbi anzilnî munzalan mubârakan wa anta khayru l-munzilîn. » (Coran 23:29)" },
  { e:'🌙', t:"Avant de dormir", d:"Éteindre les feux, fermer les récipients, mentionner Allah — protection du foyer. (Bukhârî 6296)" },
  { e:'🧹', t:"La propreté", d:"« La pureté est la moitié de la foi. » Un foyer propre apaise le cœur et attire les anges. (Muslim 223)" },
  { e:'💝', t:"La douceur au foyer", d:"« Le meilleur d\'entre vous est le meilleur envers sa famille. » (At-Tirmidhî 3895)" },
];

function foyerData() {
  if (!S.profil.foyer) S.profil.foyer = { tasks: [], date: '' };
  // reset hebdo léger : on garde les tâches, on remet les coches chaque jour
  if (S.profil.foyer.date !== salatToday()) {
    S.profil.foyer.date = salatToday();
    (S.profil.foyer.tasks||[]).forEach(function(t){ t.done = false; });
  }
  return S.profil.foyer;
}
function foyerAdd() {
  var el = document.getElementById('FOYER_NEW');
  var v = (el && el.value || '').trim();
  if (!v) return;
  var f = foyerData();
  f.tasks.push({ label: v.slice(0,50), done: false });
  save(); render();
}
function foyerToggle(i){ var f=foyerData(); f.tasks[i].done=!f.tasks[i].done; if(f.tasks[i].done){ var allDone=f.tasks.every(function(t){return t.done;}); haptic(allDone?'success':'soft'); } save(); render(); }
function foyerRemove(i){ var f=foyerData(); f.tasks.splice(i,1); save(); render(); }
function foyerSeed() {
  var f = foyerData();
  ['Aérer les pièces','Vaisselle','Linge','Préparer le repas','Ranger le salon','Sortir les poubelles'].forEach(function(l){
    f.tasks.push({label:l, done:false});
  });
  save(); render();
}

function pageFoyer() {
  var acc = gold();
  var f = foyerData();
  var done = f.tasks.filter(function(t){return t.done;}).length;
  var pct = f.tasks.length ? Math.round(done/f.tasks.length*100) : 0;
  var tab = S.foyerTab || 'checklist';

  var body;
  if (tab === 'baraka') {
    body = '<p style="font-size:16px;color:'+tx2()+';line-height:1.7;margin-bottom:10px">Un foyer musulman se construit autant par la spiritualité que par l\'ordre. Voici les clés prophétiques de la bénédiction (baraka) du foyer.</p>'
      + FOYER_BARAKA.map(function(b){
          return '<div style="background:'+bg2()+';border:1px solid '+br()+';border-radius:14px;padding:13px 15px;margin-bottom:8px;display:flex;gap:12px">'
            + '<span style="font-size:26px;flex-shrink:0">'+b.e+'</span>'
            + '<div><p style="font-size:17px;font-weight:700;color:'+tx()+'">'+esc(b.t)+'</p>'
            + '<p style="font-size:15px;color:'+tx2()+';line-height:1.55;margin-top:2px">'+esc(b.d)+'</p></div>'
          + '</div>';
        }).join('');
  } else {
    body = '<div style="background:'+bg2()+';border:1px solid '+br()+';border-radius:16px;padding:14px;margin-bottom:12px">'
      + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">'
        + '<span style="font-size:17px;font-weight:700;color:'+tx()+'">Tâches du jour</span>'
        + '<span style="font-size:15px;font-weight:700;color:'+acc+'">'+done+'/'+f.tasks.length+'</span>'
      + '</div>'
      + '<div style="height:7px;background:'+hexA(activeTheme().bx,.1)+';border-radius:4px;overflow:hidden;margin-bottom:'+(f.tasks.length?'12':'0')+'px"><div style="height:100%;width:'+pct+'%;background:linear-gradient(90deg,'+acc+','+goldStrong()+');border-radius:4px;transition:width .5s"></div></div>'
      + f.tasks.map(function(t,i){
          return '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid '+hexA(br(),.5)+'">'
            + '<div onclick="foyerToggle('+i+')" style="width:22px;height:22px;border-radius:7px;border:2px solid '+(t.done?acc:hexA(acc,.3))+';background:'+(t.done?acc:'transparent')+';display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0">'+(t.done?'<span style="font-size:14px;color:#fff;font-weight:700">✓</span>':'')+'</div>'
            + '<span onclick="foyerToggle('+i+')" style="flex:1;font-size:16px;color:'+(t.done?tx2():tx())+';cursor:pointer;'+(t.done?'text-decoration:line-through;opacity:.6':'')+'">'+esc(t.label)+'</span>'
            + '<button onclick="foyerRemove('+i+')" style="background:none;border:none;color:'+hexA('#E57373',.7)+';font-size:14px;cursor:pointer">✕</button>'
          + '</div>';
        }).join('')
      + '<div style="display:flex;gap:6px;margin-top:10px">'
        + '<input id="FOYER_NEW" placeholder="Ajouter une tâche…" onkeydown="if(event.key===\'Enter\')foyerAdd()" style="flex:1;padding:10px 12px;border-radius:10px;border:1px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:16px;font-family:inherit;min-width:0">'
        + '<button onclick="foyerAdd()" style="width:44px;border-radius:10px;border:none;background:'+hexA(acc,.15)+';color:'+acc+';font-size:20px;cursor:pointer">+</button>'
      + '</div>'
      + (f.tasks.length===0 ? '<button onclick="foyerSeed()" style="width:100%;margin-top:8px;padding:9px;border-radius:10px;border:1px dashed '+hexA(acc,.5)+';background:transparent;color:'+acc+';font-size:14px;cursor:pointer;font-family:inherit">✨ Démarrer avec des tâches type</button>' : '')
    + '</div>';
  }

  return hdr('Gestion du foyer', '🏡 Bayt · Baraka', "N('quotidien')")
    + pills([['checklist','Mes tâches'],['baraka','Baraka du foyer']], tab, 'setFoyerTab')
    + '<div class="stagger" style="padding:12px 16px 24px">' + body + '</div>';
}
function setFoyerTab(t){ S.foyerTab = t; render(); }

