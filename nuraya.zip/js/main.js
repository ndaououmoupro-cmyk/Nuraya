(function() {
  // ── PWA : capter l'invite d'installation ──
  window.deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', function(e) {
    e.preventDefault();
    window.deferredPrompt = e;
    if (typeof render === 'function' && !S.locked) render();
  });
  window.addEventListener('appinstalled', function() {
    window.deferredPrompt = null;
    if (typeof toast === 'function') toast('Nûraya installée ✓');
  });
  window.isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  window.isStandalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;

  // ── Service Worker : coquille + API (Coran, tafsir, horaires) en cache pour le hors-ligne ──
  (function registerSW(){
    if (!('serviceWorker' in navigator)) return;
    if (location.protocol !== 'https:' && location.protocol !== 'http:') return; // ignoré en file://
    window.addEventListener('load', function(){
      navigator.serviceWorker.register('sw.js').then(function(reg){
        reg.addEventListener('updatefound', function(){
          var nw = reg.installing; if (!nw) return;
          nw.addEventListener('statechange', function(){
            if (nw.state === 'installed' && navigator.serviceWorker.controller) {
              if (typeof toast === 'function') toast('Nouvelle version prête ✓ — rouvre l\'app');
            }
          });
        });
      }).catch(function(){});
    });
  })();

  // ── Conscience de la connexion ──
  window.addEventListener('offline', function(){ if (typeof toast === 'function') toast('Hors-ligne — contenu déjà chargé disponible 🌙'); });
  window.addEventListener('online',  function(){ if (typeof toast === 'function') toast('De retour en ligne ✓'); });

  function tick() { var el = document.getElementById('SB_TIME'); if (el) el.textContent = nowTime(); }
  tick();
  setInterval(tick, 30000);
  setInterval(function() { if (!S.locked) save(); }, 30000);
  // V4 : PIN dès l'ouverture, toujours
  var consent = localStorage.getItem('nuraya_v1_consent');
  if (consent === 'true') { S.consentGiven = true; load(); }
  S.locked = true; // Toujours verrouillé au démarrage
  render();
  // Disparition élégante du splash
  setTimeout(function(){
    var sp = document.getElementById('SPLASH');
    if (sp) { sp.classList.add('hide'); setTimeout(function(){ if (sp.parentNode) sp.parentNode.removeChild(sp); }, 700); }
  }, 1250);
})();
