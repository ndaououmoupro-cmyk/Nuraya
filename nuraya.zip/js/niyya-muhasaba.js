// ═══════════════════════════════════════════════════════════════
// NIYYA DU JOUR & MUHÂSABA — le cœur spirituel de Nûraya
// Pose une intention le matin → l'app aligne verset, nom & dhikr.
// Le soir, un bilan guidé (muhâsaba). Tout reste privé, sur l'appareil.
// ═══════════════════════════════════════════════════════════════
var NIYYAT = [
  { id:'gratitude', e:'🌾', label:'Gratitude', ar:'الشُّكْر',
    intention:"Aujourd'hui, je veux remercier Allah pour Ses bienfaits.",
    asma:35, // Ash-Shakûr
    dhikr:{ ar:'الْحَمْدُ لِلَّهِ', tr:'Al-hamdu lillâh', fr:'Louange à Allah', count:33 },
    verse:{ ref:'Ibrâhîm 14:7', ar:'لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ', fr:'Si vous êtes reconnaissants, Je vous donnerai certes davantage.' },
    focus:"Note trois bienfaits, même petits : un repas, une respiration, un sourire." },
  { id:'patience', e:'🕊️', label:'Patience', ar:'الصَّبْر',
    intention:"Aujourd'hui, je veux accueillir les épreuves avec patience.",
    asma:99,
    dhikr:{ ar:'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيل', tr:'Hasbunâ Llâhu wa ni\u2018ma l-wakîl', fr:'Allah nous suffit, quel excellent garant', count:7 },
    verse:{ ref:'Al-Baqara 2:153', ar:'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ', fr:'Certes, Allah est avec les patients.' },
    focus:"Quand l'agacement monte, respire et dis : « Allah est avec les patients »." },
  { id:'pardon', e:'🤲', label:'Pardon', ar:'الْعَفْو',
    intention:"Aujourd'hui, je veux pardonner et demander le pardon.",
    asma:80,
    dhikr:{ ar:'أَسْتَغْفِرُ اللَّهَ', tr:'Astaghfiru Llâh', fr:'Je demande pardon à Allah', count:100 },
    verse:{ ref:'Az-Zumar 39:53', ar:'لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ', fr:'Ne désespérez pas de la miséricorde d\'Allah.' },
    focus:"Pense à une rancune à relâcher — pour ton cœur avant celui de l'autre." },
  { id:'confiance', e:'⚓', label:'Confiance (Tawakkul)', ar:'التَّوَكُّل',
    intention:"Aujourd'hui, je remets mes affaires à Allah et j'agis sereinement.",
    asma:52,
    dhikr:{ ar:'تَوَكَّلْتُ عَلَى اللَّهِ', tr:'Tawakkaltu \u2018alâ Llâh', fr:'Je place ma confiance en Allah', count:10 },
    verse:{ ref:'At-Talâq 65:3', ar:'وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ', fr:'Quiconque place sa confiance en Allah, Il lui suffit.' },
    focus:"Fais de ton mieux sur une tâche, puis confie le résultat à Allah." },
  { id:'humilite', e:'🌱', label:'Humilité', ar:'التَّوَاضُع',
    intention:"Aujourd'hui, je veux rester humble dans mes paroles et mes actes.",
    asma:4,
    dhikr:{ ar:'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', tr:'Subhâna Llâhi wa bi-hamdih', fr:'Gloire et louange à Allah', count:33 },
    verse:{ ref:'Al-Furqân 25:63', ar:'يَمْشُونَ عَلَى الْأَرْضِ هَوْنًا', fr:'Ils marchent sur terre avec humilité.' },
    focus:"Écoute plus que tu ne parles aujourd'hui ; offre une bonne parole." },
  { id:'amour', e:'💚', label:'Amour d\'Allah', ar:'الْمَحَبَّة',
    intention:"Aujourd'hui, je veux rapprocher mon cœur d'Allah par amour.",
    asma:47,
    dhikr:{ ar:'لَا إِلَهَ إِلَّا اللَّهُ', tr:'Lâ ilâha illâ Llâh', fr:'Nulle divinité sauf Allah', count:100 },
    verse:{ ref:'Al-Baqara 2:165', ar:'وَالَّذِينَ آمَنُوا أَشَدُّ حُبًّا لِّلَّهِ', fr:'Les croyants sont les plus ardents en amour pour Allah.' },
    focus:"Accomplis un acte d'adoration avec présence, pas par habitude." },
  { id:'science', e:'📘', label:'Apprendre (Ilm)', ar:'الْعِلْم',
    intention:"Aujourd'hui, je veux apprendre quelque chose qui me rapproche d'Allah.",
    asma:19,
    dhikr:{ ar:'رَبِّ زِدْنِي عِلْمًا', tr:'Rabbi zidnî \u2018ilmâ', fr:'Seigneur, accrois mon savoir', count:7 },
    verse:{ ref:'Tâ-Hâ 20:114', ar:'وَقُل رَّبِّ زِدْنِي عِلْمًا', fr:'Dis : Seigneur, accrois mon savoir.' },
    focus:"Lis un verset avec son tafsir, ou apprends un nom d'Allah." },
  { id:'generosite', e:'🫴', label:'Générosité', ar:'الْكَرَم',
    intention:"Aujourd'hui, je veux donner sans attendre de retour.",
    asma:16,
    dhikr:{ ar:'اللَّهُمَّ اجْعَلْنِي مِنَ الْكُرَمَاء', tr:'Allâhumma j\u2018alnî mina l-kuramâ\'', fr:'Ô Allah, fais de moi quelqu\'un de généreux', count:3 },
    verse:{ ref:'Al-Baqara 2:261', ar:'كَمَثَلِ حَبَّةٍ أَنبَتَتْ سَبْعَ سَنَابِلَ', fr:'À l\'image d\'un grain qui produit sept épis.' },
    focus:"Donne quelque chose aujourd'hui : un sourire, du temps, une aumône." },
];

// Bilan guidé du soir — concret
var MUHASABA_Q = [
  { id:'priers', q:'As-tu accompli tes cinq prières ?', type:'scale' },
  { id:'niyya',  q:'As-tu honoré ton intention du jour ?', type:'scale' },
  { id:'good',   q:'Une bonne action que tu as faite aujourd\'hui ?', type:'text' },
  { id:'improve',q:'Une chose à améliorer demain, in shâ\' Allah ?', type:'text' },
  { id:'grateful',q:'Pour quoi remercies-tu Allah ce soir ?', type:'text' },
];

function niyyaToday() { return salatToday(); }
function niyyaOf(id) { return NIYYAT.find(function(n){ return n.id === id; }) || null; }

function getJournal() {
  if (!S.profil.journal) S.profil.journal = {};
  return S.profil.journal;
}
function todayEntry() {
  var j = getJournal();
  if (!j[niyyaToday()]) j[niyyaToday()] = {};
  return j[niyyaToday()];
}

function setNiyya(id) {
  haptic('success');
  var e = todayEntry();
  e.niyya = id;
  e.niyyaTime = Date.now();
  computeNiyyaStreak();
  save();
  render();
}

function computeNiyyaStreak() {
  var j = getJournal();
  var streak = 0;
  var d = new Date();
  for (var i = 0; i < 400; i++) {
    var key = d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
    if (j[key] && j[key].niyya) { streak++; d.setDate(d.getDate()-1); }
    else if (i === 0) { d.setDate(d.getDate()-1); } // aujourd'hui pas encore fait : on regarde hier
    else break;
  }
  S.profil.niyyaStreak = streak;
  return streak;
}

function saveMuhasaba(id, val) {
  var e = todayEntry();
  if (!e.muhasaba) e.muhasaba = {};
  e.muhasaba[id] = val;
  e.muhasabaTime = Date.now();
  save();
}

// ─── Carte d'accueil contextuelle (matin → niyya, soir → muhâsaba) ───
// ─── Météo spirituelle du jour (bandeau vivant sur l'accueil) ───
function spiritualWeather() {
  var h = new Date().getHours();
  var phases = [
    { lo:4,  hi:7,  e:'🌅', t:'Aube bénie', d:'Le moment le plus béni — saisis la baraka du matin', grad:['#3A4A6E','#1A2A4E'] },
    { lo:7,  hi:12, e:'☀️', t:'Matinée', d:'Énergie et concentration — place tes tâches importantes', grad:['#C28A3E','#8A5E1E'] },
    { lo:12, hi:15, e:'🌤️', t:'Mi-journée', d:'Pense à la sieste (qaylûla) et au dhikr', grad:['#5E8AA8','#3A5E78'] },
    { lo:15, hi:18, e:'🌇', t:'Après-midi', d:'Le moment d\'\'Asr — recentre-toi avant le soir', grad:['#C2703E','#8A4A1E'] },
    { lo:18, hi:21, e:'🌆', t:'Soirée', d:'Maghrib & adhkâr du soir — le jour se referme en douceur', grad:['#7A4A6E','#4A2A4E'] },
    { lo:21, hi:24, e:'🌙', t:'Nuit', d:'Calme et invocations — prépare ton cœur au repos', grad:['#2A3A5E','#141E3A'] },
    { lo:0,  hi:4,  e:'✨', t:'Dernier tiers', d:'L\'heure du tahajjud — Allah descend au ciel le plus proche', grad:['#1E2A4E','#0E162E'] },
  ];
  var p = phases.find(function(x){ return h >= x.lo && h < x.hi; }) || phases[1];
  return '<div style="margin-top:14px;background:'+hexA('#F2E9D0',.1)+';border:1px solid '+hexA('#F2E9D0',.16)+';border-radius:15px;padding:11px 14px;display:flex;align-items:center;gap:12px">'
    + '<div style="font-size:30px;animation:floatY 4s ease-in-out infinite">'+p.e+'</div>'
    + '<div style="flex:1"><p style="font-size:16px;font-weight:700;color:#F2E9D0">'+p.t+'</p>'
    + '<p style="font-size:14px;color:'+hexA('#F2E9D0',.7)+';line-height:1.4">'+esc(p.d)+'</p></div>'
  + '</div>';
}

function homeNiyyaCard() {
  var e = todayEntry();
  var hour = new Date().getHours();
  var n = e.niyya ? niyyaOf(e.niyya) : null;

  if (!e.niyya) {
    return '<button onclick="N(\'niyya\')" style="width:100%;display:flex;align-items:center;gap:11px;background:linear-gradient(135deg,'+(S.dark?hexA(gold(),.12):hexA(gold(),.08))+','+bg2()+');border:1.5px solid '+gold()+';border-radius:16px;padding:13px 15px;margin:0 0 8px;cursor:pointer;font-family:inherit;text-align:left">'
      + '<span style="font-size:26px">🌅</span>'
      + '<div style="flex:1"><p style="font-size:14px;color:'+gold()+';letter-spacing:.07em;text-transform:uppercase;font-weight:700">Niyya du jour</p>'
      + '<p style="font-size:18px;font-weight:700;color:'+tx()+'">Quelle est ton intention aujourd\'hui ?</p></div>'
      + '<span style="font-size:18px;color:'+gold()+'">›</span>'
    + '</button>';
  }
  // Intention posée
  var hasMuhasaba = e.muhasaba && Object.keys(e.muhasaba).length > 0;
  if (hour >= 18 && !hasMuhasaba) {
    return '<button onclick="N(\'niyya\')" style="width:100%;display:flex;align-items:center;gap:11px;background:'+bg2()+';border:1.5px solid '+gold()+';border-radius:16px;padding:13px 15px;margin:0 0 8px;cursor:pointer;font-family:inherit;text-align:left">'
      + '<span style="font-size:26px">🌙</span>'
      + '<div style="flex:1"><p style="font-size:14px;color:'+gold()+';letter-spacing:.07em;text-transform:uppercase;font-weight:700">Muhâsaba du soir</p>'
      + '<p style="font-size:18px;font-weight:700;color:'+tx()+'">Fais le bilan de ta journée</p></div>'
      + '<span style="font-size:18px;color:'+gold()+'">›</span>'
    + '</button>';
  }
  return '<button onclick="N(\'niyya\')" style="width:100%;display:flex;align-items:center;gap:11px;background:'+bg2()+';border:1px solid '+br()+';border-radius:16px;padding:13px 15px;margin:0 0 8px;cursor:pointer;font-family:inherit;text-align:left">'
    + '<span style="font-size:26px">'+n.e+'</span>'
    + '<div style="flex:1"><p style="font-size:14px;color:'+tx2()+';letter-spacing:.07em;text-transform:uppercase">Mon intention · '+n.label+'</p>'
    + '<p style="font-size:17px;font-weight:600;color:'+tx()+';line-height:1.4">'+esc(n.intention)+'</p></div>'
  + '</button>';
}

function pageNiyya() {
  var e = todayEntry();
  var n = e.niyya ? niyyaOf(e.niyya) : null;
  var streak = S.profil.niyyaStreak || 0;

  // ── Pas encore d'intention : sélecteur ──
  if (!n) {
    return '<div style="padding:14px 16px 28px">'
      + '<div style="text-align:center;margin-bottom:16px">'
        + '<p style="font-size:44px">🌅</p>'
        + '<p style="font-size:26px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-top:4px">Ta niyya du jour</p>'
        + '<p style="font-size:17px;color:'+tx2()+';line-height:1.6;max-width:300px;margin:8px auto 0">L\'intention oriente toute action. Choisis le cap de ton cœur aujourd\'hui — Nûraya alignera ton verset, ton dhikr et ton nom d\'Allah.</p>'
      + '</div>'
      + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:9px">'
        + NIYYAT.map(function(it){
            return '<button onclick="setNiyya(\''+it.id+'\')" style="display:flex;flex-direction:column;align-items:flex-start;gap:4px;padding:14px;border-radius:15px;border:1.5px solid '+br()+';background:'+bg2()+';cursor:pointer;font-family:inherit;text-align:left;transition:all .2s">'
              + '<span style="font-size:28px">'+it.e+'</span>'
              + '<span style="font-size:17px;font-weight:700;color:'+tx()+'">'+it.label+'</span>'
              + '<span style="font-size:16px;color:'+gold()+';direction:rtl;font-family:Fraunces,Georgia,serif">'+it.ar+'</span>'
            + '</button>';
          }).join('')
      + '</div>'
      + (streak > 0 ? '<p style="text-align:center;font-size:15px;color:'+tx2()+';margin-top:16px">🔥 '+streak+' jour'+(streak>1?'s':'')+' d\'intentions consécutifs</p>' : '')
    + '</div>';
  }

  // ── Intention posée : tableau de bord du jour ──
  var asmaName = ASMA.find(function(a){ return a.n === n.asma; }) || ASMA[0];
  var hasMuhasaba = e.muhasaba && Object.keys(e.muhasaba).length > 0;

  return '<div style="padding:14px 16px 28px">'
    // Bandeau intention
    + '<div style="background:linear-gradient(150deg,'+activeTheme().grad[0]+','+activeTheme().grad[1]+');border-radius:18px;padding:18px;text-align:center;margin-bottom:12px;position:relative;overflow:hidden">'
      + '<p style="font-size:46px;margin-bottom:4px">'+n.e+'</p>'
      + '<p style="font-size:14px;color:'+'rgba(231,213,136,.75)'+';letter-spacing:.08em;text-transform:uppercase">Intention du jour</p>'
      + '<p style="font-size:22px;font-family:Fraunces,Georgia,serif;color:#F2F6EE;margin:2px 0">'+n.label+' · <span style="direction:rtl">'+n.ar+'</span></p>'
      + '<p style="font-size:17px;color:rgba(231,239,223,.85);line-height:1.5;margin-top:6px">'+esc(n.intention)+'</p>'
      + '<button onclick="changeNiyya()" style="margin-top:10px;background:'+hexA(gold(),.15)+';border:1px solid '+hexA(gold(),.3)+';color:#E7D588;font-size:14px;padding:5px 14px;border-radius:20px;cursor:pointer;font-family:inherit">Changer</button>'
    + '</div>'
    // Focus du jour
    + card('<p style="font-size:14px;font-weight:700;color:'+gold()+';letter-spacing:.07em;text-transform:uppercase;margin-bottom:5px">🎯 Ton focus aujourd\'hui</p><p style="font-size:17px;color:'+tx()+';line-height:1.6">'+esc(n.focus)+'</p>')
    // Verset assorti
    + card('<p style="font-size:14px;font-weight:700;color:'+gold()+';letter-spacing:.07em;text-transform:uppercase;margin-bottom:6px">📖 Verset du jour</p>'
        + '<p style="font-size:24px;font-family:Fraunces,Georgia,serif;direction:rtl;text-align:right;line-height:2;color:'+tx()+';margin-bottom:6px">'+n.verse.ar+'</p>'
        + '<p style="font-size:17px;color:'+tx2()+';line-height:1.6;font-style:italic">« '+esc(n.verse.fr)+' »</p>'
        + '<p style="font-size:15px;color:'+gold()+';margin-top:4px">— '+n.verse.ref+'</p>')
    // Nom d'Allah assorti
    + card('<p style="font-size:14px;font-weight:700;color:'+gold()+';letter-spacing:.07em;text-transform:uppercase;margin-bottom:6px">☾ Nom d\'Allah à méditer</p>'
        + '<div style="display:flex;align-items:center;gap:12px">'
          + '<div style="text-align:center;flex-shrink:0"><p style="font-size:26px;font-family:Fraunces,Georgia,serif;color:'+gold()+';direction:rtl">'+asmaName.ar+'</p><p style="font-size:16px;font-weight:700;color:'+tx()+'">'+asmaName.fr+'</p></div>'
          + '<p style="font-size:16px;color:'+tx2()+';line-height:1.55;flex:1">'+esc(asmaName.tr)+' — '+esc(asmaName.med)+'</p>'
        + '</div>')
    // Dhikr assorti (compteur)
    + card('<p style="font-size:14px;font-weight:700;color:'+gold()+';letter-spacing:.07em;text-transform:uppercase;margin-bottom:6px">📿 Dhikr du jour</p>'
        + '<div style="text-align:center">'
          + '<p style="font-size:26px;font-family:Fraunces,Georgia,serif;direction:rtl;color:'+tx()+';line-height:1.8">'+n.dhikr.ar+'</p>'
          + '<p style="font-size:16px;color:'+tx2()+';margin:2px 0 10px">'+esc(n.dhikr.tr)+' — '+esc(n.dhikr.fr)+'</p>'
          + '<div style="display:flex;align-items:center;justify-content:center;gap:14px">'
            + '<button onclick="niyyaDhikrTap(-1)" style="width:42px;height:42px;border-radius:50%;border:1.5px solid '+br()+';background:transparent;color:'+tx2()+';font-size:22px;cursor:pointer">−</button>'
            + '<div style="min-width:90px"><p style="font-size:34px;font-weight:700;color:'+gold()+';line-height:1">'+(e.niyyaDhikrCount||0)+'</p><p style="font-size:14px;color:'+tx2()+'">/ '+n.dhikr.count+'</p></div>'
            + '<button class="btn-gold" onclick="niyyaDhikrTap(1)" style="width:42px;height:42px;border-radius:50%;border:none;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');color:#FFFDF0;font-size:22px;cursor:pointer">+</button>'
          + '</div>'
        + '</div>')
    // Muhâsaba du soir
    + (hasMuhasaba
        ? card('<p style="font-size:14px;font-weight:700;color:'+gold()+';letter-spacing:.07em;text-transform:uppercase;margin-bottom:7px">🌙 Ton bilan de ce soir</p>'
            + MUHASABA_Q.map(function(q){
                var v = e.muhasaba[q.id];
                if (v == null || v === '') return '';
                var disp = q.type === 'scale' ? ['—','Pas encore','En partie','Oui, al-hamdulillah'][v] || v : esc(v);
                return '<div style="margin-bottom:7px"><p style="font-size:14px;color:'+tx2()+'">'+esc(q.q)+'</p><p style="font-size:16px;color:'+tx()+';font-weight:500">'+disp+'</p></div>';
              }).join('')
            + '<button onclick="S.muhasabaEdit=true;render()" style="margin-top:4px;background:none;border:none;color:'+gold()+';font-size:15px;cursor:pointer;font-family:inherit;text-decoration:underline">Modifier</button>')
        : (new Date().getHours() >= 15 || S.muhasabaEdit
            ? muhasabaForm(e)
            : card('<div style="text-align:center;padding:6px 0"><p style="font-size:30px">🌙</p><p style="font-size:17px;font-weight:700;color:'+tx()+';margin-top:4px">Muhâsaba du soir</p><p style="font-size:15px;color:'+tx2()+';margin-top:4px">Le bilan guidé t\'attend en fin de journée. Reviens ce soir, in shâ\' Allah.</p><button onclick="S.muhasabaEdit=true;render()" style="margin-top:10px;background:none;border:1px solid '+br()+';color:'+gold()+';font-size:15px;padding:7px 16px;border-radius:11px;cursor:pointer;font-family:inherit">Faire le bilan maintenant</button></div>')))
    + (streak > 0 ? '<p style="text-align:center;font-size:15px;color:'+tx2()+';margin-top:14px">🔥 '+streak+' jour'+(streak>1?'s':'')+' d\'intentions · ton journal reste privé sur cet appareil</p>' : '')
  + '</div>';
}

function muhasabaForm(e) {
  return '<div style="background:'+bg2()+';border:1.5px solid '+gold()+';border-radius:16px;padding:15px;margin-bottom:8px">'
    + '<p style="font-size:18px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-bottom:3px">🌙 Muhâsaba du soir</p>'
    + '<p style="font-size:15px;color:'+tx2()+';margin-bottom:12px">Un examen bienveillant — pas de jugement, juste de la conscience.</p>'
    + MUHASABA_Q.map(function(q){
        var cur = (e.muhasaba && e.muhasaba[q.id] != null) ? e.muhasaba[q.id] : (q.type==='scale'?0:'');
        if (q.type === 'scale') {
          return '<div style="margin-bottom:13px"><p style="font-size:16px;color:'+tx()+';margin-bottom:6px">'+esc(q.q)+'</p>'
            + '<div style="display:flex;gap:5px">'
              + ['Pas encore','En partie','Oui ✓'].map(function(lbl,i){
                  var val = i+1; var on = cur === val;
                  return '<button onclick="saveMuhasaba(\''+q.id+'\','+val+');render()" style="flex:1;padding:8px;border-radius:10px;border:1.5px solid '+(on?gold():br())+';background:'+(on?(S.dark?hexA(gold(),.12):'rgba(122,106,30,.07)'):'transparent')+';color:'+(on?gold():tx2())+';font-size:14px;font-weight:'+(on?'700':'400')+';cursor:pointer;font-family:inherit">'+lbl+'</button>';
                }).join('')
            + '</div></div>';
        }
        return '<div style="margin-bottom:13px"><p style="font-size:16px;color:'+tx()+';margin-bottom:6px">'+esc(q.q)+'</p>'
          + '<textarea oninput="saveMuhasaba(\''+q.id+'\',this.value)" placeholder="Écris librement…" rows="2" style="width:100%;padding:10px 12px;border-radius:11px;border:1.5px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:16px;font-family:inherit;box-sizing:border-box;resize:vertical">'+esc(cur)+'</textarea></div>';
      }).join('')
    + '<button class="btn-gold" onclick="S.muhasabaEdit=false;toast(\'Bilan enregistré · qu\\\'Allah agrée 🌙\');render()" style="width:100%;padding:12px;border-radius:12px;border:none;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');color:#FFFDF0;font-size:16px;font-weight:700;cursor:pointer;font-family:inherit;margin-top:4px">Enregistrer mon bilan</button>'
  + '</div>';
}

function changeNiyya() {
  var e = todayEntry();
  e.niyya = null;
  save();
  render();
}

function niyyaDhikrTap(d) {
  var e = todayEntry();
  var n = niyyaOf(e.niyya);
  if (!n) return;
  var before = e.niyyaDhikrCount||0;
  e.niyyaDhikrCount = Math.max(0, Math.min(n.dhikr.count, before + d));
  save();
  if (e.niyyaDhikrCount === n.dhikr.count && d > 0) { haptic('celebrate'); toast('Dhikr complété · barak Allâhu fîk 🌿'); }
  else if (d > 0 && e.niyyaDhikrCount !== before) haptic('soft');
  render();
}


var HAJJ_DATA = {
  def: "Le Hajj (الحَجّ) est le 5ème pilier de l'Islam. Obligatoire une fois dans la vie pour tout musulman libre, adulte, sain d'esprit et qui en a les moyens.",
  verset: {ar:"وَلِلَّهِ عَلَى النَّاسِ حِجُّ الْبَيْتِ مَنِ اسْتَطَاعَ إِلَيْهِ سَبِيلًا", fr:"Et c'est un devoir envers Allah pour les hommes de faire le pèlerinage de la Maison — pour celui qui en a la capacité.", ref:"Al-Imran 3:97"},
  etapes: [
    {num:1, nom:'Ihrâm', ar:'الإحرام', desc:"Vêtements blancs non cousus (hommes). Niyyah + Talbiya. Début des interdits : parfums, rapports conjugaux, chasse, taille ongles/cheveux.", lieu:"Mîqât"},
    {num:2, nom:'Tawâf', ar:'الطَّوَاف', desc:"7 tours autour de la Ka'ba dans le sens anti-horaire. Commencer par la Pierre Noire (Hajr al-Aswad). Dire Bismillah, Allahu Akbar.", lieu:'Masjid al-Haram'},
    {num:3, nom:"Sa'y", ar:'السَّعي', desc:"7 allers-retours entre Safâ et Marwâ. Commémoration de Hâjar cherchant de l'eau pour Ismaïl. Distance ~450m par passage.", lieu:'Al-Mas\'â'},
    {num:4, nom:'Wuqûf', ar:'الوُقُوف', desc:"Séjour à 'Arafat — LE pilier du Hajj. Le 9 Dhu l-Hijja après le Dhohr jusqu'au coucher du soleil. Dua, pleurs, repentir.", lieu:"'Arafat"},
    {num:5, nom:'Muzdalifa', ar:'مُزدَلِفَة', desc:"Nuit à Muzdalifa après 'Arafat. Prière Maghrib + Icha combinées. Collecte de cailloux pour la lapidation.", lieu:'Muzdalifa'},
    {num:6, nom:'Lapidation', ar:'رَمي الجَمَرات', desc:"Lancer 7 cailloux à Jamarat al-Aqaba le 10 Dhu l-Hijja (Aïd al-Adha). Symbolise le rejet de Satan. Dire Allahu Akbar à chaque jet.", lieu:'Minâ'},
    {num:7, nom:"Sacrifice + Rasage", ar:'الذَّبح والحَلق', desc:"Sacrifice d'un animal (mouton, chèvre, vache) si possible. Puis se raser/couper les cheveux. Fin de la plupart des interdits.", lieu:'Minâ'},
    {num:8, nom:'Tawâf al-Ifâda', ar:'طواف الإفاضة', desc:"Tawâf obligatoire après Muzdalifa. 7 tours autour de la Ka'ba. Fin des interdits restants.", lieu:'Masjid al-Haram'},
    {num:9, nom:"Retour à Minâ", ar:'البَيتوتَة', desc:"Nuits 11 et 12 Dhu l-Hijja à Minâ. Lapidation des 3 Jamarat chaque jour (7+7+7 cailloux). Option de partir après le 12 ou rester jusqu'au 13.", lieu:'Minâ'},
    {num:10, nom:'Tawâf de congé', ar:'طواف الوَداع', desc:"Dernier Tawâf avant de quitter La Mecque. 7 tours. Dernier regard sur la Ka'ba.", lieu:'Masjid al-Haram'},
  ],
  dua_arafat: {ar:"اللَّهُمَّ لَكَ الْحَمْدُ كَالَّذِي تَقُولُ وَخَيْراً مِمَّا نَقُولُ", fr:"Ô Allah, à Toi la louange comme Tu la dis et mieux que ce que nous pouvons dire."},
  talbiya: {ar:"لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لاَ شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لاَ شَرِيكَ لَكَ", fr:"Me voilà, ô Allah, me voilà. Me voilà, Tu n'as pas d'associé. La louange, la grâce et la royauté T'appartiennent. Tu n'as pas d'associé."},
};


