// ═══════════════════════════════════════════════════════════════
// ORGANISATION & ÉQUILIBRE — pensé pour la charge mentale
// Roue de l'équilibre dîn/quotidien + priorités douces + rappel
// ═══════════════════════════════════════════════════════════════
var EQUILIBRE_AXES = [
  { id:'spi',  e:'🕌', label:'Spiritualité', q:"Prières, Coran, dhikr, lien avec Allah" },
  { id:'corps',e:'🌿', label:'Corps & repos', q:"Sommeil, alimentation, mouvement" },
  { id:'foyer',e:'🏡', label:'Foyer',         q:"Maison, organisation, repas" },
  { id:'liens',e:'💝', label:'Liens',         q:"Famille, époux, amitiés, silat ar-rahim" },
  { id:'soi',  e:'🌸', label:'Moi',           q:"Repos mental, plaisir, ressourcement" },
  { id:'ilm',  e:'📚', label:'Savoir',        q:"Apprendre, lire, se former" },
];

function equilibreData() {
  if (!S.profil.equilibre) S.profil.equilibre = {};
  return S.profil.equilibre;
}
function setEquilibre(id, val) { equilibreData()[id] = val; save(); render(); }

function pageOrga() {
  var acc = gold();
  var tab = S.orgaTab || 'equilibre';
  var body = '';

  if (tab === 'equilibre') {
    var eq = equilibreData();
    body = '<p style="font-size:16px;color:'+tx2()+';line-height:1.7;margin-bottom:14px">Comment te sens-tu dans chaque domaine aujourd\'hui ? Sans jugement — juste pour voir où mettre de la douceur. L\'équilibre n\'est pas la perfection.</p>'
      + EQUILIBRE_AXES.map(function(a){
          var v = eq[a.id] || 0;
          return '<div style="background:'+bg2()+';border:1px solid '+br()+';border-radius:14px;padding:13px 15px;margin-bottom:9px">'
            + '<div style="display:flex;align-items:center;gap:9px;margin-bottom:8px"><span style="font-size:23px">'+a.e+'</span>'
            + '<div style="flex:1"><p style="font-size:17px;font-weight:700;color:'+tx()+'">'+a.label+'</p><p style="font-size:13px;color:'+tx2()+'">'+esc(a.q)+'</p></div></div>'
            + '<div style="display:flex;gap:6px">'
              + [1,2,3,4,5].map(function(n){
                  var on = v >= n;
                  return '<button onclick="setEquilibre(\''+a.id+'\','+n+')" style="flex:1;height:30px;border-radius:8px;border:1px solid '+(on?acc:br())+';background:'+(on?hexA(acc,.18):'transparent')+';cursor:pointer;font-size:13px;color:'+(on?acc:tx2())+'">'+(on?'●':'○')+'</button>';
                }).join('')
            + '</div>'
          + '</div>';
        }).join('')
      + (function(){
          var filled = EQUILIBRE_AXES.filter(function(a){return eq[a.id];});
          if (!filled.length) return '';
          var low = EQUILIBRE_AXES.filter(function(a){return eq[a.id] && eq[a.id]<=2;});
          if (!low.length) return '<div style="background:'+hexA(acc,.08)+';border:1px solid '+hexA(acc,.25)+';border-radius:14px;padding:13px;text-align:center;margin-top:4px"><p style="font-size:16px;color:'+tx()+'">🌟 Bel équilibre, ma\'sha\'Allah. Continue ainsi avec douceur.</p></div>';
          return '<div style="background:'+hexA(acc,.08)+';border:1px solid '+hexA(acc,.25)+';border-radius:14px;padding:13px;margin-top:4px"><p style="font-size:15px;color:'+tx()+';line-height:1.6">🌷 Aujourd\'hui, accorde un peu d\'attention à : <b>'+low.map(function(a){return a.label;}).join(', ')+'</b>. Un petit pas suffit — Allah aime les actes constants même petits.</p></div>';
        })();
  } else if (tab === 'priorites') {
    body = '<div style="background:'+hexA(acc,.07)+';border:1px solid '+hexA(acc,.2)+';border-radius:14px;padding:13px 15px;margin-bottom:12px">'
      + '<p style="font-size:17px;direction:rtl;font-family:Amiri,serif;color:'+tx()+';text-align:center;line-height:2">الْمُؤْمِنُ الْقَوِيُّ خَيْرٌ</p>'
      + '<p style="font-size:15px;color:'+tx2()+';text-align:center;font-style:italic;margin-top:4px">« Le croyant fort est meilleur et plus aimé d\'Allah que le faible. » (Muslim 2664)</p></div>'
      + [
          ['🤍','Allège ta charge mentale',"Écris ce qui t\'encombre l\'esprit — sortir les pensées de la tête libère le cœur. Une seule priorité par demi-journée suffit."],
          ['🕊️','Le principe du suffisant',"« Fais ce que tu peux. » Allah ne charge une âme qu\'à sa capacité (2:286). Le \'assez bien\' fait régulièrement vaut mieux que le parfait abandonné."],
          ['⏳','Les temps bénis',"Place tes tâches importantes après Fajr (baraka du matin) et tes moments de repos en milieu d\'après-midi (qaylûla, sieste sunna)."],
          ['🌙','Le droit de ton corps',"« Ton corps a un droit sur toi. » (Bukhârî 5199) Le repos n\'est pas une paresse : c\'est une \'ibâda quand l\'intention est de mieux servir."],
          ['💞','Déléguer sans culpabilité',"Demander de l\'aide n\'est pas un échec. Le Prophète ﷺ aidait au foyer (Bukhârî 676). Partage la charge."],
        ].map(function(p){
          return '<div style="background:'+bg2()+';border:1px solid '+br()+';border-radius:14px;padding:13px 15px;margin-bottom:8px;display:flex;gap:12px">'
            + '<span style="font-size:26px;flex-shrink:0">'+p[0]+'</span>'
            + '<div><p style="font-size:17px;font-weight:700;color:'+tx()+'">'+esc(p[1])+'</p>'
            + '<p style="font-size:15px;color:'+tx2()+';line-height:1.55;margin-top:2px">'+esc(p[2])+'</p></div>'
          + '</div>';
        }).join('');
  }

  return hdr('Organisation & équilibre', '🌸 Charge mentale · Dîn & quotidien', "N('quotidien')")
    + pills([['equilibre','Ma roue d\'équilibre'],['priorites','Sérénité & priorités']], tab, 'setOrgaTab')
    + '<div class="stagger" style="padding:12px 16px 24px">' + body + '</div>';
}
function setOrgaTab(t){ S.orgaTab = t; render(); }

// ═══════════════════════════════════════════════════════════════
// SUIVI DES COURS DE SCIENCES RELIGIEUSES — matières, progression, ijazah
// ═══════════════════════════════════════════════════════════════
function coursData() {
  if (!S.profil.cours) S.profil.cours = [];
  return S.profil.cours;
}
function coursAdd() {
  var n = document.getElementById('COURS_NOM'), p = document.getElementById('COURS_PROF');
  var nom = (n && n.value || '').trim();
  if (!nom) { toast('Donne un nom à la matière'); return; }
  coursData().push({
    nom: nom.slice(0,40),
    prof: (p && p.value || '').trim().slice(0,30),
    progress: 0,
    notes: '',
    ijazah: false,
    next: ''
  });
  save(); render();
}
function coursRemove(i){ if(confirm('Supprimer cette matière ?')){ coursData().splice(i,1); save(); render(); } }
function coursFill(s){ var el=document.getElementById('COURS_NOM'); if(el) el.value=s; }
function coursField(i, f, v){ coursData()[i][f] = v; save(); }
function coursProgress(i, d){ var c=coursData()[i]; c.progress=Math.max(0,Math.min(100,(c.progress||0)+d)); save(); render(); }
function coursToggleIjazah(i){ var c=coursData()[i]; c.ijazah=!c.ijazah; if(c.ijazah)haptic('celebrate'); save(); render(); }

var COURS_SUGGEST = ['Aqîda','Fiqh','Tajwîd','Tafsîr','Hadîth','Sîra','Arabe','Nahw (grammaire)','Usûl al-Fiqh','Mémorisation Coran'];

function pageCours() {
  var acc = gold();
  var list = coursData();
  var edit = !!S.coursEdit;

  var body = '';
  if (!list.length) {
    body = '<div style="text-align:center;padding:24px 10px">'
      + '<p style="font-size:46px">📖</p>'
      + '<p style="font-size:20px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-top:6px">Tes cours de sciences religieuses</p>'
      + '<p style="font-size:16px;color:'+tx2()+';line-height:1.6;max-width:300px;margin:8px auto 0">Suis tes matières, ta progression et tes ijâzât en un seul endroit. Ajoute ta première matière.</p>'
    + '</div>';
  } else {
    body = list.map(function(c, i){
      return '<div style="background:'+bg2()+';border:1px solid '+(c.ijazah?hexA(acc,.4):br())+';border-radius:16px;padding:14px;margin-bottom:10px;position:relative;overflow:hidden">'
        + (c.ijazah ? '<div style="position:absolute;right:-8px;top:-8px;pointer-events:none">'+ornStar(50, acc, .12)+'</div>' : '')
        + '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">'
          + '<div style="flex:1"><p style="font-size:19px;font-weight:700;color:'+tx()+';font-family:Fraunces,Georgia,serif">'+esc(c.nom)+(c.ijazah?' <span style="font-size:15px">🎓</span>':'')+'</p>'
          + (c.prof?'<p style="font-size:14px;color:'+tx2()+'">avec '+esc(c.prof)+'</p>':'')+'</div>'
          + '<button onclick="coursRemove('+i+')" style="background:none;border:none;color:'+hexA('#E57373',.7)+';font-size:15px;cursor:pointer;padding:2px 6px">✕</button>'
        + '</div>'
        // progression
        + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:9px">'
          + '<button onclick="coursProgress('+i+',-10)" style="width:30px;height:30px;border-radius:8px;border:1px solid '+br()+';background:transparent;color:'+tx2()+';font-size:16px;cursor:pointer">−</button>'
          + '<div style="flex:1;height:9px;background:'+hexA(activeTheme().bx,.1)+';border-radius:5px;overflow:hidden"><div style="height:100%;width:'+(c.progress||0)+'%;background:linear-gradient(90deg,'+acc+','+goldStrong()+');border-radius:5px;transition:width .4s"></div></div>'
          + '<button onclick="coursProgress('+i+',10)" style="width:30px;height:30px;border-radius:8px;border:1px solid '+br()+';background:transparent;color:'+tx2()+';font-size:16px;cursor:pointer">+</button>'
          + '<span style="font-size:15px;font-weight:700;color:'+acc+';min-width:38px;text-align:right">'+(c.progress||0)+'%</span>'
        + '</div>'
        // prochaine séance + ijazah
        + '<div style="display:flex;gap:7px;align-items:center">'
          + '<input value="'+esc(c.next||'')+'" oninput="coursField('+i+',\'next\',this.value)" placeholder="📅 Prochaine séance / objectif…" style="flex:1;padding:8px 11px;border-radius:10px;border:1px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:15px;font-family:inherit;min-width:0">'
          + '<button onclick="coursToggleIjazah('+i+')" title="Ijâza obtenue" style="padding:8px 12px;border-radius:10px;border:1px solid '+(c.ijazah?acc:br())+';background:'+(c.ijazah?hexA(acc,.15):'transparent')+';color:'+(c.ijazah?acc:tx2())+';font-size:15px;cursor:pointer;white-space:nowrap;font-family:inherit">🎓</button>'
        + '</div>'
      + '</div>';
    }).join('');
  }

  // formulaire d'ajout
  body += '<div style="border:1.5px dashed '+hexA(acc,.5)+';border-radius:14px;padding:13px;margin-top:4px">'
    + '<p style="font-size:14px;font-weight:700;color:'+acc+';letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">＋ Nouvelle matière</p>'
    + '<input id="COURS_NOM" placeholder="Matière (ex. Tajwîd)" maxlength="40" style="width:100%;padding:10px 12px;border-radius:10px;border:1px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:16px;font-family:inherit;box-sizing:border-box;margin-bottom:6px">'
    + '<input id="COURS_PROF" placeholder="Professeur / institut (optionnel)" maxlength="30" style="width:100%;padding:10px 12px;border-radius:10px;border:1px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:16px;font-family:inherit;box-sizing:border-box;margin-bottom:6px">'
    + '<div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px">'
      + COURS_SUGGEST.map(function(s){ return '<button onclick="coursFill('+JSON.stringify(s)+')" style="padding:4px 10px;border-radius:14px;border:1px solid '+br()+';background:transparent;color:'+tx2()+';font-size:13px;cursor:pointer;font-family:inherit">'+s+'</button>'; }).join('')
    + '</div>'
    + '<button onclick="coursAdd()" style="width:100%;padding:11px;border-radius:11px;border:none;background:linear-gradient(150deg,'+acc+','+goldStrong()+');color:#FFFDF0;font-size:16px;font-weight:700;cursor:pointer;font-family:inherit">Ajouter la matière</button>'
  + '</div>';

  return hdr('Mes cours religieux', '📖 Talab al-\u2018ilm · Suivi', "N('apprendre')")
    + '<div class="stagger" style="padding:12px 16px 24px">'
      + (list.length ? '<p style="font-size:14px;color:'+tx2()+';margin-bottom:10px">'+list.length+' matière'+(list.length>1?'s':'')+' · '+list.filter(function(c){return c.ijazah;}).length+' ijâza'+(list.filter(function(c){return c.ijazah;}).length>1?'t':'')+' 🎓</p>' : '')
      + body
      + '<p style="text-align:center;font-size:14px;color:'+tx2()+';opacity:.75;margin-top:12px;direction:rtl;font-family:Amiri,serif">مَن سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللهُ لَهُ طَرِيقًا إِلَى الجَنَّةِ</p>'
      + '<p style="text-align:center;font-size:13px;color:'+tx2()+';opacity:.6;line-height:1.5">« Qui emprunte un chemin pour y chercher une science, Allah lui facilite un chemin vers le Paradis. » (Muslim 2699)</p>'
    + '</div>';
}

