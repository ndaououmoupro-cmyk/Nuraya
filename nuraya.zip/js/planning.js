// ─── PLANNING JOURNÉE ───────────────────────────────────────────
var PRAYER_SCHEDULE = null;
var PRAYER_LOADING = false;





// ═══════════════════════════════════════════════════════════════
// PLANNING PERSONNALISÉ — l'utilisateur compose sa journée
// Modèles prêts OU page blanche · blocs avec horaire + tâches
// Données privées, sur l'appareil.
// ═══════════════════════════════════════════════════════════════
var PLANNING_TEMPLATES = {
  etudiante: {
    nom:'Étudiante en sciences', emoji:'📚',
    blocks:[
      {time:'05:30', icon:'🌄', titre:'Fajr & matin béni', tasks:['Prière Fajr','Adhkâr du matin','Récitation Coran']},
      {time:'08:00', icon:'📖', titre:'Cours / Halaqa', tasks:['Mémorisation','Prise de notes','Questions au cheikh']},
      {time:'12:30', icon:'🌞', titre:'Dhuhr & pause', tasks:['Prière Dhuhr','Déjeuner','Repos (qaylûla)']},
      {time:'14:00', icon:'✍️', titre:'Révisions', tasks:['Relecture des cours','Murâja\u2018a du hifz','Exercices']},
      {time:'18:00', icon:'🌆', titre:'Maghrib & soir', tasks:['Prière Maghrib','Adhkâr du soir','Dîner en famille']},
      {time:'20:30', icon:'🌙', titre:'Isha & clôture', tasks:['Prière Isha','Lecture légère','Sommeil tôt']},
    ]
  },
  foyer: {
    nom:'Gestion du foyer', emoji:'🏡',
    blocks:[
      {time:'05:30', icon:'🌄', titre:'Fajr & lever', tasks:['Prière Fajr','Adhkâr du matin','Préparer le petit-déjeuner']},
      {time:'08:00', icon:'🧹', titre:'Foyer du matin', tasks:['Rangement','Lessive','Aération des pièces']},
      {time:'12:30', icon:'🍲', titre:'Dhuhr & repas', tasks:['Prière Dhuhr','Cuisine du déjeuner','Repos']},
      {time:'15:00', icon:'👶', titre:'Famille & soin', tasks:['Temps avec les enfants','Lecture du Coran ensemble','Tâches légères']},
      {time:'18:00', icon:'🌆', titre:'Maghrib & dîner', tasks:['Prière Maghrib','Préparer le dîner','Adhkâr du soir']},
      {time:'21:00', icon:'🌙', titre:'Isha & repos', tasks:['Prière Isha','Rangement final','Du\u2018â avant de dormir']},
    ]
  },
  active: {
    nom:'Vie active', emoji:'💼',
    blocks:[
      {time:'06:00', icon:'🌄', titre:'Fajr & départ', tasks:['Prière Fajr','Adhkâr du matin','Petit-déjeuner']},
      {time:'09:00', icon:'💼', titre:'Travail / Études', tasks:['Tâches prioritaires','Pause dhikr','Concentration']},
      {time:'13:00', icon:'🌞', titre:'Dhuhr & pause', tasks:['Prière Dhuhr','Déjeuner','Marche']},
      {time:'17:00', icon:'🌇', titre:'Asr & retour', tasks:['Prière Asr','Trajet','Détente']},
      {time:'19:30', icon:'🌆', titre:'Maghrib & maison', tasks:['Prière Maghrib','Dîner','Famille']},
      {time:'21:30', icon:'🌙', titre:'Isha & soir', tasks:['Prière Isha','Lecture','Sommeil']},
    ]
  },
};

function planData() {
  if (!S.profil.planning) S.profil.planning = null; // null = pas encore configuré
  return S.profil.planning;
}
function planSetTemplate(key) {
  var t = PLANNING_TEMPLATES[key];
  S.profil.planning = {
    name: t ? t.nom : 'Mon planning',
    blocks: t ? JSON.parse(JSON.stringify(t.blocks)) : []
  };
  S.planEdit = !t; // page blanche → ouvre l'édition direct
  save(); render();
}
function planBlank() {
  S.profil.planning = { name:'Mon planning', blocks:[] };
  S.planEdit = true;
  save(); render();
}
function planReset() {
  if (confirm('Recommencer ton planning ? (les blocs actuels seront effacés)')) {
    S.profil.planning = null; S.planEdit = false; save(); render();
  }
}
function planAddBlock() {
  var p = planData(); if (!p) return;
  p.blocks.push({ time:'12:00', icon:'⭐', titre:'Nouveau moment', tasks:[] });
  p.blocks.sort(function(a,b){ return a.time.localeCompare(b.time); });
  save(); render();
}
function planRemoveBlock(i) {
  planData().blocks.splice(i,1); save(); render();
}
function planEditField(i, field, val) {
  planData().blocks[i][field] = val; save();
}
function planSortBlocks() {
  planData().blocks.sort(function(a,b){ return a.time.localeCompare(b.time); });
  save(); render();
}
function planAddTask(i) {
  var el = document.getElementById('PLAN_T_'+i);
  var v = (el && el.value || '').trim();
  if (!v) return;
  planData().blocks[i].tasks.push(v);
  save(); render();
}
function planRemoveTask(i, j) {
  planData().blocks[i].tasks.splice(j,1); save(); render();
}
function planToggleTask(i, j) {
  if (!S.profil.planDone) S.profil.planDone = {};
  var key = salatToday()+'_'+i+'_'+j;
  S.profil.planDone[key] = !S.profil.planDone[key];
  save(); render();
}
function planIsDone(i, j) {
  return S.profil.planDone && S.profil.planDone[salatToday()+'_'+i+'_'+j];
}

function pagePlanning() {
  var p = planData();
  var acc = gold();

  // ── Écran de choix initial ──
  if (!p) {
    return hdr('Mon planning', 'Compose ta journée idéale', "N('quotidien')")
      + '<div class="stagger" style="padding:14px 16px 24px">'
        + '<div style="text-align:center;margin-bottom:6px">'
          + '<p style="font-size:46px">🗓️</p>'
          + '<p style="font-size:21px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-top:4px">Crée ton planning</p>'
          + '<p style="font-size:16px;color:'+tx2()+';line-height:1.6;max-width:300px;margin:8px auto 0">Pars d\'un modèle adapté à ton rythme, ou compose tout toi-même. Tu pourras tout modifier ensuite.</p>'
        + '</div>'
        + ornSep()
        + '<p style="font-size:13px;color:'+tx2()+';font-weight:700;letter-spacing:.12em;text-transform:uppercase;margin-bottom:9px">Partir d\'un modèle</p>'
        + Object.keys(PLANNING_TEMPLATES).map(function(key){
            var t = PLANNING_TEMPLATES[key];
            return '<button class="press" onclick="planSetTemplate(\''+key+'\')" style="width:100%;display:flex;align-items:center;gap:13px;background:'+bg2()+';border:1px solid '+br()+';border-radius:16px;padding:14px 15px;margin-bottom:9px;cursor:pointer;text-align:left">'
              + '<div style="background:'+hexA(acc,.1)+';border:1px solid '+hexA(acc,.2)+';border-radius:13px;width:48px;height:48px;display:flex;align-items:center;justify-content:center;font-size:25px;flex-shrink:0">'+t.emoji+'</div>'
              + '<div style="flex:1"><p style="font-size:18px;font-weight:700;color:'+tx()+';font-family:Fraunces,Georgia,serif">'+t.nom+'</p>'
              + '<p style="font-size:14px;color:'+tx2()+'">'+t.blocks.length+' moments · '+t.blocks.reduce(function(n,b){return n+b.tasks.length;},0)+' tâches</p></div>'
              + '<span style="color:'+acc+';font-size:18px">›</span>'
            + '</button>';
          }).join('')
        + ornSep()
        + '<button class="press" onclick="planBlank()" style="width:100%;display:flex;align-items:center;gap:13px;background:transparent;border:1.5px dashed '+hexA(acc,.5)+';border-radius:16px;padding:14px 15px;cursor:pointer;text-align:left">'
          + '<div style="border-radius:13px;width:48px;height:48px;display:flex;align-items:center;justify-content:center;font-size:25px;flex-shrink:0;color:'+acc+'">✏️</div>'
          + '<div style="flex:1"><p style="font-size:18px;font-weight:700;color:'+tx()+';font-family:Fraunces,Georgia,serif">Page blanche</p>'
          + '<p style="font-size:14px;color:'+tx2()+'">Compose ta journée de zéro</p></div>'
          + '<span style="color:'+acc+';font-size:18px">›</span>'
        + '</button>'
      + '</div>';
  }

  // ── Planning configuré ──
  var edit = !!S.planEdit;
  var content = '';

  // Barre d'actions
  content += '<div style="display:flex;gap:8px;margin-bottom:12px">'
    + '<button class="press" onclick="S.planEdit='+(edit?'false':'true')+';render()" style="flex:1;padding:10px;border-radius:12px;border:1.5px solid '+(edit?acc:br())+';background:'+(edit?hexA(acc,.1):bg2())+';color:'+(edit?acc:tx())+';font-size:15px;font-weight:700;cursor:pointer;font-family:inherit">'+(edit?'✓ Terminer':'✏️ Modifier')+'</button>'
    + '<button class="press" onclick="planReset()" style="padding:10px 14px;border-radius:12px;border:1.5px solid '+br()+';background:'+bg2()+';color:'+tx2()+';font-size:15px;cursor:pointer;font-family:inherit">↺</button>'
  + '</div>';

  if (!p.blocks.length) {
    content += '<div style="text-align:center;padding:30px 10px"><p style="font-size:40px">📋</p><p style="font-size:17px;color:'+tx2()+';margin-top:8px">Ton planning est vide.<br>Ajoute ton premier moment ci-dessous.</p></div>';
  }

  p.blocks.forEach(function(b, i){
    if (edit) {
      // Mode édition
      content += '<div style="background:'+bg2()+';border:1.5px solid '+hexA(acc,.3)+';border-radius:16px;padding:13px;margin-bottom:10px">'
        + '<div style="display:flex;gap:8px;align-items:center;margin-bottom:9px">'
          + '<input value="'+esc(b.icon)+'" maxlength="3" onchange="planEditField('+i+',\'icon\',this.value)" style="width:48px;padding:8px;border-radius:10px;border:1px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:20px;text-align:center;font-family:inherit">'
          + '<input type="time" value="'+esc(b.time)+'" onchange="planEditField('+i+',\'time\',this.value);planSortBlocks()" style="padding:8px;border-radius:10px;border:1px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:15px;font-family:inherit">'
          + '<button onclick="planRemoveBlock('+i+')" style="margin-left:auto;width:36px;height:36px;border-radius:10px;border:1px solid '+hexA('#E57373',.4)+';background:'+hexA('#E57373',.08)+';color:#E57373;font-size:15px;cursor:pointer">✕</button>'
        + '</div>'
        + '<input value="'+esc(b.titre)+'" onchange="planEditField('+i+',\'titre\',this.value)" placeholder="Titre du moment" style="width:100%;padding:9px 11px;border-radius:10px;border:1px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:16px;font-weight:600;font-family:inherit;box-sizing:border-box;margin-bottom:8px">'
        + b.tasks.map(function(t,j){
            return '<div style="display:flex;align-items:center;gap:7px;margin-bottom:5px"><span style="color:'+tx2()+';font-size:15px;flex:1">• '+esc(t)+'</span><button onclick="planRemoveTask('+i+','+j+')" style="background:none;border:none;color:#E57373;font-size:14px;cursor:pointer">✕</button></div>';
          }).join('')
        + '<div style="display:flex;gap:6px;margin-top:6px">'
          + '<input id="PLAN_T_'+i+'" placeholder="Ajouter une tâche…" onkeydown="if(event.key===\'Enter\')planAddTask('+i+')" style="flex:1;padding:8px 10px;border-radius:9px;border:1px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:15px;font-family:inherit;min-width:0">'
          + '<button onclick="planAddTask('+i+')" style="width:38px;border-radius:9px;border:none;background:'+hexA(acc,.15)+';color:'+acc+';font-size:18px;cursor:pointer">+</button>'
        + '</div>'
      + '</div>';
    } else {
      // Mode affichage
      var doneCount = b.tasks.filter(function(_,j){ return planIsDone(i,j); }).length;
      content += '<div style="background:'+bg2()+';border:1px solid '+br()+';border-radius:16px;overflow:hidden;margin-bottom:10px">'
        + '<div style="padding:12px 15px;display:flex;align-items:center;gap:11px;background:linear-gradient(90deg,'+hexA(acc,.07)+',transparent)">'
          + '<span style="font-size:24px">'+esc(b.icon)+'</span>'
          + '<div style="flex:1"><p style="font-size:18px;font-weight:700;color:'+tx()+';font-family:Fraunces,Georgia,serif">'+esc(b.titre)+'</p>'
          + (b.tasks.length?'<p style="font-size:13px;color:'+tx2()+'">'+doneCount+'/'+b.tasks.length+' fait'+(doneCount>1?'s':'')+'</p>':'')+'</div>'
          + '<span style="font-size:18px;font-weight:700;color:'+acc+';font-variant-numeric:tabular-nums">'+esc(b.time)+'</span>'
        + '</div>'
        + (b.tasks.length ? '<div style="padding:4px 15px 12px">'
          + b.tasks.map(function(t,j){
              var dn = planIsDone(i,j);
              return '<div onclick="planToggleTask('+i+','+j+')" style="display:flex;align-items:center;gap:10px;padding:7px 0;cursor:pointer">'
                + '<div style="width:20px;height:20px;border-radius:6px;border:2px solid '+(dn?acc:hexA(acc,.3))+';background:'+(dn?acc:'transparent')+';display:flex;align-items:center;justify-content:center;flex-shrink:0">'+(dn?'<span style="font-size:13px;color:#fff;font-weight:700">✓</span>':'')+'</div>'
                + '<span style="font-size:16px;color:'+(dn?tx2():tx())+';'+(dn?'text-decoration:line-through;opacity:.6':'')+'">'+esc(t)+'</span>'
              + '</div>';
            }).join('')
          + '</div>' : '')
      + '</div>';
    }
  });

  // Ajouter un bloc
  content += '<button class="press" onclick="planAddBlock()" style="width:100%;padding:13px;border-radius:14px;border:1.5px dashed '+hexA(acc,.5)+';background:transparent;color:'+acc+';font-size:16px;font-weight:700;cursor:pointer;font-family:inherit;margin-top:2px">+ Ajouter un moment</button>';

  return hdr(esc(p.name), 'Ta journée, à ton rythme', "N('quotidien')")
    + '<div class="stagger" style="padding:14px 16px 24px">' + content + '</div>';
}



