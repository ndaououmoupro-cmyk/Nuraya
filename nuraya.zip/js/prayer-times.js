// ═══════════════════════════════════════════════════════════════
// HORAIRES DE PRIÈRE — API AlAdhan (gratuite, sans clé)
// Géolocalisation ou ville · cache quotidien hors-ligne
// ═══════════════════════════════════════════════════════════════
var SALAT_METHODS = [
  [3,  'Ligue Islamique Mondiale (MWL)'],
  [12, 'UOIF / Musulmans de France'],
  [2,  'ISNA (Amérique du Nord)'],
  [4,  'Umm al-Qura (Makkah)'],
  [5,  'Égypte (Autorité générale)'],
];
var SALAT_NAMES = [['Fajr','Fajr','الفجر'],['Sunrise','Shurûq','الشروق'],['Dhuhr','Dhuhr','الظهر'],['Asr','\u2018Asr','العصر'],['Maghrib','Maghrib','المغرب'],['Isha','\u2018Ishâ','العشاء']];

function salatToday() { 
  var d = new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}

function salatCache() {
  var c = S.profil.salatCache;
  return (c && c.date === salatToday() && c.timings) ? c : null;
}

function fetchSalat() {
  var method = S.profil.salatMethod || 3;
  S.salatLoading = true; S.salatError = '';
  render();
  var done = function(json, label) {
    try {
      var d = json.data;
      S.profil.salatCache = {
        date: salatToday(),
        timings: d.timings,
        hijri: d.date && d.date.hijri ? (d.date.hijri.day+' '+d.date.hijri.month.ar+' '+d.date.hijri.year) : '',
        place: label
      };
      save();
    } catch(e) { S.salatError = 'Réponse inattendue du service.'; }
    S.salatLoading = false;
    render();
  };
  var fail = function(msg) { S.salatLoading = false; S.salatError = msg; render(); };

  var city = (S.profil.salatCity || '').trim();
  if (city) {
    var parts = city.split(',');
    var ville = encodeURIComponent(parts[0].trim());
    var pays = encodeURIComponent((parts[1] || 'France').trim());
    fetch('https://api.aladhan.com/v1/timingsByCity?city='+ville+'&country='+pays+'&method='+method)
      .then(function(r){ if(!r.ok) throw 0; return r.json(); })
      .then(function(j){ done(j, parts[0].trim()); })
      .catch(function(){ fail('Ville introuvable — essaie « Ville, Pays » (ex. Bangi, Malaysia).'); });
  } else if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(pos) {
      S.profil.qiblaLat = pos.coords.latitude; S.profil.qiblaLng = pos.coords.longitude;
      fetch('https://api.aladhan.com/v1/timings?latitude='+pos.coords.latitude+'&longitude='+pos.coords.longitude+'&method='+method)
        .then(function(r){ if(!r.ok) throw 0; return r.json(); })
        .then(function(j){ done(j, 'Ma position'); })
        .catch(function(){ fail('Service indisponible — réessaie ou saisis ta ville.'); });
    }, function() {
      fail('Position refusée — saisis ta ville ci-dessous.');
    }, {timeout: 8000});
  } else {
    fail('Saisis ta ville ci-dessous.');
  }
}

function salatNext() {
  var c = salatCache();
  if (!c) return null;
  var now = new Date();
  var prayers = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
  for (var i = 0; i < prayers.length; i++) {
    var t = (c.timings[prayers[i]] || '').slice(0,5).split(':');
    var dt = new Date(); dt.setHours(parseInt(t[0]), parseInt(t[1]), 0, 0);
    if (dt > now) {
      var diff = Math.round((dt - now) / 60000);
      return { name: prayers[i], time: c.timings[prayers[i]].slice(0,5),
               inH: Math.floor(diff/60), inM: diff%60 };
    }
  }
  return { name: 'Fajr', time: (c.timings['Fajr']||'').slice(0,5), tomorrow: true };
}

function homeSalatCard() {
  // Pendant les règles : les prières étant levées, on remplace par un message doux
  if (S.profil.genre !== 'homme' && typeof currentPeriod === 'function' && currentPeriod()) {
    return '<button onclick="S.femmeTab=\'suivi\';N(\'femme\')" style="width:100%;display:flex;align-items:center;gap:10px;background:'+bg2()+';border:1px solid rgba(229,115,115,.4);border-radius:14px;padding:11px 14px;margin:0 0 8px;cursor:pointer;font-family:inherit;text-align:left">'
      + '<span style="font-size:22px">🌸</span>'
      + '<div style="flex:1"><p style="font-size:14px;color:'+tx2()+';letter-spacing:.06em;text-transform:uppercase">Période de règles</p>'
      + '<p style="font-size:17px;font-weight:700;color:'+tx()+'">Prières levées · dhikr & du\'â continuent</p></div>'
      + '<span style="color:'+gold()+'">›</span>'
    + '</button>';
  }
  var c = salatCache();
  if (!c) {
    return '<button onclick="N(\'salat\')" style="width:100%;display:flex;align-items:center;gap:10px;background:'+bg2()+';border:1px solid '+br()+';border-radius:14px;padding:11px 14px;margin:0 0 8px;cursor:pointer;font-family:inherit;text-align:left">'
      + '<span style="font-size:22px">🕌</span>'
      + '<div style="flex:1"><p style="font-size:18px;font-weight:700;color:'+tx()+'">Horaires de prière</p>'
      + '<p style="font-size:16px;color:'+tx2()+'">Configure ta ville pour voir la prochaine salât ici</p></div>'
      + '<span style="color:'+gold()+'">›</span>'
    + '</button>';
  }
  var nx = salatNext();
  var sub = nx.tomorrow ? 'demain à '+nx.time
          : 'dans '+(nx.inH ? nx.inH+'h ' : '')+nx.inM+' min · '+nx.time;
  return '<button onclick="N(\'salat\')" style="width:100%;display:flex;align-items:center;gap:10px;background:'+bg2()+';border:1px solid rgba(191,174,85,.4);border-radius:14px;padding:11px 14px;margin:0 0 8px;cursor:pointer;font-family:inherit;text-align:left">'
    + '<span style="font-size:22px">🕌</span>'
    + '<div style="flex:1"><p style="font-size:16px;color:'+tx2()+';letter-spacing:.06em;text-transform:uppercase">Prochaine prière · '+esc(c.place||'')+'</p>'
    + '<p style="font-size:19px;font-weight:700;color:'+tx()+'">'+nx.name+' <span style="color:'+gold()+'">'+sub+'</span></p></div>'
    + '<span style="color:'+gold()+'">›</span>'
  + '</button>';
}

function pageSalat() {
  var c = salatCache();
  var nx = c ? salatNext() : null;
  var method = S.profil.salatMethod || 3;
  return '<div style="padding:12px 16px 24px">'
    // Localisation + méthode
    + card(
        '<p style="font-size:17px;font-weight:700;color:'+gold()+';letter-spacing:.08em;text-transform:uppercase;margin-bottom:7px">Localisation</p>'
        + '<input value="'+esc(S.profil.salatCity||'')+'" oninput="S.profil.salatCity=this.value;save()" placeholder="Ville, Pays (ex. Bangi, Malaysia) — vide = GPS" style="width:100%;padding:9px 11px;border-radius:10px;border:1.5px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:18px;font-family:inherit;box-sizing:border-box;margin-bottom:7px">'
        + '<select onchange="S.profil.salatMethod=parseInt(this.value);save()" style="width:100%;padding:9px 11px;border-radius:10px;border:1.5px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:18px;font-family:inherit;margin-bottom:8px">'
          + SALAT_METHODS.map(function(m){ return '<option value="'+m[0]+'"'+(method===m[0]?' selected':'')+'>'+m[1]+'</option>'; }).join('')
        + '</select>'
        + '<button class="btn-gold" onclick="fetchSalat()" '+(S.salatLoading?'disabled':'')+' style="width:100%;padding:11px;border-radius:12px;border:none;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');color:#FFFDF0;font-size:18px;font-weight:700;cursor:pointer;font-family:inherit;min-height:46px;opacity:'+(S.salatLoading?'.6':'1')+'">'+(S.salatLoading?'Chargement…':(c?'Actualiser':'Obtenir les horaires'))+'</button>'
        + (S.salatError ? '<p style="font-size:16px;color:#E57373;margin-top:6px">'+esc(S.salatError)+'</p>' : '')
      )
    // Horaires du jour
    + (c
        ? card(
            '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:9px">'
              + '<p style="font-size:18px;font-weight:700;color:'+tx()+'">'+esc(c.place||'')+'</p>'
              + '<p style="font-size:16px;color:'+tx2()+';direction:rtl">'+esc(c.hijri||'')+'</p>'
            + '</div>'
            + SALAT_NAMES.map(function(p){
                var isNext = nx && !nx.tomorrow && nx.name === p[0];
                var time = (c.timings[p[0]]||'').slice(0,5);
                return '<div style="display:flex;justify-content:space-between;align-items:center;padding:9px 11px;border-radius:11px;margin-bottom:4px;'
                  + (isNext ? 'background:'+(S.dark?hexA(gold(),.1):'rgba(138,107,29,.07)')+';border:1.5px solid '+gold() : 'border:1px solid transparent')+'">'
                  + '<div style="display:flex;align-items:baseline;gap:8px"><span style="font-size:19px;font-weight:'+(isNext?'700':'600')+';color:'+(isNext?gold():tx())+'">'+p[1]+'</span>'
                  + '<span style="font-size:17px;color:'+tx2()+';direction:rtl;font-family:Fraunces,Georgia,serif">'+p[2]+'</span>'
                  + (isNext?'<span style="font-size:14px;color:'+gold()+';font-weight:700;letter-spacing:.06em">• PROCHAINE</span>':'')+'</div>'
                  + '<span style="font-size:19px;font-weight:700;color:'+(isNext?gold():tx())+';font-variant-numeric:tabular-nums">'+time+'</span>'
                + '</div>';
              }).join('')
            + '<p style="font-size:15px;color:'+tx2()+';opacity:.7;margin-top:6px;text-align:center">Source : api.aladhan.com · horaires indicatifs, vérifie avec ta mosquée locale</p>'
          )
        : card('<p style="font-size:18px;color:'+tx2()+';text-align:center;line-height:1.7;padding:8px 0">🕌<br>Obtiens tes horaires une fois —<br>ils restent disponibles toute la journée, même hors-ligne.</p>')
      )
    + '</div>';
}

function pageAI() {
  var waiting = !!S.profil.nurWait;
  return '<div style="padding:14px 16px 24px">'
    // ── Héro ──
    + '<div style="text-align:center;padding:22px 10px 18px">'
      + '<div style="width:74px;height:74px;border-radius:50%;margin:0 auto 14px;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');display:flex;align-items:center;justify-content:center;box-shadow:0 6px 24px rgba(138,107,29,.35), 0 0 0 8px rgba(191,174,85,.1)"><span style="font-size:32px;color:#FFFDF0;text-shadow:0 1px 4px rgba(26,58,42,.4)">✦</span></div>'
      + '<p style="font-size:26px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin-bottom:2px">Nûr — نور</p>'
      + '<p style="font-size:17px;letter-spacing:.14em;text-transform:uppercase;color:'+gold()+';font-weight:700;margin-bottom:10px">Nûraya Plus</p>'
      + '<p style="font-size:18px;color:'+tx2()+';line-height:1.7;max-width:300px;margin:0 auto">Une assistante islamique conçue par Nûraya, dont chaque réponse s\'appuie sur le Coran, les hadiths authentiques et les exégètes reconnus.</p>'
    + '</div>'
    // ── Statut construction ──
    + '<div style="display:flex;align-items:center;gap:9px;border:1px solid '+br()+';border-radius:14px;padding:11px 14px;margin-bottom:12px;background:'+bg2()+'">'
      + '<div style="width:9px;height:9px;border-radius:5px;background:#E8B931;box-shadow:0 0 8px rgba(232,185,49,.6);flex-shrink:0"></div>'
      + '<div><p style="font-size:18px;font-weight:700;color:'+tx()+'">En construction</p>'
      + '<p style="font-size:16px;color:'+tx2()+'">Notre IA est en cours de développement — lancement avec l\'abonnement Nûraya Plus.</p></div>'
    + '</div>'
    // ── Ce que Nûr saura faire ──
    + card(
        '<p style="font-size:17px;font-weight:700;color:'+gold()+';letter-spacing:.08em;text-transform:uppercase;margin-bottom:9px">Incluse dans Plus</p>'
        + [
            ['📖','Réponses sourcées', 'Versets (sourate:verset) et hadiths cités avec collection, numéro et degré d\'authenticité.'],
            ['📚','Tafsir interactif', 'Pose tes questions sur n\'importe quel verset — Ibn Kathîr, As-Sa\'dî, At-Tabarî.'],
            ['🕌','Respect des écoles', 'Les divergences entre madhâhib sont présentées sans trancher. Jamais de fatwa : Nûr oriente vers les savants.'],
            ['🌙','Compagne du quotidien', 'Du\'âs adaptées, rappels, aide à la mémorisation, questions de la vie de tous les jours.'],
          ].map(function(f){
            return '<div style="display:flex;gap:10px;margin-bottom:10px"><span style="font-size:20px;flex-shrink:0">'+f[0]+'</span><div><p style="font-size:18px;font-weight:700;color:'+tx()+'">'+f[1]+'</p><p style="font-size:16px;color:'+tx2()+';line-height:1.55">'+f[2]+'</p></div></div>';
          }).join('')
      )
    // ── Gratuit vs Plus ──
    + card(
        '<div style="display:flex;gap:8px">'
          + '<div style="flex:1;text-align:center;padding:8px 4px;border-radius:11px;background:'+(S.dark?'rgba(191,174,85,.06)':'rgba(26,58,42,.04)')+'">'
            + '<p style="font-size:16px;font-weight:700;color:'+tx2()+';letter-spacing:.06em;text-transform:uppercase">Gratuit</p>'
            + '<p style="font-size:16px;color:'+tx2()+';line-height:1.6;margin-top:4px">Coran complet hors-ligne<br>Tafsir Ibn Kathir<br>Adhkâr · Dhikr · Ilm<br>Routine & Hifz</p>'
          + '</div>'
          + '<div style="flex:1;text-align:center;padding:8px 4px;border-radius:11px;border:1.5px solid '+gold()+';background:'+(S.dark?hexA(gold(),.07):'rgba(138,107,29,.05)')+'">'
            + '<p style="font-size:16px;font-weight:700;color:'+gold()+';letter-spacing:.06em;text-transform:uppercase">✦ Plus</p>'
            + '<p style="font-size:16px;color:'+tx()+';line-height:1.6;margin-top:4px">Tout le gratuit<br><b>+ Nûr IA illimitée</b><br>Tarif annoncé<br>au lancement</p>'
          + '</div>'
        + '</div>'
      )
    // ── CTA liste d\'attente ──
    + (waiting
        ? '<div style="text-align:center;border:1px solid rgba(76,175,80,.35);border-radius:14px;padding:13px;background:'+(S.dark?'rgba(76,175,80,.08)':'rgba(76,175,80,.06)')+'"><p style="font-size:18px;font-weight:700;color:'+(S.dark?'#7FC98B':'#2E7D32')+'">✓ Tu es sur la liste</p><p style="font-size:16px;color:'+tx2()+';margin-top:2px">Tu seras averti·e en premier au lancement de Nûr, insha\'Allah.</p></div>'
        : '<button class="btn-gold" onclick="S.profil.nurWait=true;save();toast(\'Inscrit·e à la liste d\\\'attente ✓\');render()" style="width:100%;padding:14px;border-radius:15px;border:none;background:linear-gradient(150deg,'+gold()+','+goldStrong()+');color:#FFFDF0;font-size:19px;font-weight:700;cursor:pointer;font-family:inherit;box-shadow:0 4px 16px rgba(138,107,29,.35);min-height:50px">✦ M\'avertir au lancement</button>')
    + '<p style="text-align:center;font-size:15px;color:'+tx2()+';opacity:.7;margin-top:10px">Nûr ne remplace pas un savant — pour une situation personnelle, consulte un imam qualifié.</p>'
    + '</div>';
}



function pageAdhkar() {
  var t = S.adhkarTab || 'sabah';
  var list = t === 'sabah' ? ADHKAR_SABAH : ADHKAR_MASAA;
  var idx = S.adhkarIdx || 0;
  if (idx >= list.length) idx = 0;
  var item = list[idx];
  var done = S.adhkarDone || {};

  // Mode liste ou mode lecture
  if (S.adhkarMode === 'read') {
    var allDone = list.every(function(_,i){ return done[t+i]; });
    return hdr(
      t==='sabah' ? 'Adhkâr du Matin 🌅' : 'Adhkâr du Soir 🌙',
      (idx+1)+'/'+list.length+' · '+item.titre,
      'S.adhkarMode=null;render()'
    )
    + '<div style="padding:14px">'
    // Progression
    + '<div style="height:4px;background:rgba(26,58,42,.1);border-radius:2px;margin-bottom:16px;overflow:hidden">'
      + '<div style="height:100%;width:'+Math.round((idx+1)/list.length*100)+'%;background:linear-gradient(90deg,'+bx()+','+gold()+');border-radius:2px;transition:width .4s"></div>'
    + '</div>'
    // Carte dhikr
    + '<div style="background:'+bg2()+';border-radius:20px;padding:20px;margin-bottom:14px;border:1px solid '+br()+'">'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:22px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:14px">'+item.ar+'</p>'
      + '<p style="font-size:18px;color:'+tx()+';line-height:1.8;font-style:italic;margin-bottom:10px">'+esc(item.fr)+'</p>'
      + '<div style="display:flex;justify-content:space-between;align-items:center">'
        + '<p style="font-size:15px;color:'+bxT()+';font-weight:600">'+esc(item.ref)+'</p>'
        + '<div style="background:rgba(26,58,42,.1);border-radius:10px;padding:4px 12px">'
          + '<p style="font-size:15px;color:'+bxT()+';font-weight:700">×'+item.rep+'</p>'
        + '</div>'
      + '</div>'
    + '</div>'
    // Bienfait
    + (item.bienfait ? '<div style="background:rgba(191,174,85,.08);border-left:3px solid '+gold()+';border-radius:0 12px 12px 0;padding:12px 14px;margin-bottom:18px">'
      + '<p style="font-size:15px;color:'+tx2()+';line-height:1.7">✦ '+esc(item.bienfait)+'</p>'
    + '</div>' : '')
    // Boutons navigation
    + '<div style="display:flex;gap:10px">'
      + (idx > 0 ? '<button onclick="S.adhkarIdx='+(idx-1)+';render()" style="flex:1;padding:14px;border-radius:14px;border:1.5px solid '+br()+';background:transparent;color:'+tx2()+';font-size:18px;cursor:pointer;font-family:inherit">← Précédent</button>' : '<div style="flex:1"></div>')
      + '<button onclick="S.adhkarDone=S.adhkarDone||{};S.adhkarDone[\''+t+idx+'\']= true;'+(idx < list.length-1 ? 'S.adhkarIdx='+(idx+1)+';' : '')+'render()" style="flex:2;padding:14px;border-radius:14px;border:none;background:'+(done[t+idx]?'rgba(129,199,132,.2)':bx())+';color:'+(done[t+idx]?'#81C784':'#E2D38C')+';font-size:18px;cursor:pointer;font-family:Fraunces,Georgia,serif;font-weight:600">'
        + (done[t+idx] ? '✓ Fait' : (idx < list.length-1 ? 'Suivant →' : '✓ Terminer'))
      + '</button>'
    + '</div>'
    + (allDone ? '<div style="text-align:center;margin-top:16px;padding:16px;background:rgba(129,199,132,.1);border-radius:14px"><p style="font-size:19px;color:#81C784">🎉 Adhkâr du '+(t==='sabah'?'matin':'soir')+' complétés !</p><p style="font-size:16px;color:'+tx2()+';margin-top:4px">Barakallahu fik 🤲</p></div>' : '')
    + '</div>';
  }

  // Mode liste
  return hdr(t==='sabah'?'Adhkâr du Matin 🌅':'Adhkâr du Soir 🌙', t==='sabah'?'Après Fajr':'Après Maghrib')
    + pills([['sabah','Matin 🌅'],['masaa','Soir 🌙']], t, 'setAdhkarTab')
    + '<div style="padding:12px 14px">'
    + '<button onclick="S.adhkarMode=\'read\';S.adhkarIdx=0;S.adhkarDone={};render()" style="width:100%;padding:16px;border-radius:16px;border:none;background:linear-gradient(135deg,'+activeTheme().grad[0]+','+activeTheme().grad[1]+');color:'+(S.dark?activeTheme().dark.goldT:'#FFFDF0')+';font-size:19px;font-family:Fraunces,Georgia,serif;cursor:pointer;margin-bottom:14px">▶ Commencer les adhkâr ('+list.length+')</button>'
    + list.map(function(item, i) {
        var isDone = done[t+i];
        return '<div style="background:'+bg2()+';border:1px solid '+(isDone?'rgba(129,199,132,.3)':br())+';border-radius:14px;padding:12px 14px;margin-bottom:8px;display:flex;align-items:center;gap:12px">'
          + '<div style="width:32px;height:32px;border-radius:10px;background:'+(isDone?'rgba(129,199,132,.2)':'rgba(26,58,42,.08)')+';display:flex;align-items:center;justify-content:center;flex-shrink:0">'
            + '<span style="font-size:16px;color:'+(isDone?'#81C784':bx())+';">'+(isDone?'✓':(i+1))+'</span>'
          + '</div>'
          + '<div style="flex:1;min-width:0">'
            + '<p style="font-size:18px;font-weight:600;color:'+tx()+'">'+esc(item.titre)+'</p>'
            + '<p style="font-size:15px;color:'+tx2()+';margin-top:2px">×'+item.rep+' · '+esc(item.ref)+'</p>'
          + '</div>'
          + '<button onclick="S.adhkarMode=\'read\';S.adhkarIdx='+i+';render()" style="padding:6px 12px;border-radius:10px;border:1px solid '+br()+';background:transparent;color:'+tx2()+';font-size:15px;cursor:pointer;font-family:inherit">Lire</button>'
        + '</div>';
      }).join('')
    + '</div>';
}

function setAdhkarTab(t) { S.adhkarTab = t; S.adhkarMode = null; S.adhkarIdx = 0; render(); }

