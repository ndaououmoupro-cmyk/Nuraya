// ═══════════════════════════════════════════════════════════════
// PAGE PROFIL — PIN, RGPD, Paramètres
// ═══════════════════════════════════════════════════════════════

function pageProfil() {
  var hasPin = !!localStorage.getItem(PIN_KEY);
  return hdr('Profil · الملف', 'Personnalisation · Sécurité')
    + '<div style="padding:10px 14px">'
    // Avatar
    + '<div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:'+bg2()+';border:1px solid '+br()+';border-radius:14px;margin-bottom:8px">'
      + logoSVG(48)
      + '<div>'
        + '<p style="font-size:21px;font-weight:600;color:'+tx()+'">'+esc(S.profil.nom || 'Utilisatrice')+'</p>'
        + '<p style="font-size:18px;color:'+tx2()+'">Madhhab : '+esc(S.profil.madhhab||'Maliki')+'</p>'
        + '<p style="font-size:18px;color:'+bxT()+';margin-top:2px">🔥 '+S.streak+' jours de streak</p>'
      + '</div>'
    + '</div>'
    // Champs profil
    + card(
        '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:8px">Informations</p>'
        + '<p style="font-size:18px;color:'+tx2()+';margin-bottom:4px">Prénom</p>'
        + '<input value="'+esc(S.profil.nom||'')+'" oninput="S.profil.nom=this.value;save()" placeholder="Ton prénom" style="width:100%;padding:7px 10px;border-radius:9px;border:1.5px solid '+br()+';background:'+bg()+';color:'+tx()+';font-size:19px;font-family:inherit;box-sizing:border-box;margin-bottom:8px">'
        + '<p style="font-size:17px;font-weight:700;color:'+tx()+';margin-bottom:4px">Profil</p>'
        + '<div style="display:flex;gap:6px;margin-bottom:8px">'
          + [['femme','🌸 Femme'],['homme','🤲 Homme']].map(function(g){
              var on = (S.profil.genre||'femme')===g[0];
              return '<button onclick="S.profil.genre=\''+g[0]+'\';save();render()" style="flex:1;padding:9px;border-radius:11px;border:1.5px solid '+(on?gold():br())+';background:'+(on?(S.dark?hexA(gold(),.1):'rgba(138,107,29,.06)'):'transparent')+';color:'+(on?gold():tx2())+';font-size:18px;font-weight:'+(on?'700':'400')+';cursor:pointer;font-family:inherit;min-height:42px">'+g[1]+'</button>';
            }).join('')
        + '</div>'
        + '<div onclick="S.profil.noHaptic=!S.profil.noHaptic;save();if(!S.profil.noHaptic)haptic(\'success\');render()" style="display:flex;align-items:center;justify-content:space-between;padding:11px 13px;border-radius:12px;border:1px solid '+br()+';background:'+bg2()+';margin-bottom:8px;cursor:pointer">'
          + '<div><p style="font-size:17px;font-weight:700;color:'+tx()+'">Vibrations</p><p style="font-size:14px;color:'+tx2()+'">Retour tactile aux moments clés</p></div>'
          + '<div style="width:46px;height:27px;border-radius:14px;background:'+(!S.profil.noHaptic?gold():hexA(tx2(),.25))+';position:relative;transition:background .25s;flex-shrink:0"><div style="width:21px;height:21px;border-radius:50%;background:#fff;position:absolute;top:3px;left:'+(!S.profil.noHaptic?'22px':'3px')+';transition:left .25s;box-shadow:0 1px 3px rgba(0,0,0,.2)"></div></div>'
        + '</div>'
        + '<div onclick="S.profil.noSound=!S.profil.noSound;save();render()" style="display:flex;align-items:center;justify-content:space-between;padding:11px 13px;border-radius:12px;border:1px solid '+br()+';background:'+bg2()+';margin-bottom:8px;cursor:pointer">'
          + '<div><p style="font-size:17px;font-weight:700;color:'+tx()+'">Sons doux</p><p style="font-size:14px;color:'+tx2()+'">Tintement léger au dhikr</p></div>'
          + '<div style="width:46px;height:27px;border-radius:14px;background:'+(!S.profil.noSound?gold():hexA(tx2(),.25))+';position:relative;transition:background .25s;flex-shrink:0"><div style="width:21px;height:21px;border-radius:50%;background:#fff;position:absolute;top:3px;left:'+(!S.profil.noSound?'22px':'3px')+';transition:left .25s;box-shadow:0 1px 3px rgba(0,0,0,.2)"></div></div>'
        + '</div>'
        + '<p style="font-size:17px;font-weight:700;color:'+tx()+';margin-bottom:4px">Taille du texte</p>'
        + '<div style="display:flex;gap:6px;margin-bottom:8px">'
          + [[0.92,'A−'],[1,'A'],[1.1,'A+'],[1.22,'A++']].map(function(z){
              var on = Math.abs((S.profil.fontScale||1)-z[0])<.01;
              return '<button onclick="S.profil.fontScale='+z[0]+';save();render()" style="flex:1;padding:9px;border-radius:11px;border:1.5px solid '+(on?gold():br())+';background:'+(on?(S.dark?hexA(gold(),.1):'rgba(138,107,29,.06)'):'transparent')+';color:'+(on?gold():tx2())+';font-size:'+(13+z[0]*4)+'px;font-weight:'+(on?'700':'400')+';cursor:pointer;font-family:inherit;min-height:42px">'+z[1]+'</button>';
            }).join('')
        + '</div>'
        + '<p style="font-size:17px;font-weight:700;color:'+tx()+';margin-bottom:6px">🎨 Thème de couleur</p>'
        + '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:6px">'
          + Object.keys(THEMES).map(function(key){
              var th = THEMES[key];
              var p = S.dark ? th.dark : th.light;
              var on = (S.profil.theme||'emeraude') === key;
              return '<button onclick="setTheme(\''+key+'\')" style="display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px 4px;border-radius:13px;border:2px solid '+(on?p.gold:br())+';background:'+(on?p.bg2:'transparent')+';cursor:pointer;font-family:inherit;position:relative">'
                + '<div style="display:flex;gap:3px">'
                  + '<span style="width:17px;height:17px;border-radius:50%;background:'+p.bg+';border:1px solid '+p.br+'"></span>'
                  + '<span style="width:17px;height:17px;border-radius:50%;background:'+th.bx+'"></span>'
                  + '<span style="width:17px;height:17px;border-radius:50%;background:'+p.gold+'"></span>'
                + '</div>'
                + '<span style="font-size:13px;font-weight:'+(on?'700':'500')+';color:'+(on?p.gold:tx2())+';text-align:center;line-height:1.2">'+th.emoji+' '+th.nom+'</span>'
                + (on ? '<span style="position:absolute;top:4px;right:5px;font-size:12px;color:'+p.gold+'">✓</span>' : '')
              + '</button>';
            }).join('')
        + '</div>'
        + '<p style="font-size:14px;color:'+tx2()+';opacity:.75;margin-bottom:10px">Le mode clair/sombre s\'applique par-dessus le thème choisi.</p>'
          + '<p style="font-size:16px;color:'+tx2()+'">'+(S.profil.nurWait?'Sur la liste d\'attente — lancement bientôt':'Nûr IA en construction — découvrir l\'offre')+'</p></div>'
          + '<span style="font-size:17px;color:'+gold()+'">›</span>'
        + '</div>'
        + '<p style="font-size:18px;color:'+tx2()+';margin-bottom:4px">Madhhab</p>'
        + '<div style="display:flex;gap:5px">'
          + ['Maliki','Hanafi','Shafi\'i','Hanbali'].map(function(m) {
              var on = (S.profil.madhhab||'Maliki') === m;
              return '<button onclick="S.profil.madhhab=\''+m+'\';save();render()" style="flex:1;padding:5px 0;border-radius:8px;border:1.5px solid '+(on?gold():br())+';background:'+(on?'rgba(191,174,85,.12)':'transparent')+';color:'+(on?gold():tx2())+';font-size:17px;cursor:pointer;font-family:inherit">'+esc(m)+'</button>';
            }).join('')
        + '</div>'
      )
    // Thème
    + card(
        '<div style="display:flex;justify-content:space-between;align-items:center">'
          + '<div><p style="font-size:19px;font-weight:700;color:'+tx()+'">Mode '+(S.dark?'sombre 🌙':'clair ☀️')+'</p><p style="font-size:18px;color:'+tx2()+'">Apparence de l\'app</p></div>'
          + '<button onclick="toggleDark()" style="width:44px;height:24px;border-radius:12px;border:none;background:'+(S.dark?bx():'rgba(26,58,42,.2)')+';position:relative;cursor:pointer;transition:background .3s">'
            + '<div style="position:absolute;top:3px;left:'+(S.dark?'22':'3')+'px;width:18px;height:18px;border-radius:9px;background:#fff;transition:left .3s;box-shadow:0 1px 4px rgba(0,0,0,.2)"></div>'
          + '</button>'
        + '</div>'
      )
    // Sécurité PIN
    + card(
        '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:8px">🔐 Sécurité</p>'
        + '<div style="display:flex;gap:8px">'
          + '<button onclick="changePin()" style="flex:1;padding:8px;border-radius:10px;border:1.5px solid '+br()+';background:transparent;color:'+tx2()+';font-size:18px;cursor:pointer;font-family:inherit">'+(hasPin?'Changer le PIN':'Créer un PIN')+'</button>'
          + (hasPin ? '<button onclick="removePin()" style="flex:1;padding:8px;border-radius:10px;border:1.5px solid rgba(229,115,115,.4);background:rgba(229,115,115,.08);color:#E57373;font-size:18px;cursor:pointer;font-family:inherit">Supprimer PIN</button>' : '')
        + '</div>'
      )
    // Assistance & contact
    + card(
        '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:4px">💬 Assistance &amp; contact</p>'
        + '<p style="font-size:15px;color:'+tx2()+';line-height:1.6;margin-bottom:10px">Une question, un bug, une idée&nbsp;? Une réponse arrive avec plaisir, in shâ\' Allah.</p>'
        + [
            ['✉️','Contacter l\'assistance','Pour toute question sur l\'app','Nûraya — Assistance'],
            ['🐞','Signaler un problème','Un bug, un affichage cassé…','Nûraya — Signalement de bug'],
            ['💡','Suggérer une amélioration','Une idée pour enrichir Nûraya','Nûraya — Suggestion']
          ].map(function(r){
            var subj = encodeURIComponent(r[3]);
            var body = encodeURIComponent('\n\n———\nNûraya '+NURAYA_VERSION+' · '+(window.isStandalone?'app installée':'navigateur'));
            return '<a href="mailto:'+SUPPORT_EMAIL+'?subject='+subj+'&body='+body+'" style="text-decoration:none;display:flex;align-items:center;gap:12px;padding:11px 13px;border-radius:12px;border:1px solid '+br()+';background:'+bg2()+';margin-bottom:8px">'
              + '<span style="font-size:22px;flex-shrink:0">'+r[0]+'</span>'
              + '<div style="flex:1;min-width:0"><p style="font-size:17px;font-weight:700;color:'+tx()+'">'+r[1]+'</p><p style="font-size:14px;color:'+tx2()+'">'+r[2]+'</p></div>'
              + '<span style="font-size:17px;color:'+gold()+'">›</span>'
            + '</a>';
          }).join('')
      )
    // RGPD
    + card(
        '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:8px">📊 Données & RGPD</p>'
        + '<div style="font-size:18px;color:'+tx2()+';line-height:1.8;margin-bottom:8px">'
          + '<p>• Toutes vos données sont stockées localement sur votre appareil.</p>'
          + '<p>• Aucune donnée personnelle n\'est envoyée à un serveur.</p>'
          + '<p>• APIs : alquran.cloud (Coran) · cdn.jsdelivr.net (tafsir) · api.aladhan.com (horaires — position et données de cycle jamais stockées ailleurs que sur ton appareil).</p>'
          + '<p>• Conformité RGPD — droit à l\'effacement garanti.</p>'
        + '</div>'
        + '<button onclick="eraseAllData()" style="width:100%;padding:8px;border-radius:10px;border:1.5px solid rgba(229,115,115,.4);background:rgba(229,115,115,.08);color:#E57373;font-size:18px;cursor:pointer;font-family:inherit">🗑️ Effacer toutes mes données</button>'
      )
    + (window.isStandalone ? '' :
        '<div style="border:1.5px solid '+gold()+';border-radius:14px;padding:12px 14px;margin-bottom:8px;background:'+(S.dark?hexA(gold(),.06):'rgba(138,107,29,.04)')+'">'
        + '<div onclick="installPWA()" style="display:flex;align-items:center;gap:11px;cursor:pointer">'
          + '<span style="font-size:24px">📲</span>'
          + '<div style="flex:1"><p style="font-size:17px;font-weight:700;color:'+tx()+'">Installer Nûraya</p>'
          + '<p style="font-size:15px;color:'+tx2()+'">Accès direct depuis ton écran d\'accueil, comme une vraie app</p></div>'
          + '<span style="font-size:17px;color:'+gold()+'">›</span>'
        + '</div>'
        + (S.profil.showIOSInstall && window.isIOS
            ? '<div style="margin-top:10px;padding-top:10px;border-top:1px solid '+br()+'">'
              + '<p style="font-size:15px;color:'+tx()+';line-height:1.8">Sur iPhone :<br>1. Touche <b>Partager</b> ⬆️ en bas de Safari<br>2. Choisis <b>« Sur l\'écran d\'accueil »</b><br>3. Confirme avec <b>Ajouter</b></p>'
            + '</div>'
            : '')
        + '</div>')
    + '</div>';
}

function forgotPin() {
  if (confirm('Supprimer le PIN et réinitialiser ? Vos données seront conservées.')) {
    localStorage.removeItem(PIN_KEY);
    S.locked = false; S.pinEntry = ''; S.pinError = '';
    render();
  }
}

function changePin() {
  localStorage.removeItem(PIN_KEY);
  S.locked = true; S.pinEntry = ''; S.pinError = '';
  render();
}

function removePin() {
  if (confirm('Supprimer le PIN ?')) { localStorage.removeItem(PIN_KEY); render(); }
}

function eraseAllData() {
  if (confirm('Effacer TOUTES vos données ? Cette action est irréversible.')) {
    localStorage.clear();
    S.streak = 0;
    S.routineDots = [false,false,false,false,false,false,false,false,false,false];
    S.dhikrHistory = [];
    S.quranMemory = {};
    S.quranBookmarks = {};
    S.cachedSurahs = {};
    S.profil = {nom:'', madhhab:'Maliki'};
    toast('Données effacées ✓');
    render();
  }
}





