// ─── TÉLÉCHARGEMENT DU CORAN COMPLET (114 sourates, hors-ligne) ───
var DL_STATE = { running:false, done:0, failed:0 };

function isSurahOffline(n) {
  var meta = SURAHS.find(function(s){ return s.n === n; });
  if (!meta) return false;
  return (QURAN_LOCAL[n] && QURAN_LOCAL[n].length === meta.v)
      || (S.cachedSurahs[n] && S.cachedSurahs[n].length === meta.v);
}

function offlineCount() {
  var c = 0;
  for (var i = 1; i <= 114; i++) if (isSurahOffline(i)) c++;
  return c;
}

function downloadFullQuran() {
  if (DL_STATE.running) return;
  DL_STATE = { running:true, done:offlineCount(), failed:0 };
  render();
  var queue = [];
  for (var i = 1; i <= 114; i++) if (!isSurahOffline(i)) queue.push(i);
  if (!queue.length) { DL_STATE.running = false; toast('Coran déjà complet hors-ligne ✓'); render(); return; }

  var idx = 0, CONCURRENCY = 4;
  function next() {
    if (idx >= queue.length) return Promise.resolve();
    var n = queue[idx++];
    return fetch('https://api.alquran.cloud/v1/surah/'+n+'/editions/quran-uthmani,fr.hamidullah')
      .then(function(r){ return r.json(); })
      .then(function(data){
        var ar = data.data[0].ayahs, fr = data.data[1].ayahs;
        S.cachedSurahs[n] = ar.map(function(a,i){ return {n:a.numberInSurah, ar:a.text, fr:fr[i].text}; });
        DL_STATE.done++;
      })
      .catch(function(){ DL_STATE.failed++; })
      .then(function(){
        if (DL_STATE.done % 8 === 0) { saveQuran(); render(); }
        return next();
      });
  }
  var workers = [];
  for (var w = 0; w < CONCURRENCY; w++) workers.push(next());
  Promise.all(workers).then(function(){
    DL_STATE.running = false;
    var ok = saveQuran();
    if (DL_STATE.failed) toast(DL_STATE.failed + ' sourate(s) ont échoué — relancez');
    else if (!ok) toast('Coran téléchargé (mémoire pleine : non persistant)');
    else toast('Coran complet disponible hors-ligne ✓');
    render();
  });
}



// ═══════════════════════════════════════════════════════════════
// TAFSIR IBN KATHIR COMPLET — à la demande via API (spa5k/tafsir_api)
// Éditions : en-tafisr-ibn-kathir (abrégé EN) · ar-tafsir-ibn-kathir (AR)
// ═══════════════════════════════════════════════════════════════
var IK_EDITIONS = { en:'en-tafisr-ibn-kathir', ar:'ar-tafsir-ibn-kathir' };

function ikKey(s,v) { return s+':'+v+':'+S.ikLang; }


function shareVerse(num, vn) {
  var surah = SURAHS.find(function(s){ return s.n === num; });
  var v = S.quranVerses.find(function(x){ return x.n === vn; });
  if (!surah || !v) return;
  var text = v.ar + '\n\n« ' + v.fr + ' »\n\n— Sourate ' + surah.fr + ' (' + num + ':' + vn + ')\n📖 Partagé via Nûraya';
  if (navigator.share) {
    navigator.share({ text: text }).catch(function(){});
  } else if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function(){ toast('Verset copié ✓'); }).catch(function(){});
  }
}

// ── Reprendre la lecture ──
function markLastRead(s, v) {
  S.profil.lastRead = { surah: s, verse: v || null, ts: Date.now() };
  save();
}
function resumeRead() {
  var lr = S.profil.lastRead;
  if (!lr) return;
  N('coran');
  openSurah(lr.surah);
  if (lr.verse) setTimeout(function(){ jumpVerse(lr.surah, lr.verse); }, 600);
}
function homeResumeCard() {
  var lr = S.profil.lastRead;
  if (!lr) return '';
  var surah = SURAHS.find(function(s){ return s.n === lr.surah; });
  if (!surah) return '';
  return '<button onclick="resumeRead()" style="width:100%;display:flex;align-items:center;gap:10px;background:'+bg2()+';border:1px solid '+br()+';border-radius:14px;padding:11px 14px;margin:0 0 8px;cursor:pointer;font-family:inherit;text-align:left">'
    + '<span style="font-size:22px">📖</span>'
    + '<div style="flex:1"><p style="font-size:16px;color:'+tx2()+';letter-spacing:.06em;text-transform:uppercase">Reprendre ma lecture</p>'
    + '<p style="font-size:19px;font-weight:700;color:'+tx()+'">'+esc(surah.fr)+(lr.verse?' <span style="color:'+gold()+'">· v.'+lr.verse+'</span>':'')+'</p></div>'
    + '<span style="color:'+gold()+'">›</span>'
  + '</button>';
}

function toggleIK(s,v) {
  var ref = s+':'+v;
  if (S.ikOpen === ref) { S.ikOpen = null; render(); return; }
  S.ikOpen = ref;
  if (S.ikCache[ikKey(s,v)]) { render(); return; }
  fetchIK(s,v);
}

function setIKLang(lang) {
  S.ikLang = lang;
  if (S.ikOpen) {
    var p = S.ikOpen.split(':');
    if (!S.ikCache[ikKey(p[0],p[1])]) { fetchIK(parseInt(p[0]),parseInt(p[1])); return; }
  }
  render();
}

function stripHTML(html) {
  var d = document.createElement('div');
  // Préserver des sauts de ligne pour les titres/paragraphes
  d.innerHTML = String(html).replace(/<\/(h1|h2|h3|p|div)>/gi,'\n\n').replace(/<br\s*\/?>/gi,'\n');
  var t = d.textContent || d.innerText || '';
  return t.replace(/\n{3,}/g,'\n\n').trim();
}

function fetchIK(s,v) {
  var key = ikKey(s,v);
  S.ikLoading = s+':'+v;
  render();
  fetch('https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/'+IK_EDITIONS[S.ikLang]+'/'+s+'/'+v+'.json')
    .then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); })
    .then(function(d){
      var txt = stripHTML(d.text || d.tafsir || '');
      S.ikCache[key] = txt || "Pas de commentaire spécifique pour ce verset (souvent traité avec les versets voisins — essayez un verset proche).";
      S.ikLoading = null;
      render();
    })
    .catch(function(){
      S.ikCache[key] = '';
      S.ikLoading = null;
      S.ikError = s+':'+v;
      render();
    });
}

function jumpVerse(s, v) {
  v = parseInt(v); if (!v) return;
  markLastRead(s, v);
  var el = document.getElementById('VRS_'+s+'_'+v);
  if (el) {
    el.scrollIntoView({behavior:'smooth', block:'start'});
    el.style.transition = 'box-shadow .4s';
    el.style.boxShadow = '0 0 0 2px rgba(191,174,85,.55)';
    setTimeout(function(){ el.style.boxShadow = 'none'; }, 1600);
  }
}

function ikPanel(num, vn) {
  var ref = num+':'+vn;
  if (S.ikOpen !== ref) return '';
  var key = ikKey(num,vn);
  var loading = S.ikLoading === ref;
  var txt = S.ikCache[key];
  var isAr = S.ikLang === 'ar';
  var body;
  if (loading) {
    body = '<div style="display:flex;align-items:center;gap:8px;padding:10px 0"><div style="width:18px;height:18px;border-radius:9px;border:2.5px solid rgba(191,174,85,.25);border-top-color:'+gold()+';animation:spin 1s linear infinite"></div><p style="font-size:17px;color:'+tx2()+'">Chargement du tafsir…</p></div>';
  } else if (txt === '') {
    body = '<p style="font-size:17px;color:'+tx2()+';padding:8px 0">Hors-ligne ou indisponible. <button onclick="fetchIK('+num+','+vn+')" style="background:none;border:none;color:'+gold()+';font-size:17px;cursor:pointer;text-decoration:underline;font-family:inherit;padding:0">Réessayer</button></p>';
  } else if (txt) {
    body = '<div id="IKTXT_'+num+'_'+vn+'" style="font-size:'+(isAr?'17':'15')+'px;color:'+tx()+';line-height:'+(isAr?'2':'1.7')+';white-space:pre-line;max-height:340px;overflow-y:auto;'+(isAr?'direction:rtl;text-align:right;font-family:Fraunces,Georgia,serif;':'')+'">'+esc(txt)+'</div>';
  } else {
    body = '';
  }
  return '<div style="background:'+(S.dark?'rgba(191,174,85,.07)':'rgba(26,58,42,.08)')+';border:1px solid rgba(191,174,85,.3);border-radius:10px;padding:8px 10px;margin-top:6px">'
    + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">'
      + '<p style="font-size:17px;color:'+goldT()+';font-weight:700">📖 Tafsir Ibn Kathir · v.'+vn+'</p>'
      + '<div style="display:flex;gap:4px">'
        + '<button onclick="setIKLang(\'en\')" style="padding:2px 8px;border-radius:7px;border:1px solid rgba(191,174,85,.35);background:'+(S.ikLang==='en'?'rgba(191,174,85,.22)':'transparent')+';color:'+goldT()+';font-size:15px;cursor:pointer;font-family:inherit;font-weight:'+(S.ikLang==='en'?'700':'400')+'">EN</button>'
        + '<button onclick="setIKLang(\'ar\')" style="padding:2px 8px;border-radius:7px;border:1px solid rgba(191,174,85,.35);background:'+(S.ikLang==='ar'?'rgba(191,174,85,.22)':'transparent')+';color:'+goldT()+';font-size:15px;cursor:pointer;font-family:inherit;font-weight:'+(S.ikLang==='ar'?'700':'400')+'">ع</button>'
        + (txt ? '<button onclick="copyIK('+num+','+vn+')" title="Copier" style="padding:2px 8px;border-radius:7px;border:1px solid rgba(191,174,85,.35);background:transparent;color:'+goldT()+';font-size:15px;cursor:pointer;font-family:inherit">⧉</button>' : '')
      + '</div>'
    + '</div>'
    + body
    + '<p style="font-size:14px;color:'+tx2()+';opacity:.7;margin-top:5px">'+(isAr?'Tafsîr al-Qur\'ân al-\'Azîm (texte original)':'Version abrégée (anglais) · source : quran.com')+'</p>'
  + '</div>';
}

function toast(msg) {
  var t = document.getElementById('NTOAST');
  if (!t) {
    t = document.createElement('div');
    t.id = 'NTOAST';
    t.style.cssText = 'position:fixed;bottom:calc(84px + env(safe-area-inset-bottom, 0px));left:50%;transform:translateX(-50%);background:#1A3A2A;color:#E2D38C;padding:9px 20px;border-radius:16px;font-size:17px;font-family:inherit;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,.3);opacity:0;transition:opacity .25s;pointer-events:none;border:1px solid rgba(191,174,85,.35)';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.background = bx();
  t.style.color = S.dark ? activeTheme().dark.goldT : '#FFFDF0';
  t.style.borderColor = hexA(gold(), .4);
  requestAnimationFrame(function(){ t.style.opacity = '1'; });
  clearTimeout(t._h);
  t._h = setTimeout(function(){ t.style.opacity = '0'; }, 1800);
}

function copyIK(s,v) {
  var txt = S.ikCache[ikKey(s,v)];
  if (!txt) return;
  var label = 'Tafsir Ibn Kathir — sourate '+s+', verset '+v+'\n\n'+txt;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(label).then(function(){ toast('Tafsir copié ✓'); }).catch(function(){});
  }
}

function contextPanel(num) {
  var info = SURAH_INFO[num];
  if (!info) return '';
  var open = S.quranCtxOpen === num;
  return '<div style="background:'+(S.dark?'rgba(191,174,85,.06)':'rgba(26,58,42,.06)')+';border-bottom:1px solid '+br()+'">'
    + '<button onclick="S.quranCtxOpen='+(open?'null':num)+';render()" style="width:100%;padding:9px 14px;background:transparent;border:none;display:flex;justify-content:space-between;align-items:center;cursor:pointer">'
      + '<span style="font-size:18px;color:'+goldT()+';font-weight:700">📚 Contexte & Tafsir</span>'
      + '<span style="font-size:17px;color:'+goldT()+'">'+(open?'▲':'▼')+'</span>'
    + '</button>'
    + (open
        ? '<div style="padding:0 14px 12px">'
          + '<p style="font-size:16px;font-weight:700;color:'+goldT()+';text-transform:uppercase;letter-spacing:.08em;margin-bottom:4px">Contexte de révélation</p>'
          + '<p style="font-size:18px;color:'+tx()+';line-height:1.75;margin-bottom:10px">'+esc(info.context)+'</p>'
          + '<p style="font-size:16px;font-weight:700;color:'+goldT()+';text-transform:uppercase;letter-spacing:.08em;margin-bottom:4px">Tafsir</p>'
          + '<p style="font-size:18px;color:'+tx()+';line-height:1.75;margin-bottom:10px">'+esc(info.tafsir)+'</p>'
          + '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px">'
            + info.themes.map(function(t) { return '<span style="font-size:16px;background:'+(S.dark?'rgba(191,174,85,.15)':'rgba(26,58,42,.1)')+';color:'+goldT()+';border-radius:8px;padding:2px 9px;font-weight:600">'+esc(t)+'</span>'; }).join('')
          + '</div>'
          + (info.src ? '<p style="font-size:15px;color:'+tx2()+';font-style:italic;border-top:1px solid '+br()+';padding-top:6px">Sources : '+esc(info.src)+'</p>' : '')
        + '</div>'
        : ''
      )
  + '</div>';
}

function pageCoranRead() {
  var num = S.quranSurah;
  var surah = SURAHS.find(function(s) { return s.n === num; }) || {fr:'?',ar:'',v:'?',t:'',j:'?'};
  var fsSizes = [18,22,27];
  var fs = fsSizes[S.quranFont];

  return '<div style="padding:0">'
    // Header lecture
    + '<div style="background:linear-gradient(160deg,'+activeTheme().grad[0]+','+activeTheme().grad[1]+');padding:12px 16px;position:relative">'
      + '<button onclick="S.quranSurah=null;S.quranVerses=[];S.ikOpen=null;if(S.quranAudio){S.quranAudio.pause();S.quranAudio=null;}S.quranAudioVerse=null;render()" style="background:none;border:none;color:rgba(226,211,140,.85);font-size:19px;cursor:pointer;padding:6px 0;margin:-6px 0 2px;font-family:inherit;min-height:36px">← Retour</button>'
      + '<div style="display:flex;justify-content:space-between;align-items:flex-start">'
        + '<div>'
          + '<p style="font-size:20px;font-weight:700;color:'+hexA("#FFFFFF",.92)+'">'+(surah.tr?esc(surah.tr):esc(surah.fr))+'</p>'
          + (surah.tr?'<p style="font-size:16px;color:'+hexA("#FFFFFF",.7)+';font-style:italic">'+esc(surah.fr)+'</p>':'')
          + '<p style="font-size:17px;color:'+hexA(goldT(),.6)+'">'+surah.v+' versets · '+(surah.t==='M'?'mecquoise':'médinoise')+' · Juz '+surah.j+'</p>'
        + '</div>'
        + '<div style="display:flex;gap:6px;align-items:center">'
          + '<span style="font-size:24px;font-family:Fraunces,Georgia,serif;color:'+goldT()+';direction:rtl">'+surah.ar+'</span>'
          + '<button onclick="S.quranMode=S.quranMode===\'both\'?\'arabic\':\'both\';render()" title="Arabe seul" style="min-width:34px;height:34px;padding:0 8px;border-radius:9px;border:1px solid '+hexA(goldT(),.4)+';background:'+(S.quranMode==='arabic'?''+hexA(goldT(),.22)+'':'transparent')+';color:'+goldT()+';font-size:19px;cursor:pointer">ع</button>'
          + '<button onclick="S.quranReciterPicker=!S.quranReciterPicker;render()" title="Récitateur" style="min-width:34px;height:34px;padding:0 8px;border-radius:9px;border:1px solid '+hexA(goldT(),.4)+';background:transparent;color:'+goldT()+';font-size:19px;cursor:pointer">🎙</button>'
          + '<input id="VJUMP" type="number" inputmode="numeric" min="1" max="'+surah.v+'" placeholder="v." onkeydown="if(event.key===\'Enter\')jumpVerse('+num+',this.value)" onblur="if(this.value)jumpVerse('+num+',this.value)" style="width:48px;height:34px;padding:0 5px;border-radius:9px;border:1px solid '+hexA(goldT(),.4)+';background:'+hexA(goldT(),.12)+';color:'+goldT()+';font-size:18px;text-align:center;font-family:inherit">'
        + '</div>'
      + '</div>'
      + '<div style="position:absolute;left:0;right:0;bottom:0;height:1.5px;background:linear-gradient(90deg,transparent,rgba(191,174,85,.7) 30%,rgba(191,174,85,.95) 50%,rgba(191,174,85,.7) 70%,transparent)"></div>'
    + '</div>'
    // Picker récitateur
    + (S.quranReciterPicker ? recitersPanel() : '')
    // Contexte et infos
    + contextPanel(num)
    // Versets
    + '<div style="padding:10px 14px">'
      + (num !== 9 ? '<p style="text-align:center;font-family:Fraunces,Georgia,serif;font-size:'+(fs+2)+'px;color:'+gold()+';direction:rtl;margin-bottom:8px;text-shadow:0 0 8px rgba(191,174,85,.2)">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>' : '')
      + '<p style="text-align:center;font-size:14px;color:'+tx2()+';opacity:.75;margin-bottom:12px">📖 tafsir Ibn Kathir complet · 🔖 signet · ▶ écoute</p>'
      + (S.quranLoading
          ? [0,1,2,3].map(function(k){
              return '<div style="background:'+bg2()+';border:1px solid '+br()+';border-radius:15px;padding:14px;margin-bottom:13px">'
                + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">'
                  + '<div class="skel" style="width:30px;height:30px;border-radius:50%"></div>'
                  + '<div class="skel" style="width:90px;height:14px"></div>'
                + '</div>'
                + '<div class="skel" style="width:100%;height:20px;margin-bottom:9px;margin-left:auto"></div>'
                + '<div class="skel" style="width:75%;height:20px;margin-bottom:14px;margin-left:auto"></div>'
                + '<div class="skel" style="width:100%;height:14px;margin-bottom:6px"></div>'
                + '<div class="skel" style="width:55%;height:14px"></div>'
              + '</div>';
            }).join('')
          : S.quranVerses.map(function(v) {
              var isPlaying = S.quranAudioVerse === v.n;
              var isBkd = S.quranBookmarks[num] === v.n;
              return '<div id="VRS_'+num+'_'+v.n+'" style="margin-bottom:13px;padding:12px 12px 10px;border-radius:15px;background:'+(isBkd?(S.dark?'rgba(217,172,88,.08)':'rgba(143,106,28,.06)'):bg2())+';border:1px solid '+(isBkd?'rgba(191,174,85,.45)':br())+';box-shadow:0 1px 3px '+(S.dark?'rgba(0,0,0,.25)':'rgba(26,58,42,.04)')+'">'
                + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:7px">'
                  + '<div style="width:27px;height:27px;border-radius:50%;background:'+(S.dark?'rgba(217,172,88,.1)':'rgba(26,58,42,.07)')+';border:1.5px solid rgba(191,174,85,.5);display:flex;align-items:center;justify-content:center;transform:rotate(45deg)"><span style="font-size:15px;font-weight:700;color:'+gold()+';transform:rotate(-45deg)">'+v.n+'</span></div>'
                  + '<div style="display:flex;gap:2px">'
                    + '<button onclick="toggleIK('+num+','+v.n+')" title="Tafsir Ibn Kathir" style="width:36px;height:36px;background:none;border:none;font-size:19px;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:10px;color:'+(S.ikOpen===num+':'+v.n?gold():'rgba(180,140,70,.45)')+';'+(S.ikOpen===num+':'+v.n?'background:rgba(191,174,85,.12)':'')+'">📖</button>'
                    + '<button onclick="shareVerse('+num+','+v.n+')" title="Partager" style="width:36px;height:36px;background:none;border:none;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:10px;color:rgba(180,140,70,.45)">↗</button>'
                    + '<button onclick="toggleBkm('+num+','+v.n+')" title="Signet" style="width:36px;height:36px;background:none;border:none;font-size:19px;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:10px;color:'+(isBkd?gold():'rgba(180,140,70,.45)')+'">🔖</button>'
                    + '<button onclick="playVerse('+num+','+v.n+')" title="Écouter" style="width:36px;height:36px;border-radius:10px;border:1px solid '+(isPlaying?gold():br())+';background:'+(isPlaying?'rgba(191,174,85,.15)':'transparent')+';color:'+(isPlaying?gold():tx2())+';font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center">'+(isPlaying?'⏸':'▶')+'</button>'
                  + '</div>'
                + '</div>'
                + '<p style="font-family:Fraunces,Georgia,serif;font-size:'+(fs+2)+'px;direction:rtl;text-align:right;line-height:2.15;color:'+tx()+';margin-bottom:'+(S.quranMode==='both'?'7':'2')+'px">'+v.ar+'</p>'
                + (S.quranMode === 'both' ? '<p style="font-size:18px;color:'+tx2()+';line-height:1.7;margin-bottom:'+(TAFSIR_VERSES[num+':'+v.n]?'7':'2')+'px">'+esc(v.fr)+'</p>' : '')
                + (TAFSIR_VERSES[num+':'+v.n]
                    ? '<div style="background:'+(S.dark?'rgba(217,172,88,.07)':'rgba(26,58,42,.05)')+';border-left:2.5px solid rgba(191,174,85,.55);border-radius:0 10px 10px 0;padding:7px 10px;margin-top:3px"><p style="font-size:16px;color:'+gold()+';font-weight:700;margin-bottom:2px;letter-spacing:.04em">💡 TAFSIR</p><p style="font-size:17px;color:'+tx()+';line-height:1.7">'+esc(TAFSIR_VERSES[num+':'+v.n])+'</p></div>'
                    : '')
                + ikPanel(num, v.n)
              + '</div>';
            }).join('')
        )
    + '</div>'
  + '</div>';
}

var RECITERS = [
  {id:'Alafasy_128kbps',                name:'Mishary Al-Afasy',         flag:'🇰🇼'},
  {id:'Yasser_Ad-Dussary_128kbps',      name:'Yasser Al-Dossari',        flag:'🇸🇦'},
  {id:'Abdurrahmaan_As-Sudais_192kbps', name:'Abdurrahman As-Sudais',    flag:'🇸🇦'},
  {id:'MaherAlMuaiqly128kbps',          name:'Maher Al-Muaiqly',         flag:'🇸🇦'},
  {id:'Husary_128kbps',                 name:'Mahmoud Khalil Al-Husary', flag:'🇪🇬'},
  {id:'Abu_Bakr_Ash-Shaatree_128kbps',  name:'Abu Bakr Ash-Shatri',      flag:'🇸🇦'},
];

function recitersPanel() {
  return '<div style="background:'+bg2()+';border-bottom:1px solid '+br()+';padding:10px 14px">'
    + '<p style="font-size:18px;font-weight:600;color:'+tx()+';margin-bottom:7px">Récitateur</p>'
    + RECITERS.map(function(r) {
        var on = S.quranReciter === r.id;
        return '<button onclick="S.quranReciter=\''+r.id+'\';S.quranReciterPicker=false;render()" style="display:flex;align-items:center;gap:7px;width:100%;padding:6px 8px;border-radius:8px;border:none;background:'+(on?'rgba(191,174,85,.1)':'transparent')+';cursor:pointer;margin-bottom:2px">'
          + '<span style="font-size:19px">'+r.flag+'</span>'
          + '<span style="font-size:18px;color:'+(on?gold():tx())+';font-weight:'+(on?'700':'400')+'">'+r.name+'</span>'
          + (on ? '<span style="margin-left:auto;color:'+gold()+';font-size:17px">✓</span>' : '')
        + '</button>';
      }).join('')
  + '</div>';
}

function cycleMem(n) {
  var order = [undefined,'todo','learning','learned'];
  var cur = S.quranMemory[n];
  var idx = order.indexOf(cur);
  var next = order[(idx+1) % order.length];
  if (!next) delete S.quranMemory[n];
  else S.quranMemory[n] = next;
  save(); render();
}

function toggleBkm(surah, verse) {
  if (S.quranBookmarks[surah] === verse) delete S.quranBookmarks[surah];
  else S.quranBookmarks[surah] = verse;
  save(); render();
}

function playVerse(surah, verse) {
  if (S.quranAudioVerse === verse && S.quranAudio) {
    S.quranAudio.pause(); S.quranAudio = null; S.quranAudioVerse = null;
    render(); return;
  }
  if (S.quranAudio) { S.quranAudio.pause(); S.quranAudio = null; }
  var s = String(surah).padStart(3,'0');
  var v = String(verse).padStart(3,'0');
  S.quranAudio = new Audio('https://everyayah.com/data/'+S.quranReciter+'/'+s+v+'.mp3');
  S.quranAudioVerse = verse;
  S.quranAudio.onended = function() { S.quranAudioVerse = null; render(); };
  S.quranAudio.onerror = function() { S.quranAudioVerse = null; render(); };
  S.quranAudio.play().catch(function() { S.quranAudioVerse = null; render(); });
  render();
}


