// ── Page liste Coran ─────────────────────────────────────────────
function pageCoran() {
  if (S.quranSurah !== null) return pageCoranRead();
  var q = S.quranSearch.toLowerCase().trim();
  var results = SURAHS;

  if (q) {
    // Recherche thématique améliorée
    var themeNums = null;
    var themeMatched = null;
    for (var theme in SEARCH_THEMES) {
      if (q === theme || q.includes(theme) || theme.includes(q)) {
        if (!themeNums || SEARCH_THEMES[theme].length > themeNums.length) {
          themeNums = SEARCH_THEMES[theme];
          themeMatched = theme;
        }
      }
    }
    if (themeNums) {
      results = SURAHS.filter(function(s) { return themeNums.indexOf(s.n) !== -1; });
    }
    if (themeNums) {
      results = SURAHS.filter(function(s) { return themeNums.indexOf(s.n) !== -1; });
    } else {
      results = SURAHS.filter(function(s) {
        var norm = function(x){ return x.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[\s'-]/g,''); };
        var nq = norm(q);
        return norm(s.fr).includes(nq) || (s.tr && norm(s.tr).includes(nq)) || s.ar.includes(S.quranSearch) || String(s.n) === q;
      });
    }
  }

  var memLabels = {todo:'○',learning:'~',learned:'✓'};
  var memColors = {todo:tx2(),learning:gold(),learned:'#4CAF50'};
  var fsSizes = ['S','M','L'];

  return hdr('Coran · 114 sourates','Lecture · Recherche · Mémorisation')
    + '<div style="padding:8px 14px 4px;background:'+bg()+'">'
      // Barre de recherche
      + '<div style="position:relative;margin-bottom:8px">'
        + '<input id="QSEARCH" value="'+esc(S.quranSearch)+'" oninput="S.quranSearch=this.value;render()" placeholder="🔍 Sourate, thème… (tristesse, paradis…)" style="width:100%;padding:7px 32px 7px 10px;border-radius:11px;border:1.5px solid '+(S.quranSearch?gold():br())+';background:'+bg2()+';color:'+tx()+';font-size:18px;font-family:inherit;box-sizing:border-box">'
        + (S.quranSearch ? '<button onclick="S.quranSearch=\'\';render()" style="position:absolute;right:8px;top:50%;transform:translateY(-50%);background:none;border:none;color:'+tx2()+';font-size:21px;cursor:pointer">×</button>' : '')
      + '</div>'
      // Contrôles taille
      + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">'
        + '<span style="font-size:17px;color:'+tx2()+'">'+(results.length)+' sourate(s)</span>'
        + '<div style="display:flex;gap:4px">'
          + fsSizes.map(function(s,i) {
              return '<button onclick="S.quranFont='+i+';render()" style="width:28px;height:28px;border-radius:8px;border:1px solid '+(S.quranFont===i?gold():br())+';background:'+(S.quranFont===i?'rgba(191,174,85,.15)':'transparent')+';color:'+(S.quranFont===i?gold():tx2())+';font-size:'+(7+i)+'px;cursor:pointer">'+s+'</button>';
            }).join('')
        + '</div>'
      + '</div>'
      // Téléchargement intégral hors-ligne
      + (function(){
          var off = offlineCount();
          if (DL_STATE.running) {
            var pct = Math.round((DL_STATE.done/114)*100);
            return '<div style="border:1px solid '+br()+';border-radius:12px;padding:9px 12px;margin-bottom:6px;background:'+bg2()+'">'
              + '<div style="display:flex;justify-content:space-between;margin-bottom:5px"><span style="font-size:17px;color:'+tx()+';font-weight:600">Téléchargement du Coran…</span><span style="font-size:17px;color:'+gold()+';font-weight:700">'+DL_STATE.done+'/114</span></div>'
              + '<div style="height:6px;border-radius:3px;background:'+(S.dark?'rgba(191,174,85,.12)':'rgba(26,58,42,.1)')+';overflow:hidden"><div style="height:100%;width:'+pct+'%;border-radius:3px;background:linear-gradient(90deg,'+gold()+','+goldStrong()+');transition:width .3s"></div></div>'
            + '</div>';
          }
          if (off >= 114) {
            return '<div style="display:flex;align-items:center;gap:7px;border:1px solid rgba(76,175,80,.35);border-radius:12px;padding:8px 12px;margin-bottom:6px;background:'+(S.dark?'rgba(76,175,80,.08)':'rgba(76,175,80,.06)')+'"><span style="font-size:18px">✓</span><span style="font-size:17px;color:'+(S.dark?'#7FC98B':'#2E7D32')+';font-weight:600">Coran complet disponible hors-ligne (114/114)</span></div>';
          }
          return '<button onclick="downloadFullQuran()" style="width:100%;display:flex;align-items:center;justify-content:center;gap:8px;border:1px solid '+gold()+';border-radius:12px;padding:10px;margin-bottom:6px;background:'+(S.dark?'rgba(217,172,88,.08)':'rgba(143,106,28,.06)')+';color:'+gold()+';font-size:18px;font-weight:700;cursor:pointer;font-family:inherit;min-height:44px">⬇ Télécharger le Coran complet <span style="font-weight:400;opacity:.75">('+off+'/114 hors-ligne)</span></button>';
        })()
    + '</div>'
    // Liste
    + (results._theme ? '<div style="background:rgba(191,174,85,.1);border:1px solid rgba(191,174,85,.25);border-radius:10px;padding:6px 12px;margin:4px 14px 0;display:flex;align-items:center;gap:6px"><span style="font-size:18px;color:'+gold()+'">🔍 Thème : ' + esc(results._theme||'') + '</span><span style="font-size:17px;color:'+tx2()+'">' + results.length + ' sourate(s) trouvée(s)</span></div>' : '')
    + '<div style="padding:0 14px 8px">'
      + (results.length === 0
          ? '<p style="text-align:center;color:'+tx2()+';font-size:19px;padding:30px 0">Aucune sourate trouvée</p>'
          : results.map(function(s) {
              var mem = S.quranMemory[s.n];
              var bkd = S.quranBookmarks[s.n];
              return '<div style="display:flex;gap:0;margin-bottom:5px;border-radius:14px;overflow:hidden;border:1px solid '+(mem?memColors[mem]+'40':br())+';box-shadow:0 1px 3px '+(S.dark?'rgba(0,0,0,.22)':'rgba(26,58,42,.04)')+'">'
                + '<button onclick="openSurah('+s.n+')" style="flex:1;background:'+bg2()+';border:none;padding:10px 11px;display:flex;align-items:center;gap:9px;cursor:pointer;text-align:left;min-height:54px">'
                  + '<div style="width:31px;height:31px;border-radius:50%;background:'+(S.dark?'rgba(217,172,88,.1)':'rgba(26,58,42,.07)')+';border:1.5px solid rgba(191,174,85,.45);display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative;transform:rotate(45deg)">'
                    + '<span style="font-size:16px;font-weight:700;color:'+gold()+';transform:rotate(-45deg)">'+s.n+'</span>'
                    + (bkd ? '<div style="position:absolute;top:-3px;right:-3px;width:8px;height:8px;border-radius:4px;background:'+gold()+';transform:rotate(-45deg)"></div>' : '')
                  + '</div>'
                  + '<div style="flex:1;min-width:0">'
                    + '<div style="display:flex;justify-content:space-between;align-items:center">'
                      + '<span style="font-size:19px;font-weight:600;color:'+tx()+'">'+(s.tr?esc(s.tr):esc(s.fr))+'</span>'
                      + '<span style="font-size:20px;font-family:Fraunces,Georgia,serif;color:'+goldT()+';direction:rtl">'+s.ar+'</span>'
                    + '</div>'
                    + '<div style="display:flex;gap:5px;margin-top:2px;align-items:center;flex-wrap:wrap">'
                      + (s.tr?'<span style="font-size:15px;color:'+tx2()+';font-style:italic">'+esc(s.fr)+'</span>':'')
                      + '<span style="font-size:16px;color:'+(s.t==='M'?(S.dark?'#9BD3B0':'#1A3A2A'):(S.dark?'#9FC4DB':'#1A5276'))+';background:'+(s.t==='M'?(S.dark?'rgba(155,211,176,.12)':'rgba(26,58,42,.08)'):(S.dark?'rgba(159,196,219,.12)':'rgba(26,82,118,.08)'))+';border-radius:5px;padding:1px 6px">'+(s.t==='M'?'mecquoise':'médinoise')+'</span>'
                      + '<span style="font-size:16px;color:'+tx2()+'">· '+s.v+'v · J'+s.j+'</span>'
                      + (isSurahOffline(s.n) ? '<span style="font-size:16px;color:'+(S.dark?'#7FC98B':'#2E7D32')+'">· hors-ligne</span>' : '')
                    + '</div>'
                  + '</div>'
                + '</button>'
                + '<button onclick="cycleMem('+s.n+')" style="padding:0 9px;border:none;border-left:1px solid '+br()+';background:'+(mem?'rgba(191,174,85,.08)':'transparent')+';color:'+(mem?memColors[mem]:tx2())+';font-size:21px;cursor:pointer;flex-shrink:0">'+(mem?memLabels[mem]:'+')+'</button>'
                + '<button onclick="openSurah('+s.n+')" style="padding:0 9px;border:none;border-left:1px solid '+br()+';background:rgba(26,58,42,.08);color:'+gold()+';font-size:19px;cursor:pointer;flex-shrink:0">📖</button>'
              + '</div>';
            }).join('')
        )
    + '</div>';
}

function openSurah(num) {
  S.quranSurah = num;
  markLastRead(num, (S.profil.lastRead && S.profil.lastRead.surah === num) ? S.profil.lastRead.verse : null);
  S.quranVerses = [];
  S.quranLoading = false;
  try { history.pushState({page:'coran', surah:num}, ''); } catch(e) {}
  var meta = SURAHS.find(function(s){ return s.n === num; });
  var expected = meta ? meta.v : 0;
  // 1. Texte embarqué SEULEMENT s'il est complet (les extraits partiels ne suffisent pas)
  if (QURAN_LOCAL[num] && QURAN_LOCAL[num].length === expected) {
    S.quranVerses = QURAN_LOCAL[num];
    render();
  // 2. Cache téléchargé complet
  } else if (S.cachedSurahs[num] && S.cachedSurahs[num].length === expected) {
    S.quranVerses = S.cachedSurahs[num];
    render();
  // 3. Téléchargement de la sourate entière
  } else {
    S.quranLoading = true;
    render();
    fetch('https://api.alquran.cloud/v1/surah/'+num+'/editions/quran-uthmani,fr.hamidullah')
      .then(function(r) { return r.json(); })
      .then(function(data) {
        var ar = data.data[0].ayahs;
        var fr = data.data[1].ayahs;
        S.quranVerses = ar.map(function(a,i) { return {n:a.numberInSurah, ar:a.text, fr:fr[i].text}; });
        S.cachedSurahs[num] = S.quranVerses;
        S.quranLoading = false;
        saveQuran();
        render();
      })
      .catch(function() {
        // Hors-ligne : afficher l'extrait local s'il existe, avec avertissement
        if (QURAN_LOCAL[num] && QURAN_LOCAL[num].length) {
          S.quranVerses = QURAN_LOCAL[num].concat([{n:0, ar:'', fr:'⚠ Extrait partiel ('+QURAN_LOCAL[num].length+'/'+expected+' versets). Connectez-vous une fois pour télécharger la sourate complète.'}]);
        } else {
          S.quranVerses = [{n:0, ar:'', fr:'Hors-ligne · Connectez-vous une fois pour télécharger cette sourate.'}];
        }
        S.quranLoading = false;
        render();
      });
  }
}

