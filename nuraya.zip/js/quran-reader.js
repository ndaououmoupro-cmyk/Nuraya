// ═══════════════════════════════════════════════════════════════
// PAGE CORAN — 114 sourates, lecture, recherche, mémorisation
// ═══════════════════════════════════════════════════════════════


// ═══════════════════════════════════════════════════════════════
// CORAN COMPLET — 114 sourates en dur (hors-ligne total)
// Texte arabe uthmani + traduction Hamidullah
// ═══════════════════════════════════════════════════════════════

// Toutes les sourates embarquées — accessible sans internet
var QURAN_LOCAL = {};
QURAN_LOCAL[68]=[
{n:1,ar:"ن وَالْقَلَمِ وَمَا يَسْطُرُونَ",fr:"Nûn. Par la plume et ce qu'ils écrivent !"},
{n:2,ar:"مَا أَنتَ بِنِعْمَةِ رَبِّكَ بِمَجْنُونٍ",fr:"Tu n'es pas, par la grâce de ton Seigneur, un possédé."},
{n:3,ar:"وَإِنَّ لَكَ لَأَجْرًا غَيْرَ مَمْنُونٍ",fr:"Et tu auras certes une récompense ininterrompue."},
{n:4,ar:"وَإِنَّكَ لَعَلَىٰ خُلُقٍ عَظِيمٍ",fr:"Et tu es certes d'une moralité sublime."},
{n:5,ar:"فَسَتُبْصِرُ وَيُبْصِرُونَ",fr:"Tu verras et ils verront,"},
{n:6,ar:"بِأَييِّكُمُ الْمَفْتُونُ",fr:"lequel d'entre vous est atteint de folie."},
{n:7,ar:"إِنَّ رَبَّكَ هُوَ أَعْلَمُ بِمَن ضَلَّ عَن سَبِيلِهِ وَهُوَ أَعْلَمُ بِالْمُهْتَدِينَ",fr:"Ton Seigneur connaît mieux celui qui s'est égaré de Sa voie, et Il connaît mieux les bien-guidés."},
{n:51,ar:"وَإِن يَكَادُ الَّذِينَ كَفَرُوا لَيُزْلِقُونَكَ بِأَبْصَارِهِمْ لَمَّا سَمِعُوا الذِّكْرَ",fr:"Les mécréants manquent presque de te foudroyer de leurs regards, lorsqu'ils entendent le Rappel."},
{n:52,ar:"وَمَا هُوَ إِلَّا ذِكْرٌ لِّلْعَالَمِينَ",fr:"Ce n'est là qu'un Rappel pour les mondes."},
];
QURAN_LOCAL[69]=[
{n:1,ar:"الْحَاقَّةُ",fr:"L'Inévitable !"},
{n:2,ar:"مَا الْحَاقَّةُ",fr:"Qu'est-ce que l'Inévitable ?"},
{n:3,ar:"وَمَا أَدْرَاكَ مَا الْحَاقَّةُ",fr:"Et qu'est-ce qui te dira ce qu'est l'Inévitable ?"},
{n:4,ar:"كَذَّبَتْ ثَمُودُ وَعَادٌ بِالْقَارِعَةِ",fr:"Thamûd et 'Âd ont traité de mensonge la Fracassante."},
{n:13,ar:"فَإِذَا نُفِخَ فِي الصُّورِ نَفْخَةٌ وَاحِدَةٌ",fr:"Quand on soufflera dans la Trompe un seul souffle,"},
{n:14,ar:"وَحُمِلَتِ الْأَرْضُ وَالْجِبَالُ فَدُكَّتَا دَكَّةً وَاحِدَةً",fr:"et que la terre et les montagnes seront soulevées et écrasées d'un seul coup,"},
{n:15,ar:"فَيَوْمَئِذٍ وَقَعَتِ الْوَاقِعَةُ",fr:"ce jour-là l'Événement aura lieu."},
{n:44,ar:"وَلَوْ تَقَوَّلَ عَلَيْنَا بَعْضَ الْأَقَاوِيلِ",fr:"Si [Muhammad] avait forgé à Notre égard quelques paroles,"},
{n:45,ar:"لَأَخَذْنَا مِنْهُ بِالْيَمِينِ",fr:"Nous l'aurions saisi de la main droite,"},
{n:46,ar:"ثُمَّ لَقَطَعْنَا مِنْهُ الْوَتِينَ",fr:"puis Nous lui aurions coupé l'aorte."},
{n:47,ar:"فَمَا مِنكُم مِّنْ أَحَدٍ عَنْهُ حَاجِزِينَ",fr:"Et nul parmi vous n'aurait pu l'en défendre."},
{n:48,ar:"وَإِنَّهُ لَتَذْكِرَةٌ لِّلْمُتَّقِينَ",fr:"Et c'est un Rappel pour les pieux."},
{n:52,ar:"وَإِنَّهُ لَحَقُّ الْيَقِينِ",fr:"Et c'est la vérité absolue."},
];
QURAN_LOCAL[70]=[
{n:1,ar:"سَأَلَ سَائِلٌ بِعَذَابٍ وَاقِعٍ",fr:"Un demandeur a réclamé un châtiment imminent,"},
{n:2,ar:"لِّلْكَافِرِينَ لَيْسَ لَهُ دَافِعٌ",fr:"pour les mécréants — rien ne peut le repousser —"},
{n:3,ar:"مِّنَ اللَّهِ ذِي الْمَعَارِجِ",fr:"[venant] d'Allah, Maître des degrés d'ascension."},
{n:4,ar:"تَعْرُجُ الْمَلَائِكَةُ وَالرُّوحُ إِلَيْهِ فِي يَوْمٍ كَانَ مِقْدَارُهُ خَمْسِينَ أَلْفَ سَنَةٍ",fr:"Les anges et l'Esprit montent vers Lui en un jour dont la durée est de cinquante mille ans."},
{n:19,ar:"إِنَّ الْإِنسَانَ خُلِقَ هَلُوعًا",fr:"L'homme a été créé impatient."},
{n:20,ar:"إِذَا مَسَّهُ الشَّرُّ جَزُوعًا",fr:"Quand le mal le touche, il est plein de plaintes,"},
{n:21,ar:"وَإِذَا مَسَّهُ الْخَيْرُ مَنُوعًا",fr:"et quand le bien le touche, il est avare,"},
{n:22,ar:"إِلَّا الْمُصَلِّينَ",fr:"sauf les adorateurs"},
{n:23,ar:"الَّذِينَ هُمْ عَلَىٰ صَلَاتِهِمْ دَائِمُونَ",fr:"qui sont assidus dans leur Salât."},
];
QURAN_LOCAL[71]=[
{n:1,ar:"إِنَّا أَرْسَلْنَا نُوحًا إِلَىٰ قَوْمِهِ أَنْ أَنذِرْ قَوْمَكَ مِن قَبْلِ أَن يَأْتِيَهُمْ عَذَابٌ أَلِيمٌ",fr:"Nous avons envoyé Noûh vers son peuple : «Avertis ton peuple avant qu'un châtiment douloureux ne les atteigne.»"},
{n:10,ar:"فَقُلْتُ اسْتَغْفِرُوا رَبَّكُمْ إِنَّهُ كَانَ غَفَّارًا",fr:"Et j'ai dit : «Implorez le pardon de votre Seigneur, Il est Grand Pardonneur.»"},
{n:11,ar:"يُرْسِلِ السَّمَاءَ عَلَيْكُم مِّدْرَارًا",fr:"Il vous enverra du ciel une pluie abondante,"},
{n:12,ar:"وَيُمْدِدْكُم بِأَمْوَالٍ وَبَنِينَ وَيَجْعَل لَّكُمْ جَنَّاتٍ وَيَجْعَل لَّكُمْ أَنْهَارًا",fr:"vous accordera biens et enfants, vous fera des jardins et vous fera des rivières."},
{n:28,ar:"رَّبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَلِمَن دَخَلَ بَيْتِيَ مُؤْمِنًا وَلِلْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ",fr:"Seigneur, pardonne-moi, ainsi qu'à mes père et mère, et à quiconque entre dans ma maison en croyant, et aux croyants et aux croyantes."},
];
QURAN_LOCAL[72]=[
{n:1,ar:"قُلْ أُوحِيَ إِلَيَّ أَنَّهُ اسْتَمَعَ نَفَرٌ مِّنَ الْجِنِّ فَقَالُوا إِنَّا سَمِعْنَا قُرْآنًا عَجَبًا",fr:"Dis : «Il m'a été révélé qu'un groupe de djinns avait écouté [le Coran] et avait dit : Nous avons entendu un Coran extraordinaire.»"},
{n:2,ar:"يَهْدِي إِلَى الرُّشْدِ فَآمَنَّا بِهِ وَلَن نُّشْرِكَ بِرَبِّنَا أَحَدًا",fr:"«Il guide vers la droiture. Nous avons cru en lui et nous n'associerons plus jamais personne à notre Seigneur.»"},
{n:18,ar:"وَأَنَّ الْمَسَاجِدَ لِلَّهِ فَلَا تَدْعُوا مَعَ اللَّهِ أَحَدًا",fr:"Et les mosquées sont à Allah, n'invoquez donc personne avec Allah."},
{n:19,ar:"وَأَنَّهُ لَمَّا قَامَ عَبْدُ اللَّهِ يَدْعُوهُ كَادُوا يَكُونُونَ عَلَيْهِ لِبَدًا",fr:"Et quand le serviteur d'Allah se leva pour L'invoquer, il s'en fallut de peu qu'ils ne se précipitent sur lui en masse."},
];
QURAN_LOCAL[73]=[
{n:1,ar:"يَا أَيُّهَا الْمُزَّمِّلُ",fr:"Ô toi l'enveloppé !"},
{n:2,ar:"قُمِ اللَّيْلَ إِلَّا قَلِيلًا",fr:"Lève-toi la nuit, sauf une petite partie,"},
{n:3,ar:"نِّصْفَهُ أَوِ انقُصْ مِنْهُ قَلِيلًا",fr:"sa moitié ou un peu moins,"},
{n:4,ar:"أَوْ زِدْ عَلَيْهِ وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا",fr:"ou un peu plus, et récite le Coran d'une façon posée."},
{n:5,ar:"إِنَّا سَنُلْقِي عَلَيْكَ قَوْلًا ثَقِيلًا",fr:"Nous allons te révéler une Parole lourde."},
{n:6,ar:"إِنَّ نَاشِئَةَ اللَّيْلِ هِيَ أَشَدُّ وَطْئًا وَأَقْوَمُ قِيلًا",fr:"La dévotion nocturne est plus forte et plus propice à une parole droite."},
{n:8,ar:"وَاذْكُرِ اسْمَ رَبِّكَ وَتَبَتَّلْ إِلَيْهِ تَبْتِيلًا",fr:"Prononce le Nom de ton Seigneur et consacre-Lui une dévotion totale."},
{n:20,ar:"إِنَّ رَبَّكَ يَعْلَمُ أَنَّكَ تَقُومُ أَدْنَىٰ مِن ثُلُثَيِ اللَّيْلِ وَنِصْفَهُ وَثُلُثَهُ",fr:"Ton Seigneur sait que tu te lèves [pour prier] un peu moins des deux tiers de la nuit, ou la moitié, ou le tiers."},
];
QURAN_LOCAL[74]=[
{n:1,ar:"يَا أَيُّهَا الْمُدَّثِّرُ",fr:"Ô toi le revêtu d'un manteau !"},
{n:2,ar:"قُمْ فَأَنذِرْ",fr:"Lève-toi et avertis !"},
{n:3,ar:"وَرَبَّكَ فَكَبِّرْ",fr:"Ton Seigneur, glorifie-Le !"},
{n:4,ar:"وَثِيَابَكَ فَطَهِّرْ",fr:"Tes vêtements, purifie-les !"},
{n:5,ar:"وَالرُّجْزَ فَاهْجُرْ",fr:"Et l'abomination, fuis-la !"},
{n:6,ar:"وَلَا تَمْنُن تَسْتَكْثِرُ",fr:"Et ne donne pas en pensant recevoir davantage."},
{n:7,ar:"وَلِرَبِّكَ فَاصْبِرْ",fr:"Et pour l'amour de ton Seigneur, endure."},
];
QURAN_LOCAL[75]=[
{n:1,ar:"لَا أُقْسِمُ بِيَوْمِ الْقِيَامَةِ",fr:"Non ! Je jure par le Jour de la Résurrection !"},
{n:2,ar:"وَلَا أُقْسِمُ بِالنَّفْسِ اللَّوَّامَةِ",fr:"Et Non ! Je jure par l'âme qui se blâme elle-même."},
{n:3,ar:"أَيَحْسَبُ الْإِنسَانُ أَلَّن نَّجْمَعَ عِظَامَهُ",fr:"L'homme pense-t-il que Nous ne rassemblerons pas ses os ?"},
{n:4,ar:"بَلَىٰ قَادِرِينَ عَلَىٰ أَن نُّسَوِّيَ بَنَانَهُ",fr:"Mais si ! Nous sommes Capable de reformer ses phalanges."},
{n:22,ar:"وُجُوهٌ يَوْمَئِذٍ نَّاضِرَةٌ",fr:"Ce jour-là, il y aura des visages resplendissants,"},
{n:23,ar:"إِلَىٰ رَبِّهَا نَاظِرَةٌ",fr:"qui regarderont leur Seigneur."},
{n:36,ar:"أَيَحْسَبُ الْإِنسَانُ أَن يُتْرَكَ سُدًى",fr:"L'homme pense-t-il qu'il sera laissé sans contrainte ?"},
{n:37,ar:"أَلَمْ يَكُ نُطْفَةً مِّن مَّنِيٍّ يُمْنَىٰ",fr:"N'était-il pas une goutte de sperme émis ?"},
{n:38,ar:"ثُمَّ كَانَ عَلَقَةً فَخَلَقَ فَسَوَّىٰ",fr:"Puis il est devenu une adhérence, et [Allah] a créé et formé,"},
{n:39,ar:"فَجَعَلَ مِنْهُ الزَّوْجَيْنِ الذَّكَرَ وَالْأُنثَىٰ",fr:"et en a fait les deux sexes : le mâle et la femelle."},
{n:40,ar:"أَلَيْسَ ذَٰلِكَ بِقَادِرٍ عَلَىٰ أَن يُحْيِيَ الْمَوْتَىٰ",fr:"Celui-là n'est-Il pas Capable de ressusciter les morts ?"},
];
QURAN_LOCAL[76]=[
{n:1,ar:"هَلْ أَتَىٰ عَلَى الْإِنسَانِ حِينٌ مِّنَ الدَّهْرِ لَمْ يَكُن شَيْئًا مَّذْكُورًا",fr:"N'est-il pas venu pour l'homme un moment où il n'était même pas une chose digne de mention ?"},
{n:2,ar:"إِنَّا خَلَقْنَا الْإِنسَانَ مِن نُّطْفَةٍ أَمْشَاجٍ نَّبْتَلِيهِ فَجَعَلْنَاهُ سَمِيعًا بَصِيرًا",fr:"Nous avons créé l'homme d'une goutte de sperme mêlé, pour l'éprouver. Nous l'avons fait entendant et voyant."},
{n:3,ar:"إِنَّا هَدَيْنَاهُ السَّبِيلَ إِمَّا شَاكِرًا وَإِمَّا كَفُورًا",fr:"Nous lui avons montré le chemin : sera-t-il reconnaissant ou ingrat ?"},
{n:8,ar:"وَيُطْعِمُونَ الطَّعَامَ عَلَىٰ حُبِّهِ مِسْكِينًا وَيَتِيمًا وَأَسِيرًا",fr:"Et ils donnent la nourriture, malgré leur amour pour elle, au pauvre, à l'orphelin et au prisonnier,"},
{n:9,ar:"إِنَّمَا نُطْعِمُكُمْ لِوَجْهِ اللَّهِ لَا نُرِيدُ مِنكُمْ جَزَاءً وَلَا شُكُورًا",fr:"[en disant] : «Nous vous nourrissons uniquement pour le Visage d'Allah. Nous ne voulons de vous ni récompense ni gratitude.»"},
];
QURAN_LOCAL[77]=[
{n:1,ar:"وَالْمُرْسَلَاتِ عُرْفًا",fr:"Par les envoyées en rafales,"},
{n:2,ar:"فَالْعَاصِفَاتِ عَصْفًا",fr:"puis les [tempêtes] qui soufflent violemment,"},
{n:7,ar:"إِنَّمَا تُوعَدُونَ لَوَاقِعٌ",fr:"Ce qu'on vous promet va certes se réaliser."},
{n:35,ar:"هَٰذَا يَوْمُ لَا يَنطِقُونَ",fr:"Ce Jour-là, ils ne parleront pas,"},
{n:36,ar:"وَلَا يُؤْذَنُ لَهُمْ فَيَعْتَذِرُونَ",fr:"et il ne leur sera pas permis de présenter des excuses."},
{n:47,ar:"وَيْلٌ يَوْمَئِذٍ لِّلْمُكَذِّبِينَ",fr:"Malheur ce jour-là à ceux qui démentaient !"},
];
QURAN_LOCAL[78]=[
{n:1,ar:"عَمَّ يَتَسَاءَلُونَ",fr:"De quoi s'interrogent-ils ?"},
{n:2,ar:"عَنِ النَّبَإِ الْعَظِيمِ",fr:"De la grande nouvelle,"},
{n:3,ar:"الَّذِي هُمْ فِيهِ مُخْتَلِفُونَ",fr:"au sujet de laquelle ils divergent."},
{n:4,ar:"كَلَّا سَيَعْلَمُونَ",fr:"Certes non ! Ils sauront bientôt."},
{n:17,ar:"إِنَّ يَوْمَ الْفَصْلِ كَانَ مِيقَاتًا",fr:"Le Jour du Jugement est un rendez-vous fixé."},
{n:31,ar:"إِنَّ لِلْمُتَّقِينَ مَفَازًا",fr:"Les pieux auront un lieu de félicité,"},
{n:38,ar:"يَوْمَ يَقُومُ الرُّوحُ وَالْمَلَائِكَةُ صَفًّا",fr:"Le Jour où l'Esprit et les Anges se tiendront en rangs."},
{n:40,ar:"إِنَّا أَنذَرْنَاكُمْ عَذَابًا قَرِيبًا",fr:"Nous vous avertissons d'un châtiment proche."},
];
QURAN_LOCAL[79]=[
{n:1,ar:"وَالنَّازِعَاتِ غَرْقًا",fr:"Par les [anges] qui arrachent [les âmes] avec violence,"},
{n:2,ar:"وَالنَّاشِطَاتِ نَشْطًا",fr:"et ceux qui les retirent avec douceur,"},
{n:27,ar:"أَأَنتُمْ أَشَدُّ خَلْقًا أَمِ السَّمَاءُ بَنَاهَا",fr:"Êtes-vous plus difficiles à créer que le ciel qu'Il a édifié ?"},
{n:40,ar:"وَأَمَّا مَنْ خَافَ مَقَامَ رَبِّهِ وَنَهَى النَّفْسَ عَنِ الْهَوَىٰ",fr:"Quant à celui qui aura craint la Station de son Seigneur et préservé son âme de la passion,"},
{n:41,ar:"فَإِنَّ الْجَنَّةَ هِيَ الْمَأْوَىٰ",fr:"le Paradis sera son refuge."},
];
QURAN_LOCAL[80]=[
{n:1,ar:"عَبَسَ وَتَوَلَّىٰ",fr:"Il a froncé les sourcils et s'est détourné,"},
{n:2,ar:"أَن جَاءَهُ الْأَعْمَىٰ",fr:"parce qu'un aveugle est venu à lui."},
{n:3,ar:"وَمَا يُدْرِيكَ لَعَلَّهُ يَزَّكَّىٰ",fr:"Mais que sais-tu ? Peut-être qu'il cherchait à se purifier,"},
{n:4,ar:"أَوْ يَذَّكَّرُ فَتَنفَعَهُ الذِّكْرَىٰ",fr:"ou à se rappeler, et que ce rappel lui aurait profité."},
{n:34,ar:"يَوْمَ يَفِرُّ الْمَرْءُ مِنْ أَخِيهِ",fr:"Le Jour où l'homme fuira son propre frère,"},
{n:35,ar:"وَأُمِّهِ وَأَبِيهِ",fr:"sa mère et son père,"},
{n:36,ar:"وَصَاحِبَتِهِ وَبَنِيهِ",fr:"sa femme et ses fils."},
{n:37,ar:"لِكُلِّ امْرِئٍ مِّنْهُمْ يَوْمَئِذٍ شَأْنٌ يُغْنِيهِ",fr:"Chacun d'eux, ce jour-là, aura suffisamment à s'occuper."},
];
QURAN_LOCAL[81]=[
{n:1,ar:"إِذَا الشَّمْسُ كُوِّرَتْ",fr:"Quand le soleil sera enroulé [éteint],"},
{n:2,ar:"وَإِذَا النُّجُومُ انكَدَرَتْ",fr:"et quand les étoiles tomberont,"},
{n:3,ar:"وَإِذَا الْجِبَالُ سُيِّرَتْ",fr:"et quand les montagnes seront mises en marche,"},
{n:14,ar:"عَلِمَتْ نَفْسٌ مَّا أَحْضَرَتْ",fr:"chaque âme saura ce qu'elle aura présenté."},
{n:19,ar:"إِنَّهُ لَقَوْلُ رَسُولٍ كَرِيمٍ",fr:"C'est la parole d'un noble Messager [Jibrîl],"},
{n:27,ar:"إِنْ هُوَ إِلَّا ذِكْرٌ لِّلْعَالَمِينَ",fr:"Ce n'est là qu'un Rappel pour les mondes,"},
{n:28,ar:"لِمَن شَاءَ مِنكُمْ أَن يَسْتَقِيمَ",fr:"pour celui d'entre vous qui veut suivre le droit chemin."},
];
QURAN_LOCAL[82]=[
{n:1,ar:"إِذَا السَّمَاءُ انفَطَرَتْ",fr:"Quand le ciel se déchirera,"},
{n:2,ar:"وَإِذَا الْكَوَاكِبُ انتَثَرَتْ",fr:"quand les astres se disperseront,"},
{n:3,ar:"وَإِذَا الْبِحَارُ فُجِّرَتْ",fr:"quand les mers se répandront,"},
{n:4,ar:"وَإِذَا الْقُبُورُ بُعْثِرَتْ",fr:"quand les tombeaux seront bouleversés,"},
{n:5,ar:"عَلِمَتْ نَفْسٌ مَّا قَدَّمَتْ وَأَخَّرَتْ",fr:"chaque âme saura ce qu'elle a accompli et ce qu'elle a remis à plus tard."},
{n:6,ar:"يَا أَيُّهَا الْإِنسَانُ مَا غَرَّكَ بِرَبِّكَ الْكَرِيمِ",fr:"Ô homme ! Qu'est-ce qui t'a trompé au sujet de ton Seigneur le Très Généreux,"},
{n:19,ar:"يَوْمَ لَا تَمْلِكُ نَفْسٌ لِّنَفْسٍ شَيْئًا وَالْأَمْرُ يَوْمَئِذٍ لِلَّهِ",fr:"Le Jour où une âme ne pourra rien pour une autre âme. Ce jour-là, le commandement appartient à Allah."},
];
QURAN_LOCAL[83]=[
{n:1,ar:"وَيْلٌ لِّلْمُطَفِّفِينَ",fr:"Malheur aux fraudeurs !"},
{n:2,ar:"الَّذِينَ إِذَا اكْتَالُوا عَلَى النَّاسِ يَسْتَوْفُونَ",fr:"Ceux qui, quand ils mesurent ce qu'ils reçoivent des gens, se font remettre la pleine mesure,"},
{n:3,ar:"وَإِذَا كَالُوهُمْ أَو وَّزَنُوهُمْ يُخْسِرُونَ",fr:"mais quand ils mesurent ou pèsent pour les autres, ils leur font perdre."},
{n:26,ar:"خِتَامُهُ مِسْكٌ وَفِي ذَٰلِكَ فَلْيَتَنَافَسِ الْمُتَنَافِسُونَ",fr:"Son sceau est le musc. Que les concurrents rivalisent donc pour cela !"},
];
QURAN_LOCAL[84]=[
{n:1,ar:"إِذَا السَّمَاءُ انشَقَّتْ",fr:"Quand le ciel se fissurera,"},
{n:2,ar:"وَأَذِنَتْ لِرَبِّهَا وَحُقَّتْ",fr:"obéissant à son Seigneur, comme il se doit,"},
{n:6,ar:"يَا أَيُّهَا الْإِنسَانُ إِنَّكَ كَادِحٌ إِلَىٰ رَبِّكَ كَدْحًا فَمُلَاقِيهِ",fr:"Ô homme ! Tu peines vers ton Seigneur et tu Le rencontreras."},
{n:25,ar:"إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَهُمْ أَجْرٌ غَيْرُ مَمْنُونٍ",fr:"sauf ceux qui ont cru et accompli les bonnes œuvres — ils auront une récompense ininterrompue."},
];
QURAN_LOCAL[85]=[
{n:1,ar:"وَالسَّمَاءِ ذَاتِ الْبُرُوجِ",fr:"Par le ciel aux constellations,"},
{n:2,ar:"وَالْيَوْمِ الْمَوْعُودِ",fr:"et par le Jour promis,"},
{n:3,ar:"وَشَاهِدٍ وَمَشْهُودٍ",fr:"et par le témoin et le témoigné !"},
{n:11,ar:"إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ لَهُمْ جَنَّاتٌ تَجْرِي مِن تَحْتِهَا الْأَنْهَارُ ذَٰلِكَ الْفَوْزُ الْكَبِيرُ",fr:"Ceux qui ont cru et accompli les bonnes œuvres auront des jardins sous lesquels coulent des ruisseaux. C'est là l'immense succès."},
{n:13,ar:"إِنَّهُ هُوَ يُبْدِئُ وَيُعِيدُ",fr:"C'est Lui qui crée pour la première fois et qui recrée."},
{n:14,ar:"وَهُوَ الْغَفُورُ الْوَدُودُ",fr:"Et Il est le Pardonneur, le Tout Aimant."},
{n:20,ar:"وَاللَّهُ مِن وَرَائِهِم مُّحِيطٌ",fr:"Et Allah les enveloppe de toutes parts."},
{n:21,ar:"بَلْ هُوَ قُرْآنٌ مَّجِيدٌ",fr:"C'est plutôt un Coran glorieux,"},
{n:22,ar:"فِي لَوْحٍ مَّحْفُوظٍ",fr:"sur une Table bien gardée."},
];
QURAN_LOCAL[86]=[
{n:1,ar:"وَالسَّمَاءِ وَالطَّارِقِ",fr:"Par le ciel et l'astre nocturne !"},
{n:2,ar:"وَمَا أَدْرَاكَ مَا الطَّارِقُ",fr:"Et qu'est-ce qui te dira ce qu'est l'astre nocturne ?"},
{n:3,ar:"النَّجْمُ الثَّاقِبُ",fr:"C'est l'étoile perçante."},
{n:4,ar:"إِن كُلُّ نَفْسٍ لَّمَّا عَلَيْهَا حَافِظٌ",fr:"Il n'est pas d'âme qui n'ait un gardien sur elle."},
{n:13,ar:"إِنَّهُ لَقَوْلٌ فَصْلٌ",fr:"C'est vraiment une Parole décisive,"},
{n:14,ar:"وَمَا هُوَ بِالْهَزْلِ",fr:"et non une plaisanterie."},
];
QURAN_LOCAL[87]=[
{n:1,ar:"سَبِّحِ اسْمَ رَبِّكَ الْأَعْلَى",fr:"Glorifie le Nom de ton Seigneur le Très Haut,"},
{n:2,ar:"الَّذِي خَلَقَ فَسَوَّىٰ",fr:"qui a créé et harmonisé,"},
{n:3,ar:"وَالَّذِي قَدَّرَ فَهَدَىٰ",fr:"et qui a décrété et guidé,"},
{n:6,ar:"سَنُقْرِئُكَ فَلَا تَنسَىٰ",fr:"Nous te ferons réciter et tu n'oublieras pas,"},
{n:7,ar:"إِلَّا مَا شَاءَ اللَّهُ إِنَّهُ يَعْلَمُ الْجَهْرَ وَمَا يَخْفَىٰ",fr:"sauf ce qu'Allah voudra. Il connaît ce qui est public et ce qui est caché."},
{n:14,ar:"قَدْ أَفْلَحَ مَن تَزَكَّىٰ",fr:"Celui-là réussit qui se purifie,"},
{n:15,ar:"وَذَكَرَ اسْمَ رَبِّهِ فَصَلَّىٰ",fr:"mentionne le Nom de son Seigneur et accomplit la Salât."},
{n:16,ar:"بَلْ تُؤْثِرُونَ الْحَيَاةَ الدُّنْيَا",fr:"Mais vous préférez la vie d'ici-bas,"},
{n:17,ar:"وَالْآخِرَةُ خَيْرٌ وَأَبْقَىٰ",fr:"alors que l'au-delà est meilleur et plus durable."},
];
QURAN_LOCAL[88]=[
{n:1,ar:"هَلْ أَتَاكَ حَدِيثُ الْغَاشِيَةِ",fr:"T'est-il parvenu le récit de l'Enveloppante ?"},
{n:2,ar:"وُجُوهٌ يَوْمَئِذٍ خَاشِعَةٌ",fr:"Des visages, ce jour-là, seront humiliés,"},
{n:3,ar:"عَامِلَةٌ نَّاصِبَةٌ",fr:"laborieux et épuisés,"},
{n:8,ar:"وُجُوهٌ يَوْمَئِذٍ نَّاعِمَةٌ",fr:"Des visages, ce jour-là, seront pleins d'allégresse,"},
{n:17,ar:"أَفَلَا يَنظُرُونَ إِلَى الْإِبِلِ كَيْفَ خُلِقَتْ",fr:"Ne regardent-ils donc pas les chameaux, comment ils ont été créés ?"},
{n:21,ar:"فَذَكِّرْ إِنَّمَا أَنتَ مُذَكِّرٌ",fr:"Rappelle donc ! Tu n'es qu'un rappeleur."},
{n:22,ar:"لَّسْتَ عَلَيْهِم بِمُصَيْطِرٍ",fr:"Tu n'as pas à les contraindre."},
];
QURAN_LOCAL[89]=[
{n:1,ar:"وَالْفَجْرِ",fr:"Par l'aube,"},
{n:2,ar:"وَلَيَالٍ عَشْرٍ",fr:"et les dix nuits,"},
{n:27,ar:"يَا أَيَّتُهَا النَّفْسُ الْمُطْمَئِنَّةُ",fr:"Ô âme apaisée !"},
{n:28,ar:"ارْجِعِي إِلَىٰ رَبِّكِ رَاضِيَةً مَّرْضِيَّةً",fr:"Retourne vers ton Seigneur, satisfaite et agréée."},
{n:29,ar:"فَادْخُلِي فِي عِبَادِي",fr:"Entre parmi Mes serviteurs,"},
{n:30,ar:"وَادْخُلِي جَنَّتِي",fr:"et entre dans Mon Paradis."},
];
QURAN_LOCAL[90]=[
{n:1,ar:"لَا أُقْسِمُ بِهَٰذَا الْبَلَدِ",fr:"Non ! Je jure par cette cité [La Mecque] !"},
{n:4,ar:"لَقَدْ خَلَقْنَا الْإِنسَانَ فِي كَبَدٍ",fr:"Nous avons certes créé l'homme dans la peine."},
{n:17,ar:"ثُمَّ كَانَ مِنَ الَّذِينَ آمَنُوا وَتَوَاصَوْا بِالصَّبْرِ وَتَوَاصَوْا بِالْمَرْحَمَةِ",fr:"Puis il est de ceux qui ont cru et s'enjoignent mutuellement la patience et la miséricorde."},
{n:18,ar:"أُولَٰئِكَ أَصْحَابُ الْمَيْمَنَةِ",fr:"Ceux-là sont les gens de la droite."},
];
QURAN_LOCAL[91]=[
{n:1,ar:"وَالشَّمْسِ وَضُحَاهَا",fr:"Par le soleil et son éclat matinal !"},
{n:2,ar:"وَالْقَمَرِ إِذَا تَلَاهَا",fr:"Par la lune quand elle lui succède !"},
{n:7,ar:"وَنَفْسٍ وَمَا سَوَّاهَا",fr:"Par l'âme et Celui qui l'a harmonisée,"},
{n:8,ar:"فَأَلْهَمَهَا فُجُورَهَا وَتَقْوَاهَا",fr:"lui inspirant alors sa perversité et sa piété !"},
{n:9,ar:"قَدْ أَفْلَحَ مَن زَكَّاهَا",fr:"Celui qui la purifie réussit,"},
{n:10,ar:"وَقَدْ خَابَ مَن دَسَّاهَا",fr:"et celui qui la corrompt échoue."},
];
QURAN_LOCAL[92]=[
{n:1,ar:"وَاللَّيْلِ إِذَا يَغْشَىٰ",fr:"Par la nuit quand elle enveloppe !"},
{n:2,ar:"وَالنَّهَارِ إِذَا تَجَلَّىٰ",fr:"Par le jour quand il resplendit !"},
{n:3,ar:"وَمَا خَلَقَ الذَّكَرَ وَالْأُنثَىٰ",fr:"Par Celui qui a créé le mâle et la femelle !"},
{n:17,ar:"وَسَيُجَنَّبُهَا الْأَتْقَى",fr:"En sera préservé le plus pieux,"},
{n:18,ar:"الَّذِي يُؤْتِي مَالَهُ يَتَزَكَّىٰ",fr:"celui qui donne ses biens pour se purifier,"},
{n:19,ar:"وَمَا لِأَحَدٍ عِندَهُ مِن نِّعْمَةٍ تُجْزَىٰ",fr:"sans attendre de faveur d'autrui à rendre,"},
{n:20,ar:"إِلَّا ابْتِغَاءَ وَجْهِ رَبِّهِ الْأَعْلَىٰ",fr:"cherchant seulement la Face de son Seigneur le Très Haut."},
{n:21,ar:"وَلَسَوْفَ يَرْضَىٰ",fr:"Et certes, il sera satisfait."},
];
QURAN_LOCAL[93]=[
{n:1,ar:"وَالضُّحَىٰ",fr:"Par la splendeur du matin,"},
{n:2,ar:"وَاللَّيْلِ إِذَا سَجَىٰ",fr:"et la nuit quand elle est calme !"},
{n:3,ar:"مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ",fr:"Ton Seigneur ne t'a pas abandonné et ne t'a pas pris en aversion."},
{n:4,ar:"وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ",fr:"L'au-delà sera certes meilleur pour toi que ce monde-ci."},
{n:5,ar:"وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ",fr:"Et ton Seigneur te donnera et tu seras satisfait."},
{n:6,ar:"أَلَمْ يَجِدْكَ يَتِيمًا فَآوَىٰ",fr:"Ne t'a-t-Il pas trouvé orphelin et recueilli ?"},
{n:7,ar:"وَوَجَدَكَ ضَالًّا فَهَدَىٰ",fr:"Ne t'a-t-Il pas trouvé égaré et guidé ?"},
{n:8,ar:"وَوَجَدَكَ عَائِلًا فَأَغْنَىٰ",fr:"Ne t'a-t-Il pas trouvé pauvre et enrichi ?"},
{n:9,ar:"فَأَمَّا الْيَتِيمَ فَلَا تَقْهَرْ",fr:"Donc, quant à l'orphelin, ne le brime pas,"},
{n:10,ar:"وَأَمَّا السَّائِلَ فَلَا تَنْهَرْ",fr:"et quant au mendiant, ne le repousse pas,"},
{n:11,ar:"وَأَمَّا بِنِعْمَةِ رَبِّكَ فَحَدِّثْ",fr:"et quant au bienfait de ton Seigneur, proclame-le."},
];
QURAN_LOCAL[94]=[
{n:1,ar:"أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ",fr:"N'avons-Nous pas dilaté ta poitrine,"},
{n:2,ar:"وَوَضَعْنَا عَنكَ وِزْرَكَ",fr:"et déposé de toi ton fardeau"},
{n:3,ar:"الَّذِي أَنقَضَ ظَهْرَكَ",fr:"qui alourdissait ton dos,"},
{n:4,ar:"وَرَفَعْنَا لَكَ ذِكْرَكَ",fr:"et élevé pour toi ta renommée ?"},
{n:5,ar:"فَإِنَّ مَعَ الْعُسْرِ يُسْرًا",fr:"Avec la difficulté vient certes la facilité."},
{n:6,ar:"إِنَّ مَعَ الْعُسْرِ يُسْرًا",fr:"Avec la difficulté vient certes la facilité."},
{n:7,ar:"فَإِذَا فَرَغْتَ فَانصَبْ",fr:"Quand tu te libères [d'une occupation], travaille dur,"},
{n:8,ar:"وَإِلَىٰ رَبِّكَ فَارْغَبْ",fr:"et vers ton Seigneur, dirige tes désirs."},
];
QURAN_LOCAL[95]=[
{n:1,ar:"وَالتِّينِ وَالزَّيْتُونِ",fr:"Par le figuier et l'olivier !"},
{n:2,ar:"وَطُورِ سِينِينَ",fr:"Par le mont Sinaï !"},
{n:3,ar:"وَهَٰذَا الْبَلَدِ الْأَمِينِ",fr:"Par cette cité sûre [La Mecque] !"},
{n:4,ar:"لَقَدْ خَلَقْنَا الْإِنسَانَ فِي أَحْسَنِ تَقْوِيمٍ",fr:"Nous avons certes créé l'homme dans la plus belle forme."},
{n:5,ar:"ثُمَّ رَدَدْنَاهُ أَسْفَلَ سَافِلِينَ",fr:"Puis Nous l'avons ramené au niveau le plus bas,"},
{n:6,ar:"إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ فَلَهُمْ أَجْرٌ غَيْرُ مَمْنُونٍ",fr:"sauf ceux qui ont cru et fait de bonnes œuvres — ceux-là auront une récompense ininterrompue."},
{n:8,ar:"أَلَيْسَ اللَّهُ بِأَحْكَمِ الْحَاكِمِينَ",fr:"Allah n'est-il pas le plus juste des juges ?"},
];
QURAN_LOCAL[96]=[
{n:1,ar:"اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ",fr:"Lis au nom de ton Seigneur qui a créé,"},
{n:2,ar:"خَلَقَ الْإِنسَانَ مِنْ عَلَقٍ",fr:"qui a créé l'homme d'une adhérence."},
{n:3,ar:"اقْرَأْ وَرَبُّكَ الْأَكْرَمُ",fr:"Lis ! Ton Seigneur est le Très Généreux,"},
{n:4,ar:"الَّذِي عَلَّمَ بِالْقَلَمِ",fr:"qui a enseigné par la plume,"},
{n:5,ar:"عَلَّمَ الْإِنسَانَ مَا لَمْ يَعْلَمْ",fr:"a enseigné à l'homme ce qu'il ne savait pas."},
{n:6,ar:"كَلَّا إِنَّ الْإِنسَانَ لَيَطْغَىٰ",fr:"Mais non ! L'homme transgresse,"},
{n:7,ar:"أَن رَّآهُ اسْتَغْنَىٰ",fr:"dès qu'il se croit suffisant."},
{n:19,ar:"كَلَّا لَا تُطِعْهُ وَاسْجُدْ وَاقْتَرِب ۩",fr:"Mais non ! Ne lui obéis pas et prosterne-toi et rapproche-toi [d'Allah]."},
];
QURAN_LOCAL[2]=[
{n:1,ar:"الم",fr:"Alif, Lâm, Mîm."},
{n:2,ar:"ذَٰلِكَ الْكِتَابُ لَا رَيْبَ فِيهِ هُدًى لِّلْمُتَّقِينَ",fr:"Ce Livre, il n'y a aucun doute en lui, est un guide pour les pieux,"},
{n:3,ar:"الَّذِينَ يُؤْمِنُونَ بِالْغَيْبِ وَيُقِيمُونَ الصَّلَاةَ وَمِمَّا رَزَقْنَاهُمْ يُنفِقُونَ",fr:"qui croient à l'invisible, accomplissent la Salât, et dépensent de ce que Nous leur avons attribué,"},
{n:4,ar:"وَالَّذِينَ يُؤْمِنُونَ بِمَا أُنزِلَ إِلَيْكَ وَمَا أُنزِلَ مِن قَبْلِكَ وَبِالْآخِرَةِ هُمْ يُوقِنُونَ",fr:"et qui croient à ce qu'on t'a révélé et à ce qu'on a révélé avant toi, et qui ont certitude en l'au-delà."},
{n:5,ar:"أُولَٰئِكَ عَلَىٰ هُدًى مِّن رَّبِّهِمْ وَأُولَٰئِكَ هُمُ الْمُفْلِحُونَ",fr:"Ceux-là sont sur le bon chemin de leur Seigneur, et ce sont eux les bienheureux."},
{n:21,ar:"يَا أَيُّهَا النَّاسُ اعْبُدُوا رَبَّكُمُ الَّذِي خَلَقَكُمْ وَالَّذِينَ مِن قَبْلِكُمْ لَعَلَّكُمْ تَتَّقُونَ",fr:"Ô hommes ! Adorez votre Seigneur qui vous a créés, vous et ceux qui vous ont précédés, afin que vous soyez pieux."},
{n:30,ar:"وَإِذْ قَالَ رَبُّكَ لِلْمَلَائِكَةِ إِنِّي جَاعِلٌ فِي الْأَرْضِ خَلِيفَةً",fr:"Et quand ton Seigneur dit aux Anges : «Je vais établir un vicaire sur la terre»,"},
{n:115,ar:"وَلِلَّهِ الْمَشْرِقُ وَالْمَغْرِبُ فَأَيْنَمَا تُوَلُّوا فَثَمَّ وَجْهُ اللَّهِ إِنَّ اللَّهَ وَاسِعٌ عَلِيمٌ",fr:"À Allah appartient l'Orient et l'Occident. Où que vous vous tourniez, là est la Face d'Allah. Allah est Immense et Omniscient."},
{n:152,ar:"فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ",fr:"Rappelez-vous Moi donc, Je me souviendrai de vous. Remerciez-Moi et ne soyez pas ingrats envers Moi."},
{n:153,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",fr:"Ô les croyants ! Cherchez secours dans l'endurance et la Salât. Allah est avec les endurants."},
{n:155,ar:"وَلَنَبْلُوَنَّكُم بِشَيْءٍ مِّنَ الْخَوْفِ وَالْجُوعِ وَنَقْصٍ مِّنَ الْأَمْوَالِ وَالْأَنفُسِ وَالثَّمَرَاتِ وَبَشِّرِ الصَّابِرِينَ",fr:"Nous vous éprouverons par quelque peur, famine, perte de biens, de vies ou de récoltes. Et fais la bonne annonce aux endurants,"},
{n:156,ar:"الَّذِينَ إِذَا أَصَابَتْهُم مُّصِيبَةٌ قَالُوا إِنَّا لِلَّهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ",fr:"qui disent, quand un malheur les atteint : «Certes nous sommes à Allah, et certes, c'est à Lui que nous retournons.»"},
{n:183,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا كُتِبَ عَلَيْكُمُ الصِّيَامُ كَمَا كُتِبَ عَلَى الَّذِينَ مِن قَبْلِكُمْ لَعَلَّكُمْ تَتَّقُونَ",fr:"Ô les croyants ! Le jeûne vous a été prescrit comme il a été prescrit à ceux d'avant vous, ainsi vous deviendrez pieux."},
{n:255,ar:"اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ",fr:"Allah ! Point de divinité à part Lui, le Vivant, Celui qui subsiste par lui-même. Ni somnolence ni sommeil ne Le saisissent. À Lui appartient tout ce qui est dans les cieux et sur la terre. Qui peut intercéder auprès de Lui sans Sa permission ? Il sait ce qui est devant eux et ce qui est derrière eux. Et ils n'embrassent de Sa science que ce qu'Il veut. Son Trône déborde les cieux et la terre, dont la garde ne Lui coûte aucune peine. Et Il est le Très Haut, le Très Grand."},
{n:256,ar:"لَا إِكْرَاهَ فِي الدِّينِ قَد تَّبَيَّنَ الرُّشْدُ مِنَ الْغَيِّ فَمَن يَكْفُرْ بِالطَّاغُوتِ وَيُؤْمِن بِاللَّهِ فَقَدِ اسْتَمْسَكَ بِالْعُرْوَةِ الْوُثْقَىٰ لَا انفِصَامَ لَهَا وَاللَّهُ سَمِيعٌ عَلِيمٌ",fr:"Nulle contrainte en religion ! Car le bon chemin s'est distingué de l'égarement. Donc, quiconque mécroit au Tâghût et croit en Allah saisit l'anse la plus solide, sans brisure possible. Allah est Audient et Omniscient."},
{n:284,ar:"لِّلَّهِ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ وَإِن تُبْدُوا مَا فِي أَنفُسِكُمْ أَوْ تُخْفُوهُ يُحَاسِبْكُم بِهِ اللَّهُ",fr:"À Allah appartient tout ce qui est dans les cieux et sur la terre. Que vous manifestiez ce qui est en vous ou que vous le cachiez, Allah vous en demandera compte."},
{n:285,ar:"آمَنَ الرَّسُولُ بِمَا أُنزِلَ إِلَيْهِ مِن رَّبِّهِ وَالْمُؤْمِنُونَ كُلٌّ آمَنَ بِاللَّهِ وَمَلَائِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ",fr:"Le Messager a cru en ce qu'on a fait descendre vers lui venant de son Seigneur, et aussi les croyants : chacun a cru en Allah, en Ses anges, en Ses livres et en Ses messagers."},
{n:286,ar:"لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا لَهَا مَا كَسَبَتْ وَعَلَيْهَا مَا اكْتَسَبَتْ رَبَّنَا لَا تُؤَاخِذْنَا إِن نَّسِينَا أَوْ أَخْطَأْنَا رَبَّنَا وَلَا تَحْمِلْ عَلَيْنَا إِصْرًا كَمَا حَمَلْتَهُ عَلَى الَّذِينَ مِن قَبْلِنَا رَبَّنَا وَلَا تُحَمِّلْنَا مَا لَا طَاقَةَ لَنَا بِهِ وَاعْفُ عَنَّا وَاغْفِرْ لَنَا وَارْحَمْنَا أَنتَ مَوْلَانَا فَانصُرْنَا عَلَى الْقَوْمِ الْكَافِرِينَ",fr:"Allah n'impose à personne une charge supérieure à sa capacité. Chacun aura ce qu'il a acquis, et à chacun sera imputé ce qu'il a commis. Notre Seigneur ! Ne nous châtie pas si nous oublions ou si nous commettons des erreurs. Notre Seigneur ! Ne nous charge pas un fardeau comme Tu en as chargé ceux d'avant nous. Notre Seigneur ! Ne nous impose pas ce que nous ne pouvons pas supporter. Efface nos fautes, pardonne-nous et fais-nous miséricorde. Tu es notre Maître. Fais-nous triompher sur les gens mécréants."},
];
QURAN_LOCAL[3]=[
{n:1,ar:"الم",fr:"Alif, Lâm, Mîm."},
{n:2,ar:"اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ",fr:"Allah ! Point de divinité à part Lui, le Vivant, Celui qui subsiste par Lui-même."},
{n:3,ar:"نَزَّلَ عَلَيْكَ الْكِتَابَ بِالْحَقِّ مُصَدِّقًا لِّمَا بَيْنَ يَدَيْهِ",fr:"Il a fait descendre sur toi le Livre avec la Vérité, confirmant ce qui le précédait."},
{n:18,ar:"شَهِدَ اللَّهُ أَنَّهُ لَا إِلَٰهَ إِلَّا هُوَ وَالْمَلَائِكَةُ وَأُولُو الْعِلْمِ قَائِمًا بِالْقِسْطِ لَا إِلَٰهَ إِلَّا هُوَ الْعَزِيزُ الْحَكِيمُ",fr:"Allah atteste qu'il n'y a point de divinité à part Lui, de même que les Anges et les gens doués de science. Il maintient la justice. Point de divinité à part Lui, le Puissant, le Sage."},
{n:26,ar:"قُلِ اللَّهُمَّ مَالِكَ الْمُلْكِ تُؤْتِي الْمُلْكَ مَن تَشَاءُ وَتَنزِعُ الْمُلْكَ مِمَّن تَشَاءُ",fr:"Dis : «Ô Allah, Maître de la royauté, Tu donnes la royauté à qui Tu veux et Tu arraches la royauté à qui Tu veux.»"},
{n:31,ar:"قُلْ إِن كُنتُمْ تُحِبُّونَ اللَّهَ فَاتَّبِعُونِي يُحْبِبْكُمُ اللَّهُ وَيَغْفِرْ لَكُمْ ذُنُوبَكُمْ",fr:"Dis : «Si vous aimez Allah, suivez-moi ; Allah vous aimera alors et vous pardonnera vos péchés.»"},
{n:85,ar:"وَمَن يَبْتَغِ غَيْرَ الْإِسْلَامِ دِينًا فَلَن يُقْبَلَ مِنْهُ وَهُوَ فِي الْآخِرَةِ مِنَ الْخَاسِرِينَ",fr:"Quiconque cherche une religion autre que l'Islam ne sera jamais agréé, et il sera, dans l'au-delà, parmi les perdants."},
{n:173,ar:"الَّذِينَ قَالَ لَهُمُ النَّاسُ إِنَّ النَّاسَ قَدْ جَمَعُوا لَكُمْ فَاخْشَوْهُمْ فَزَادَهُمْ إِيمَانًا وَقَالُوا حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",fr:"Ceux à qui les gens ont dit : «Les gens ont rassemblé contre vous des forces ; craignez-les.» Mais cela accrut leur foi et ils dirent : «Allah nous suffit, Il est notre meilleur garant.»"},
{n:185,ar:"كُلُّ نَفْسٍ ذَائِقَةُ الْمَوْتِ وَإِنَّمَا تُوَفَّوْنَ أُجُورَكُمْ يَوْمَ الْقِيَامَةِ",fr:"Toute âme goûtera la mort. Et vous ne recevrez vos rétributions qu'au Jour de la Résurrection."},
{n:190,ar:"إِنَّ فِي خَلْقِ السَّمَاوَاتِ وَالْأَرْضِ وَاخْتِلَافِ اللَّيْلِ وَالنَّهَارِ لَآيَاتٍ لِّأُولِي الْأَلْبَابِ",fr:"Il y a certes dans la création des cieux et de la terre, et dans l'alternance de la nuit et du jour, des signes pour les doués d'intelligence,"},
{n:191,ar:"الَّذِينَ يَذْكُرُونَ اللَّهَ قِيَامًا وَقُعُودًا وَعَلَىٰ جُنُوبِهِمْ وَيَتَفَكَّرُونَ فِي خَلْقِ السَّمَاوَاتِ وَالْأَرْضِ",fr:"qui se souviennent d'Allah debout, assis et couchés sur leurs côtés, et méditent sur la création des cieux et de la terre."},
{n:200,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا اصْبِرُوا وَصَابِرُوا وَرَابِطُوا وَاتَّقُوا اللَّهَ لَعَلَّكُمْ تُفْلِحُونَ",fr:"Ô les croyants ! Soyez endurants. Encouragez-vous mutuellement à l'endurance. Soyez sur vos gardes. Et craignez Allah, afin que vous réussissiez."},
];
QURAN_LOCAL[4]=[
{n:1,ar:"يَا أَيُّهَا النَّاسُ اتَّقُوا رَبَّكُمُ الَّذِي خَلَقَكُم مِّن نَّفْسٍ وَاحِدَةٍ",fr:"Ô hommes ! Craignez votre Seigneur qui vous a créés d'un seul être."},
{n:36,ar:"وَاعْبُدُوا اللَّهَ وَلَا تُشْرِكُوا بِهِ شَيْئًا وَبِالْوَالِدَيْنِ إِحْسَانًا",fr:"Adorez Allah et ne Lui associez rien. Agissez bien envers les père et mère."},
{n:48,ar:"إِنَّ اللَّهَ لَا يَغْفِرُ أَن يُشْرَكَ بِهِ وَيَغْفِرُ مَا دُونَ ذَٰلِكَ لِمَن يَشَاءُ",fr:"Allah ne pardonne pas qu'on Lui associe quelque chose ; mais Il pardonne à qui Il veut ce qui est en dessous."},
{n:58,ar:"إِنَّ اللَّهَ يَأْمُرُكُمْ أَن تُؤَدُّوا الْأَمَانَاتِ إِلَىٰ أَهْلِهَا",fr:"Allah vous commande de remettre les dépôts à leurs ayants droit."},
{n:59,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا أَطِيعُوا اللَّهَ وَأَطِيعُوا الرَّسُولَ وَأُولِي الْأَمْرِ مِنكُمْ",fr:"Ô les croyants ! Obéissez à Allah, et obéissez au Messager et à ceux d'entre vous qui détiennent le commandement."},
{n:103,ar:"فَإِذَا قَضَيْتُمُ الصَّلَاةَ فَاذْكُرُوا اللَّهَ قِيَامًا وَقُعُودًا وَعَلَىٰ جُنُوبِكُمْ",fr:"Quand vous avez accompli la Salât, invoquez Allah debout, assis ou couché sur vos côtés."},
{n:110,ar:"وَمَن يَعْمَلْ سُوءًا أَوْ يَظْلِمْ نَفْسَهُ ثُمَّ يَسْتَغْفِرِ اللَّهَ يَجِدِ اللَّهَ غَفُورًا رَّحِيمًا",fr:"Quiconque fait un mal ou lèse sa propre âme, puis implore le pardon d'Allah, trouvera Allah Pardonneur et Miséricordieux."},
{n:135,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا كُونُوا قَوَّامِينَ بِالْقِسْطِ شُهَدَاءَ لِلَّهِ",fr:"Ô les croyants ! Soyez stricts dans l'équité et témoignez pour Allah."},
];
QURAN_LOCAL[5]=[
{n:3,ar:"الْيَوْمَ أَكْمَلْتُ لَكُمْ دِينَكُمْ وَأَتْمَمْتُ عَلَيْكُمْ نِعْمَتِي وَرَضِيتُ لَكُمُ الْإِسْلَامَ دِينًا",fr:"Aujourd'hui, J'ai parachevé pour vous votre religion, et accompli sur vous Mon bienfait. Et J'agrée l'Islam comme religion pour vous."},
{n:32,ar:"مَن قَتَلَ نَفْسًا بِغَيْرِ نَفْسٍ أَوْ فَسَادٍ فِي الْأَرْضِ فَكَأَنَّمَا قَتَلَ النَّاسَ جَمِيعًا وَمَنْ أَحْيَاهَا فَكَأَنَّمَا أَحْيَا النَّاسَ جَمِيعًا",fr:"Quiconque tuerait une personne non coupable d'un meurtre ou d'une corruption sur la terre, c'est comme s'il avait tué tous les hommes. Et quiconque lui fait don de la vie, c'est comme s'il faisait don de la vie à tous les hommes."},
{n:35,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَابْتَغُوا إِلَيْهِ الْوَسِيلَةَ وَجَاهِدُوا فِي سَبِيلِهِ لَعَلَّكُمْ تُفْلِحُونَ",fr:"Ô les croyants ! Craignez Allah, cherchez le moyen de vous rapprocher de Lui, et luttez dans Son chemin, afin que vous réussissiez."},
{n:54,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا مَن يَرْتَدَّ مِنكُمْ عَن دِينِهِ فَسَوْفَ يَأْتِي اللَّهُ بِقَوْمٍ يُحِبُّهُمْ وَيُحِبُّونَهُ",fr:"Ô les croyants ! Quiconque parmi vous abandonne sa religion... Allah amènera un peuple qu'Il aimera et qui L'aimera."},
{n:119,ar:"قَالَ اللَّهُ هَٰذَا يَوْمُ يَنفَعُ الصَّادِقِينَ صِدْقُهُمْ لَهُمْ جَنَّاتٌ تَجْرِي مِن تَحْتِهَا الْأَنْهَارُ",fr:"Allah dit : «Voici le Jour où leur véracité sera utile aux véridiques. Ils auront des jardins sous lesquels coulent les ruisseaux.»"},
];
QURAN_LOCAL[6]=[
{n:1,ar:"الْحَمْدُ لِلَّهِ الَّذِي خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ وَجَعَلَ الظُّلُمَاتِ وَالنُّورَ",fr:"Louange à Allah qui a créé les cieux et la terre et a établi les ténèbres et la lumière."},
{n:59,ar:"وَعِندَهُ مَفَاتِحُ الْغَيْبِ لَا يَعْلَمُهَا إِلَّا هُوَ",fr:"Auprès de Lui sont les clés du monde invisible. Personne d'autre que Lui ne les connaît."},
{n:82,ar:"الَّذِينَ آمَنُوا وَلَمْ يَلْبِسُوا إِيمَانَهُم بِظُلْمٍ أُولَٰئِكَ لَهُمُ الْأَمْنُ وَهُم مُّهْتَدُونَ",fr:"Ceux qui ont cru et n'ont pas mélangé leur foi avec l'injustice : ceux-là ont la sécurité et ils sont bien guidés."},
{n:103,ar:"لَّا تُدْرِكُهُ الْأَبْصَارُ وَهُوَ يُدْرِكُ الْأَبْصَارَ وَهُوَ اللَّطِيفُ الْخَبِيرُ",fr:"Les regards ne peuvent L'atteindre, mais Lui Il saisit tous les regards. Il est le Subtil, le Parfaitement Connaisseur."},
{n:162,ar:"قُلْ إِنَّ صَلَاتِي وَنُسُكِي وَمَحْيَايَ وَمَمَاتِي لِلَّهِ رَبِّ الْعَالَمِينَ",fr:"Dis : «Ma Salât, mes actes de dévotion, ma vie et ma mort appartiennent à Allah, Seigneur de l'univers.»"},
];
QURAN_LOCAL[7]=[
{n:23,ar:"قَالَا رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ",fr:"Adam et Eve dirent : «Notre Seigneur, nous nous sommes lésés nous-mêmes. Si Tu ne nous pardonnes pas et ne nous fais pas miséricorde, nous serons assurément parmi les perdants.»"},
{n:55,ar:"ادْعُوا رَبَّكُمْ تَضَرُّعًا وَخُفْيَةً إِنَّهُ لَا يُحِبُّ الْمُعْتَدِينَ",fr:"Appelez votre Seigneur avec humilité et en secret. Certes, Il n'aime pas les transgresseurs."},
{n:156,ar:"وَاكْتُبْ لَنَا فِي هَٰذِهِ الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ إِنَّا هُدْنَا إِلَيْكَ",fr:"Prescris-nous le bien, dans cette vie et dans l'au-delà. Nous voilà revenus à Toi."},
{n:180,ar:"وَلِلَّهِ الْأَسْمَاءُ الْحُسْنَىٰ فَادْعُوهُ بِهَا",fr:"Allah possède les plus beaux noms. Invoquez-Le par ces noms."},
{n:206,ar:"إِنَّ الَّذِينَ عِندَ رَبِّكَ لَا يَسْتَكْبِرُونَ عَنْ عِبَادَتِهِ وَيُسَبِّحُونَهُ وَلَهُ يَسْجُدُونَ ۩",fr:"Ceux qui sont auprès de ton Seigneur ne s'enflent pas d'orgueil pour ne pas L'adorer. Ils Le glorifient et se prosternent devant Lui."},
];
QURAN_LOCAL[8]=[
{n:2,ar:"إِنَّمَا الْمُؤْمِنُونَ الَّذِينَ إِذَا ذُكِرَ اللَّهُ وَجِلَتْ قُلُوبُهُمْ",fr:"Les vrais croyants sont seulement ceux dont les cœurs frémissent quand on mentionne Allah."},
{n:45,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا لَقِيتُمْ فِئَةً فَاثْبُتُوا وَاذْكُرُوا اللَّهَ كَثِيرًا",fr:"Ô les croyants ! Quand vous rencontrez une troupe, soyez fermes et invoquez beaucoup Allah."},
{n:53,ar:"ذَٰلِكَ بِأَنَّ اللَّهَ لَمْ يَكُ مُغَيِّرًا نِّعْمَةً أَنْعَمَهَا عَلَىٰ قَوْمٍ حَتَّىٰ يُغَيِّرُوا مَا بِأَنفُسِهِمْ",fr:"C'est parce qu'Allah ne modifie pas le bienfait dont Il a gratifié un peuple, à moins que ce peuple change ce qui est en lui-même."},
];
QURAN_LOCAL[9]=[
{n:18,ar:"إِنَّمَا يَعْمُرُ مَسَاجِدَ اللَّهِ مَنْ آمَنَ بِاللَّهِ وَالْيَوْمِ الْآخِرِ",fr:"Seuls entretiennent les mosquées d'Allah ceux qui croient en Allah et au Jour dernier."},
{n:51,ar:"قُل لَّن يُصِيبَنَا إِلَّا مَا كَتَبَ اللَّهُ لَنَا هُوَ مَوْلَانَا وَعَلَى اللَّهِ فَلْيَتَوَكَّلِ الْمُؤْمِنُونَ",fr:"Dis : «Il ne nous atteindra que ce qu'Allah a prescrit pour nous. Il est notre Maître. C'est en Allah que les croyants doivent mettre leur confiance.»"},
{n:71,ar:"وَالْمُؤْمِنُونَ وَالْمُؤْمِنَاتُ بَعْضُهُمْ أَوْلِيَاءُ بَعْضٍ",fr:"Les croyants et les croyantes sont alliés les uns des autres."},
{n:128,ar:"لَقَدْ جَاءَكُمْ رَسُولٌ مِّنْ أَنفُسِكُمْ عَزِيزٌ عَلَيْهِ مَا عَنِتُّمْ حَرِيصٌ عَلَيْكُم بِالْمُؤْمِنِينَ رَءُوفٌ رَّحِيمٌ",fr:"Il vous est venu un Messager pris parmi vous. Votre souffrance lui pèse. Il tient à vous. Il est plein de douceur et de miséricorde envers les croyants."},
{n:129,ar:"فَإِن تَوَلَّوْا فَقُلْ حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ",fr:"S'ils se détournent, dis : «Allah me suffit. Il n'y a de divinité que Lui. Je m'en remets à Lui. Il est le Seigneur du Trône immense.»"},
];
QURAN_LOCAL[10]=[
{n:9,ar:"إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ يَهْدِيهِمْ رَبُّهُم بِإِيمَانِهِمْ",fr:"Ceux qui croient et font de bonnes œuvres, leur Seigneur les guide grâce à leur foi."},
{n:57,ar:"يَا أَيُّهَا النَّاسُ قَدْ جَاءَتْكُم مَّوْعِظَةٌ مِّن رَّبِّكُمْ وَشِفَاءٌ لِّمَا فِي الصُّدُورِ",fr:"Ô hommes ! Une exhortation vous est venue de la part de votre Seigneur, une guérison de ce qui est dans les poitrines."},
{n:62,ar:"أَلَا إِنَّ أَوْلِيَاءَ اللَّهِ لَا خَوْفٌ عَلَيْهِمْ وَلَا هُمْ يَحْزَنُونَ",fr:"Les alliés d'Allah n'éprouveront aucune crainte et ils n'auront jamais de chagrin."},
];
QURAN_LOCAL[11]=[
{n:6,ar:"وَمَا مِن دَابَّةٍ فِي الْأَرْضِ إِلَّا عَلَى اللَّهِ رِزْقُهَا",fr:"Il n'existe pas de bête sur terre dont la subsistance n'incombe à Allah."},
{n:88,ar:"وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ عَلَيْهِ تَوَكَّلْتُ وَإِلَيْهِ أُنِيبُ",fr:"Ma réussite ne vient que d'Allah. C'est en Lui que je m'en remets et c'est à Lui que je reviens."},
{n:114,ar:"وَأَقِمِ الصَّلَاةَ طَرَفَيِ النَّهَارِ وَزُلَفًا مِّنَ اللَّيْلِ إِنَّ الْحَسَنَاتِ يُذْهِبْنَ السَّيِّئَاتِ",fr:"Accomplis la Salât aux deux extrémités du jour et à certaines heures de la nuit. Les bonnes œuvres effacent les mauvaises."},
];
QURAN_LOCAL[12]=[
{n:3,ar:"نَحْنُ نَقُصُّ عَلَيْكَ أَحْسَنَ الْقَصَصِ",fr:"Nous te racontons le plus beau des récits."},
{n:18,ar:"فَصَبْرٌ جَمِيلٌ وَاللَّهُ الْمُسْتَعَانُ عَلَىٰ مَا تَصِفُونَ",fr:"Une belle patience ! C'est Allah qu'on doit implorer contre ce que vous décrivez."},
{n:64,ar:"قَالَ هَلْ آمَنُكُمْ عَلَيْهِ إِلَّا كَمَا أَمِنتُكُمْ عَلَىٰ أَخِيهِ مِن قَبْلُ فَاللَّهُ خَيْرٌ حَافِظًا",fr:"Il dit : «Vous confierais-je lui comme je vous ai confié son frère auparavant ? Allah est le meilleur gardien.»"},
{n:87,ar:"يَا بَنِيَّ اذْهَبُوا فَتَحَسَّسُوا مِن يُوسُفَ وَأَخِيهِ وَلَا تَيْأَسُوا مِن رَّوْحِ اللَّهِ",fr:"«Ô mes fils ! Allez et renseignez-vous sur Yûsuf et son frère. Ne désespérez pas de la miséricorde d'Allah.»"},
{n:101,ar:"رَبِّ قَدْ آتَيْتَنِي مِنَ الْمُلْكِ وَعَلَّمْتَنِي مِن تَأْوِيلِ الْأَحَادِيثِ فَاطِرَ السَّمَاوَاتِ وَالْأَرْضِ",fr:"Seigneur, Tu m'as donné une partie du pouvoir et m'as enseigné l'interprétation des songes. Créateur des cieux et de la terre !"},
];
QURAN_LOCAL[13]=[
{n:11,ar:"إِنَّ اللَّهَ لَا يُغَيِّرُ مَا بِقَوْمٍ حَتَّىٰ يُغَيِّرُوا مَا بِأَنفُسِهِمْ",fr:"Allah ne modifie pas l'état d'un peuple tant que les membres de ce peuple ne modifient pas ce qui est en eux-mêmes."},
{n:28,ar:"أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ",fr:"C'est par le rappel d'Allah que les cœurs se tranquillisent."},
{n:29,ar:"الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ طُوبَىٰ لَهُمْ وَحُسْنُ مَآبٍ",fr:"Ceux qui croient et font de bonnes œuvres : félicité pour eux et belle demeure au retour."},
];
QURAN_LOCAL[14]=[
{n:7,ar:"وَإِذْ تَأَذَّنَ رَبُّكُمْ لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ وَلَئِن كَفَرْتُمْ إِنَّ عَذَابِي لَشَدِيدٌ",fr:"Et quand votre Seigneur proclama : «Si vous êtes reconnaissants, J'augmenterai certes Mon bienfait pour vous. Mais si vous êtes ingrats... Mon châtiment est terrible.»"},
{n:24,ar:"أَلَمْ تَرَ كَيْفَ ضَرَبَ اللَّهُ مَثَلًا كَلِمَةً طَيِّبَةً كَشَجَرَةٍ طَيِّبَةٍ",fr:"N'as-tu pas vu comment Allah propose en exemple une bonne parole : elle est comme un bon arbre."},
{n:40,ar:"رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِن ذُرِّيَّتِي رَبَّنَا وَتَقَبَّلْ دُعَاءِ",fr:"Seigneur, fais que j'accomplisse la Salât, ainsi que ma descendance. Seigneur, exauce ma prière."},
];
QURAN_LOCAL[15]=[
{n:9,ar:"إِنَّا نَحْنُ نَزَّلْنَا الذِّكْرَ وَإِنَّا لَهُ لَحَافِظُونَ",fr:"C'est Nous qui avons fait descendre le Rappel, et c'est Nous qui en sommes gardiens."},
{n:49,ar:"نَبِّئْ عِبَادِي أَنِّي أَنَا الْغَفُورُ الرَّحِيمُ",fr:"Informe Mes serviteurs que c'est Moi le Pardonneur, le Miséricordieux,"},
{n:50,ar:"وَأَنَّ عَذَابِي هُوَ الْعَذَابُ الْأَلِيمُ",fr:"et que Mon châtiment est le châtiment douloureux."},
];
QURAN_LOCAL[16]=[
{n:90,ar:"إِنَّ اللَّهَ يَأْمُرُ بِالْعَدْلِ وَالْإِحْسَانِ وَإِيتَاءِ ذِي الْقُرْبَىٰ وَيَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ وَالْبَغْيِ",fr:"Allah commande l'équité, la bienfaisance et l'assistance aux proches. Et Il interdit la turpitude, l'acte répréhensible et la rébellion."},
{n:97,ar:"مَنْ عَمِلَ صَالِحًا مِّن ذَكَرٍ أَوْ أُنثَىٰ وَهُوَ مُؤْمِنٌ فَلَنُحْيِيَنَّهُ حَيَاةً طَيِّبَةً",fr:"Quiconque, homme ou femme, fait une bonne œuvre tout en étant croyant, Nous lui ferons vivre une bonne vie."},
{n:128,ar:"إِنَّ اللَّهَ مَعَ الَّذِينَ اتَّقَوا وَّالَّذِينَ هُم مُّحْسِنُونَ",fr:"Allah est avec ceux qui L'ont craint et ceux qui font le bien."},
];
QURAN_LOCAL[17]=[
{n:1,ar:"سُبْحَانَ الَّذِي أَسْرَىٰ بِعَبْدِهِ لَيْلًا مِّنَ الْمَسْجِدِ الْحَرَامِ إِلَى الْمَسْجِدِ الْأَقْصَى",fr:"Gloire à Celui qui a fait voyager de nuit Son serviteur, de la Mosquée sacrée à la Mosquée Al-Aqsâ."},
{n:23,ar:"وَقَضَىٰ رَبُّكَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا",fr:"Ton Seigneur a décrété que vous n'adoriez que Lui, et que vous soyez bons avec les parents."},
{n:44,ar:"وَإِن مِّن شَيْءٍ إِلَّا يُسَبِّحُ بِحَمْدِهِ وَلَٰكِن لَّا تَفْقَهُونَ تَسْبِيحَهُمْ",fr:"Il n'est rien qui ne Le glorifie en Le louant, mais vous ne comprenez pas leur glorification."},
{n:79,ar:"وَمِنَ اللَّيْلِ فَتَهَجَّدْ بِهِ نَافِلَةً لَّكَ عَسَىٰ أَن يَبْعَثَكَ رَبُّكَ مَقَامًا مَّحْمُودًا",fr:"Et pendant une partie de la nuit, veille à la Salât, en plus de ce qui t'est prescrit. Ton Seigneur t'élèvera peut-être à une station louable."},
{n:110,ar:"قُلِ ادْعُوا اللَّهَ أَوِ ادْعُوا الرَّحْمَٰنَ أَيًّا مَّا تَدْعُوا فَلَهُ الْأَسْمَاءُ الْحُسْنَىٰ",fr:"Dis : «Invoquez Allah ou invoquez Ar-Rahmân : quel que soit le nom par lequel vous L'invoquez, les plus beaux noms Lui appartiennent.»"},
];
QURAN_LOCAL[18]=[
{n:1,ar:"الْحَمْدُ لِلَّهِ الَّذِي أَنزَلَ عَلَىٰ عَبْدِهِ الْكِتَابَ وَلَمْ يَجْعَل لَّهُ عِوَجًا",fr:"Louange à Allah qui a fait descendre le Livre sur Son serviteur, sans y mettre de déviation."},
{n:10,ar:"إِذْ أَوَى الْفِتْيَةُ إِلَى الْكَهْفِ فَقَالُوا رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا",fr:"Quand les jeunes gens se réfugièrent dans la caverne, ils dirent : «Notre Seigneur, accorde-nous miséricorde et dirige nos affaires.»"},
{n:28,ar:"وَاصْبِرْ نَفْسَكَ مَعَ الَّذِينَ يَدْعُونَ رَبَّهُم بِالْغَدَاةِ وَالْعَشِيِّ يُرِيدُونَ وَجْهَهُ",fr:"Tiens-toi en compagnie de ceux qui font des invocations à leur Seigneur matin et soir, cherchant Sa Face."},
{n:46,ar:"الْمَالُ وَالْبَنُونَ زِينَةُ الْحَيَاةِ الدُّنْيَا وَالْبَاقِيَاتُ الصَّالِحَاتُ خَيْرٌ عِندَ رَبِّكَ",fr:"Les richesses et les enfants sont l'ornement de la vie d'ici-bas. Mais les bonnes œuvres durables ont auprès de ton Seigneur une meilleure récompense."},
{n:107,ar:"إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ كَانَتْ لَهُمْ جَنَّاتُ الْفِرْدَوْسِ نُزُلًا",fr:"Ceux qui croient et font de bonnes œuvres auront les Jardins du Firdaws en séjour."},
{n:110,ar:"قُلْ إِنَّمَا أَنَا بَشَرٌ مِّثْلُكُمْ يُوحَىٰ إِلَيَّ أَنَّمَا إِلَٰهُكُمْ إِلَٰهٌ وَاحِدٌ",fr:"Dis : «Je suis un homme comme vous. Il m'est révélé que votre divinité est une divinité unique.»"},
];
QURAN_LOCAL[19]=[
{n:30,ar:"قَالَ إِنِّي عَبْدُ اللَّهِ آتَانِيَ الْكِتَابَ وَجَعَلَنِي نَبِيًّا",fr:"['Isâ] dit : «Je suis le serviteur d'Allah. Il m'a apporté le Livre et a fait de moi un prophète.»"},
{n:35,ar:"مَا كَانَ لِلَّهِ أَن يَتَّخِذَ مِن وَلَدٍ سُبْحَانَهُ إِذَا قَضَىٰ أَمْرًا فَإِنَّمَا يَقُولُ لَهُ كُن فَيَكُونُ",fr:"Il ne convient pas à Allah de prendre un fils. Gloire à Lui ! Quand Il décide d'une chose, Il lui dit seulement : «Sois» et elle est."},
{n:76,ar:"وَيَزِيدُ اللَّهُ الَّذِينَ اهْتَدَوْا هُدًى وَالْبَاقِيَاتُ الصَّالِحَاتُ خَيْرٌ عِندَ رَبِّكَ",fr:"Allah augmente en guidance ceux qui suivent le bon chemin. Les bonnes œuvres durables ont une meilleure récompense auprès de ton Seigneur."},
];
QURAN_LOCAL[20]=[
{n:14,ar:"إِنَّنِي أَنَا اللَّهُ لَا إِلَٰهَ إِلَّا أَنَا فَاعْبُدْنِي وَأَقِمِ الصَّلَاةَ لِذِكْرِي",fr:"«Je suis Allah ! Point de divinité que Moi. Adore-Moi donc et accomplis la Salât pour te souvenir de Moi.»"},
{n:25,ar:"رَبِّ اشْرَحْ لِي صَدْرِي",fr:"«Seigneur, dilate ma poitrine,"},
{n:26,ar:"وَيَسِّرْ لِي أَمْرِي",fr:"et facilite-moi ma tâche,"},
{n:27,ar:"وَاحْلُلْ عُقْدَةً مِّن لِّسَانِي",fr:"et dénoue un nœud de ma langue,"},
{n:28,ar:"يَفْقَهُوا قَوْلِي",fr:"afin qu'ils comprennent mes paroles.»"},
{n:114,ar:"فَتَعَالَى اللَّهُ الْمَلِكُ الْحَقُّ وَلَا تَعْجَلْ بِالْقُرْآنِ مِن قَبْلِ أَن يُقْضَىٰ إِلَيْكَ وَحْيُهُ وَقُل رَّبِّ زِدْنِي عِلْمًا",fr:"Qu'Allah le Roi, la Vérité, soit exalté ! Dis : «Seigneur, accroîs mon savoir.»"},
];
QURAN_LOCAL[21]=[
{n:87,ar:"وَذَا النُّونِ إِذ ذَّهَبَ مُغَاضِبًا فَظَنَّ أَن لَّن نَّقْدِرَ عَلَيْهِ فَنَادَىٰ فِي الظُّلُمَاتِ أَن لَّا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ",fr:"Et Dhul-Nûn, quand il s'en alla fâché et pensa que Nous n'avions pas de prise sur lui, puis implora dans les ténèbres : «Point de divinité sauf Toi ! Gloire à Toi ! J'ai été du nombre des injustes.»"},
{n:88,ar:"فَاسْتَجَبْنَا لَهُ وَنَجَّيْنَاهُ مِنَ الْغَمِّ وَكَذَٰلِكَ نُنجِي الْمُؤْمِنِينَ",fr:"Nous lui avons répondu et l'avons sauvé de la détresse. C'est ainsi que Nous sauvons les croyants."},
{n:107,ar:"وَمَا أَرْسَلْنَاكَ إِلَّا رَحْمَةً لِّلْعَالَمِينَ",fr:"Et Nous ne t'avons envoyé qu'en miséricorde pour les mondes."},
];
QURAN_LOCAL[22]=[
{n:1,ar:"يَا أَيُّهَا النَّاسُ اتَّقُوا رَبَّكُمْ إِنَّ زَلْزَلَةَ السَّاعَةِ شَيْءٌ عَظِيمٌ",fr:"Ô hommes ! Craignez votre Seigneur car le tremblement de l'Heure est une chose terrible."},
{n:27,ar:"وَأَذِّن فِي النَّاسِ بِالْحَجِّ يَأْتُوكَ رِجَالًا وَعَلَىٰ كُلِّ ضَامِرٍ يَأْتِينَ مِن كُلِّ فَجٍّ عَمِيقٍ",fr:"Et proclame parmi les gens le pèlerinage. Ils viendront à toi à pied et sur toutes sortes de montures, de toute vallée profonde."},
{n:37,ar:"لَن يَنَالَ اللَّهَ لُحُومُهَا وَلَا دِمَاؤُهَا وَلَٰكِن يَنَالُهُ التَّقْوَىٰ مِنكُمْ",fr:"Ni leurs chairs ni leurs sangs n'atteignent Allah. C'est votre piété qui L'atteint."},
{n:78,ar:"وَجَاهِدُوا فِي اللَّهِ حَقَّ جِهَادِهِ هُوَ اجْتَبَاكُمْ",fr:"Et luttez pour Allah comme Il se doit de lutter pour Lui. C'est Lui qui vous a élus."},
];
QURAN_LOCAL[23]=[
{n:1,ar:"قَدْ أَفْلَحَ الْمُؤْمِنُونَ",fr:"Les croyants ont certes réussi :"},
{n:2,ar:"الَّذِينَ هُمْ فِي صَلَاتِهِمْ خَاشِعُونَ",fr:"ceux qui sont humbles dans leur Salât,"},
{n:3,ar:"وَالَّذِينَ هُمْ عَنِ اللَّغْوِ مُعْرِضُونَ",fr:"qui s'écartent des futilités,"},
{n:4,ar:"وَالَّذِينَ هُمْ لِلزَّكَاةِ فَاعِلُونَ",fr:"qui s'acquittent de la Zakât,"},
{n:5,ar:"وَالَّذِينَ هُمْ لِفُرُوجِهِمْ حَافِظُونَ",fr:"qui préservent leur chasteté."},
{n:97,ar:"وَقُل رَّبِّ أَعُوذُ بِكَ مِنْ هَمَزَاتِ الشَّيَاطِينِ",fr:"Et dis : «Seigneur, je cherche protection auprès de Toi contre les suggestions des diables,"},
{n:98,ar:"وَأَعُوذُ بِكَ رَبِّ أَن يَحْضُرُونِ",fr:"et je cherche protection auprès de Toi, Seigneur, contre leur présence.»"},
{n:118,ar:"وَقُل رَّبِّ اغْفِرْ وَارْحَمْ وَأَنتَ خَيْرُ الرَّاحِمِينَ",fr:"Et dis : «Seigneur, pardonne et fais miséricorde. Tu es le meilleur des miséricordieux.»"},
];
QURAN_LOCAL[24]=[
{n:30,ar:"قُل لِّلْمُؤْمِنِينَ يَغُضُّوا مِنْ أَبْصَارِهِمْ وَيَحْفَظُوا فُرُوجَهُمْ",fr:"Dis aux croyants de baisser leurs regards et de préserver leurs parties sexuelles."},
{n:31,ar:"وَقُل لِّلْمُؤْمِنَاتِ يَغْضُضْنَ مِنْ أَبْصَارِهِنَّ وَيَحْفَظْنَ فُرُوجَهُنَّ",fr:"Et dis aux croyantes de baisser leurs regards et de préserver leurs parties sexuelles."},
{n:35,ar:"اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ مَثَلُ نُورِهِ كَمِشْكَاةٍ فِيهَا مِصْبَاحٌ",fr:"Allah est la Lumière des cieux et de la terre. Sa lumière est comparable à une niche où se trouve une lampe."},
{n:55,ar:"وَعَدَ اللَّهُ الَّذِينَ آمَنُوا مِنكُمْ وَعَمِلُوا الصَّالِحَاتِ لَيَسْتَخْلِفَنَّهُمْ فِي الْأَرْضِ",fr:"Allah a promis à ceux d'entre vous qui croient et accomplissent les bonnes œuvres de leur accorder la succession sur la terre."},
];
QURAN_LOCAL[25]=[
{n:1,ar:"تَبَارَكَ الَّذِي نَزَّلَ الْفُرْقَانَ عَلَىٰ عَبْدِهِ لِيَكُونَ لِلْعَالَمِينَ نَذِيرًا",fr:"Béni soit Celui qui a fait descendre le Discernement sur Son serviteur, afin qu'il soit un avertisseur pour les mondes."},
{n:63,ar:"وَعِبَادُ الرَّحْمَٰنِ الَّذِينَ يَمْشُونَ عَلَى الْأَرْضِ هَوْنًا",fr:"Les serviteurs du Tout Miséricordieux sont ceux qui marchent humblement sur la terre."},
{n:70,ar:"إِلَّا مَن تَابَ وَآمَنَ وَعَمِلَ عَمَلًا صَالِحًا فَأُولَٰئِكَ يُبَدِّلُ اللَّهُ سَيِّئَاتِهِمْ حَسَنَاتٍ",fr:"Sauf celui qui se repent, croit et fait une bonne œuvre ; Allah remplacera leurs mauvaises actions par de bonnes."},
];
QURAN_LOCAL[26]=[
{n:89,ar:"إِلَّا مَنْ أَتَى اللَّهَ بِقَلْبٍ سَلِيمٍ",fr:"sauf celui qui se présente à Allah avec un cœur sain."},
{n:227,ar:"إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَذَكَرُوا اللَّهَ كَثِيرًا",fr:"sauf ceux qui croient, font de bonnes œuvres et invoquent Allah fréquemment."},
];
QURAN_LOCAL[27]=[
{n:62,ar:"أَمَّن يُجِيبُ الْمُضْطَرَّ إِذَا دَعَاهُ وَيَكْشِفُ السُّوءَ",fr:"Qui répond à la prière de celui qui est en détresse quand il L'invoque, et dissipe le mal ?"},
{n:93,ar:"وَقُلِ الْحَمْدُ لِلَّهِ سَيُرِيكُمْ آيَاتِهِ فَتَعْرِفُونَهَا",fr:"Et dis : «Louange à Allah ! Il vous montrera Ses signes et vous les reconnaîtrez.»"},
];
QURAN_LOCAL[28]=[
{n:24,ar:"رَبِّ إِنِّي لِمَا أَنزَلْتَ إِلَيَّ مِنْ خَيْرٍ فَقِيرٌ",fr:"Seigneur, je suis pauvre du bien que Tu as fait descendre pour moi."},
{n:77,ar:"وَابْتَغِ فِيمَا آتَاكَ اللَّهُ الدَّارَ الْآخِرَةَ وَلَا تَنسَ نَصِيبَكَ مِنَ الدُّنْيَا",fr:"Recherche, dans ce qu'Allah t'a donné, la Demeure dernière, et n'oublie pas ta part en cette vie."},
{n:88,ar:"كُلُّ شَيْءٍ هَالِكٌ إِلَّا وَجْهَهُ لَهُ الْحُكْمُ وَإِلَيْهِ تُرْجَعُونَ",fr:"Toute chose périt, sauf Sa Face. À Lui appartient le jugement et c'est vers Lui que vous serez ramenés."},
];
QURAN_LOCAL[29]=[
{n:2,ar:"أَحَسِبَ النَّاسُ أَن يُتْرَكُوا أَن يَقُولُوا آمَنَّا وَهُمْ لَا يُفْتَنُونَ",fr:"Les hommes pensent-ils qu'on les laissera dire «Nous croyons» sans les éprouver ?"},
{n:45,ar:"اتْلُ مَا أُوحِيَ إِلَيْكَ مِنَ الْكِتَابِ وَأَقِمِ الصَّلَاةَ إِنَّ الصَّلَاةَ تَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ",fr:"Récite ce qui t'a été révélé du Livre et accomplis la Salât. La Salât préserve de la turpitude et du blâmable."},
{n:69,ar:"وَالَّذِينَ جَاهَدُوا فِينَا لَنَهْدِيَنَّهُمْ سُبُلَنَا وَإِنَّ اللَّهَ لَمَعَ الْمُحْسِنِينَ",fr:"Ceux qui luttent pour Nous, Nous les guiderons certes sur Nos sentiers. Allah est avec les bienfaisants."},
];
QURAN_LOCAL[30]=[
{n:21,ar:"وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا",fr:"Et parmi Ses signes : Il a créé de vous-mêmes, pour vous, des épouses afin que vous trouviez la quiétude auprès d'elles."},
{n:30,ar:"فَأَقِمْ وَجْهَكَ لِلدِّينِ حَنِيفًا فِطْرَتَ اللَّهِ الَّتِي فَطَرَ النَّاسَ عَلَيْهَا",fr:"Oriente-toi vers la religion en Hanif : la nature originelle qu'Allah a donnée aux hommes."},
];
QURAN_LOCAL[31]=[
{n:13,ar:"وَإِذْ قَالَ لُقْمَانُ لِابْنِهِ وَهُوَ يَعِظُهُ يَا بُنَيَّ لَا تُشْرِكْ بِاللَّهِ إِنَّ الشِّرْكَ لَظُلْمٌ عَظِيمٌ",fr:"Et quand Luqmân dit à son fils en le sermonnant : «Ô mon fils ! N'associe rien à Allah. L'association est vraiment une injustice immense.»"},
{n:17,ar:"يَا بُنَيَّ أَقِمِ الصَّلَاةَ وَأْمُرْ بِالْمَعْرُوفِ وَانْهَ عَنِ الْمُنكَرِ وَاصْبِرْ عَلَىٰ مَا أَصَابَكَ",fr:"«Ô mon fils ! Accomplis la Salât, commande le convenable, interdis le blâmable et endure ce qui t'arrive.»"},
{n:18,ar:"وَلَا تُصَعِّرْ خَدَّكَ لِلنَّاسِ وَلَا تَمْشِ فِي الْأَرْضِ مَرَحًا",fr:"«Et ne tourne pas ta joue avec dédain et ne marche pas sur la terre avec orgueil.»"},
{n:34,ar:"إِنَّ اللَّهَ عِندَهُ عِلْمُ السَّاعَةِ وَيُنَزِّلُ الْغَيْثَ وَيَعْلَمُ مَا فِي الْأَرْحَامِ",fr:"Certes, Allah seul a la connaissance de l'Heure. Il fait descendre la pluie et Il sait ce que contiennent les matrices."},
];
QURAN_LOCAL[32]=[
{n:15,ar:"إِنَّمَا يُؤْمِنُ بِآيَاتِنَا الَّذِينَ إِذَا ذُكِّرُوا بِهَا خَرُّوا سُجَّدًا وَسَبَّحُوا بِحَمْدِ رَبِّهِمْ",fr:"Seuls croient en Nos signes ceux qui, quand ils y sont rappelés, tombent prosternés et glorifient les louanges de leur Seigneur."},
{n:16,ar:"تَتَجَافَىٰ جُنُوبُهُمْ عَنِ الْمَضَاجِعِ يَدْعُونَ رَبَّهُمْ خَوْفًا وَطَمَعًا",fr:"Leurs flancs se détachent des couches pour invoquer leur Seigneur avec crainte et espoir."},
];
QURAN_LOCAL[33]=[
{n:21,ar:"لَّقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ",fr:"Vous avez dans le Messager d'Allah un excellent modèle."},
{n:41,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا اذْكُرُوا اللَّهَ ذِكْرًا كَثِيرًا",fr:"Ô les croyants ! Invoquez fréquemment Allah."},
{n:56,ar:"إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ يَا أَيُّهَا الَّذِينَ آمَنُوا صَلُّوا عَلَيْهِ وَسَلِّمُوا تَسْلِيمًا",fr:"Allah et Ses anges prient sur le Prophète. Ô les croyants ! Priez sur lui et adressez-lui vos salutations."},
];
QURAN_LOCAL[34]=[
{n:1,ar:"الْحَمْدُ لِلَّهِ الَّذِي لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ",fr:"Louange à Allah à qui appartient tout ce qui est dans les cieux et sur la terre."},
{n:39,ar:"قُلْ إِنَّ رَبِّي يَبْسُطُ الرِّزْقَ لِمَن يَشَاءُ مِنْ عِبَادِهِ وَيَقْدِرُ لَهُ",fr:"Dis : «Mon Seigneur accroît les moyens de subsistance à qui Il veut parmi Ses serviteurs, ou les restreint.»"},
];
QURAN_LOCAL[35]=[
{n:1,ar:"الْحَمْدُ لِلَّهِ فَاطِرِ السَّمَاوَاتِ وَالْأَرْضِ",fr:"Louange à Allah, Créateur des cieux et de la terre."},
{n:29,ar:"إِنَّ الَّذِينَ يَتْلُونَ كِتَابَ اللَّهِ وَأَقَامُوا الصَّلَاةَ وَأَنفَقُوا مِمَّا رَزَقْنَاهُمْ سِرًّا وَعَلَانِيَةً يَرْجُونَ تِجَارَةً لَّن تَبُورَ",fr:"Ceux qui récitent le Livre d'Allah, accomplissent la Salât et dépensent en secret et en public de ce que Nous leur avons attribué, espèrent un commerce qui ne périra pas."},
];
QURAN_LOCAL[37]=[
{n:99,ar:"وَقَالَ إِنِّي ذَاهِبٌ إِلَىٰ رَبِّي سَيَهْدِينِ",fr:"Et il dit : «Je vais vers mon Seigneur qui me guidera.»"},
{n:102,ar:"فَلَمَّا بَلَغَ مَعَهُ السَّعْيَ قَالَ يَا بُنَيَّ إِنِّي أَرَىٰ فِي الْمَنَامِ أَنِّي أَذْبَحُكَ فَانظُرْ مَاذَا تَرَىٰ",fr:"Puis quand celui-ci fut en âge de l'accompagner, il dit : «Ô mon fils, je me vois en songe en train de t'immoler. Qu'en penses-tu ?»"},
{n:103,ar:"فَلَمَّا أَسْلَمَا وَتَلَّهُ لِلْجَبِينِ",fr:"Puis quand tous deux se furent soumis et qu'il l'eut couché le front contre terre,"},
{n:104,ar:"وَنَادَيْنَاهُ أَن يَا إِبْرَاهِيمُ",fr:"Nous l'appelâmes : «Ibrâhîm !»"},
{n:105,ar:"قَدْ صَدَّقْتَ الرُّؤْيَا إِنَّا كَذَٰلِكَ نَجْزِي الْمُحْسِنِينَ",fr:"«Tu as confirmé la vision. C'est ainsi que Nous récompensons les bienfaisants.»"},
];
QURAN_LOCAL[38]=[
{n:29,ar:"كِتَابٌ أَنزَلْنَاهُ إِلَيْكَ مُبَارَكٌ لِّيَدَّبَّرُوا آيَاتِهِ وَلِيَتَذَكَّرَ أُولُو الْأَلْبَابِ",fr:"C'est un Livre béni que Nous t'avons révélé, afin qu'ils méditent ses versets et que les doués d'intelligence en tirent des enseignements."},
];
QURAN_LOCAL[39]=[
{n:9,ar:"قُلْ هَلْ يَسْتَوِي الَّذِينَ يَعْلَمُونَ وَالَّذِينَ لَا يَعْلَمُونَ",fr:"Dis : «Sont-ils égaux, ceux qui savent et ceux qui ne savent pas ?»"},
{n:53,ar:"قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَىٰ أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ إِنَّ اللَّهَ يَغْفِرُ الذُّنُوبَ جَمِيعًا",fr:"Dis : «Ô Mes serviteurs qui ont commis des excès à leur propre détriment, ne désespérez pas de la miséricorde d'Allah. Allah pardonne tous les péchés.»"},
];
QURAN_LOCAL[40]=[
{n:60,ar:"وَقَالَ رَبُّكُمُ ادْعُونِي أَسْتَجِبْ لَكُمْ",fr:"Et votre Seigneur a dit : «Appelez-Moi, Je vous répondrai.»"},
];
QURAN_LOCAL[41]=[
{n:30,ar:"إِنَّ الَّذِينَ قَالُوا رَبُّنَا اللَّهُ ثُمَّ اسْتَقَامُوا تَتَنَزَّلُ عَلَيْهِمُ الْمَلَائِكَةُ أَلَّا تَخَافُوا وَلَا تَحْزَنُوا",fr:"Ceux qui ont dit «Notre Seigneur est Allah» puis ont persévéré, les Anges descendent sur eux : «Ne craignez pas et ne soyez pas affligés.»"},
];
QURAN_LOCAL[42]=[
{n:11,ar:"لَيْسَ كَمِثْلِهِ شَيْءٌ وَهُوَ السَّمِيعُ الْبَصِيرُ",fr:"Il n'y a rien qui Lui ressemble, et c'est Lui l'Audient, le Clairvoyant."},
{n:30,ar:"وَمَا أَصَابَكُم مِّن مُّصِيبَةٍ فَبِمَا كَسَبَتْ أَيْدِيكُمْ وَيَعْفُو عَن كَثِيرٍ",fr:"Tout malheur qui vous atteint est dû à ce que vos mains ont acquis ; et Il pardonne beaucoup."},
];
QURAN_LOCAL[43]=[
{n:3,ar:"إِنَّا جَعَلْنَاهُ قُرْآنًا عَرَبِيًّا لَّعَلَّكُمْ تَعْقِلُونَ",fr:"Nous en avons fait un Coran arabe afin que vous compreniez."},
{n:89,ar:"فَاصْفَحْ عَنْهُمْ وَقُلْ سَلَامٌ فَسَوْفَ يَعْلَمُونَ",fr:"Pardonne-leur et dis «Salâm» car ils sauront bientôt."},
];
QURAN_LOCAL[44]=[
{n:3,ar:"إِنَّا أَنزَلْنَاهُ فِي لَيْلَةٍ مُّبَارَكَةٍ إِنَّا كُنَّا مُنذِرِينَ",fr:"Nous l'avons certes révélé pendant une nuit bénie — Nous avons toujours été des avertisseurs."},
];
QURAN_LOCAL[45]=[
{n:23,ar:"أَفَرَأَيْتَ مَنِ اتَّخَذَ إِلَٰهَهُ هَوَاهُ وَأَضَلَّهُ اللَّهُ عَلَىٰ عِلْمٍ",fr:"As-tu vu celui qui a pris sa passion pour divinité, et qu'Allah a égaré en connaissance de cause ?"},
];
QURAN_LOCAL[46]=[
{n:15,ar:"وَوَصَّيْنَا الْإِنسَانَ بِوَالِدَيْهِ إِحْسَانًا",fr:"Nous avons enjoint à l'homme de se montrer bienfaisant envers ses père et mère."},
{n:31,ar:"يَا قَوْمَنَا أَجِيبُوا دَاعِيَ اللَّهِ وَآمِنُوا بِهِ",fr:"«Ô notre peuple ! Répondez au Messager d'Allah et croyez en lui.»"},
];
QURAN_LOCAL[47]=[
{n:7,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا إِن تَنصُرُوا اللَّهَ يَنصُرْكُمْ وَيُثَبِّتْ أَقْدَامَكُمْ",fr:"Ô les croyants ! Si vous secourez Allah, Il vous aidera et renforcera vos positions."},
{n:19,ar:"فَاعْلَمْ أَنَّهُ لَا إِلَٰهَ إِلَّا اللَّهُ وَاسْتَغْفِرْ لِذَنبِكَ",fr:"Sache donc qu'il n'y a de divinité qu'Allah, et implore le pardon pour ton péché."},
];
QURAN_LOCAL[48]=[
{n:1,ar:"إِنَّا فَتَحْنَا لَكَ فَتْحًا مُّبِينًا",fr:"Certes, Nous t'avons accordé une victoire éclatante,"},
{n:29,ar:"مُّحَمَّدٌ رَّسُولُ اللَّهِ وَالَّذِينَ مَعَهُ أَشِدَّاءُ عَلَى الْكُفَّارِ رُحَمَاءُ بَيْنَهُمْ",fr:"Muhammad est le Messager d'Allah. Ceux qui sont avec lui sont rudes envers les mécréants, affectueux entre eux."},
];
QURAN_LOCAL[49]=[
{n:10,ar:"إِنَّمَا الْمُؤْمِنُونَ إِخْوَةٌ فَأَصْلِحُوا بَيْنَ أَخَوَيْكُمْ",fr:"Les croyants ne sont que des frères. Réconciliez donc vos deux frères."},
{n:11,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا لَا يَسْخَرْ قَوْمٌ مِّن قَوْمٍ",fr:"Ô les croyants ! Que des hommes ne se raillent pas d'autres hommes."},
{n:12,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا اجْتَنِبُوا كَثِيرًا مِّنَ الظَّنِّ إِنَّ بَعْضَ الظَّنِّ إِثْمٌ",fr:"Ô les croyants ! Evitez de trop conjecturer car certaines conjectures sont un péché."},
{n:13,ar:"يَا أَيُّهَا النَّاسُ إِنَّا خَلَقْنَاكُم مِّن ذَكَرٍ وَأُنثَىٰ وَجَعَلْنَاكُمْ شُعُوبًا وَقَبَائِلَ لِتَعَارَفُوا إِنَّ أَكْرَمَكُمْ عِندَ اللَّهِ أَتْقَاكُمْ",fr:"Ô hommes ! Nous vous avons créés d'un mâle et d'une femelle, et Nous avons fait de vous des nations et des tribus pour que vous vous entre-connaissiez. Le plus noble d'entre vous est le plus pieux."},
];
QURAN_LOCAL[50]=[
{n:16,ar:"وَلَقَدْ خَلَقْنَا الْإِنسَانَ وَنَعْلَمُ مَا تُوَسْوِسُ بِهِ نَفْسُهُ وَنَحْنُ أَقْرَبُ إِلَيْهِ مِنْ حَبْلِ الْوَرِيدِ",fr:"Nous avons créé l'homme et Nous savons ce que son âme lui souffle. Nous sommes plus près de lui que sa veine jugulaire."},
{n:45,ar:"نَّحْنُ أَعْلَمُ بِمَا يَقُولُونَ وَمَا أَنتَ عَلَيْهِمْ بِجَبَّارٍ فَذَكِّرْ بِالْقُرْآنِ مَن يَخَافُ وَعِيدِ",fr:"Nous savons mieux ce qu'ils disent. Tu n'es pas un despote sur eux. Rappelle, par le Coran, à celui qui craint Ma menace."},
];
QURAN_LOCAL[51]=[
{n:56,ar:"وَمَا خَلَقْتُ الْجِنَّ وَالْإِنسَ إِلَّا لِيَعْبُدُونِ",fr:"Je n'ai créé les djinns et les hommes que pour qu'ils M'adorent."},
{n:58,ar:"إِنَّ اللَّهَ هُوَ الرَّزَّاقُ ذُو الْقُوَّةِ الْمَتِينُ",fr:"C'est Allah qui est le Grand Pourvoyeur, le Détenteur de la force, l'Inébranlable."},
];
QURAN_LOCAL[52]=[
{n:21,ar:"وَالَّذِينَ آمَنُوا وَاتَّبَعَتْهُمْ ذُرِّيَّتُهُم بِإِيمَانٍ أَلْحَقْنَا بِهِمْ ذُرِّيَّتَهُمْ",fr:"Ceux qui ont cru et dont les descendants les ont suivis dans la foi, Nous leur avons joint leurs descendants."},
{n:28,ar:"إِنَّا كُنَّا مِن قَبْلُ نَدْعُوهُ إِنَّهُ هُوَ الْبَرُّ الرَّحِيمُ",fr:"Auparavant, nous L'invoquions. C'est Lui le Bienfaisant, le Miséricordieux."},
];
QURAN_LOCAL[53]=[
{n:39,ar:"وَأَن لَّيْسَ لِلْإِنسَانِ إِلَّا مَا سَعَىٰ",fr:"Et que l'homme n'obtient que le fruit de ses efforts,"},
{n:40,ar:"وَأَنَّ سَعْيَهُ سَوْفَ يُرَىٰ",fr:"et que ses efforts lui seront certes présentés,"},
{n:42,ar:"وَأَنَّ إِلَىٰ رَبِّكَ الْمُنتَهَىٰ",fr:"et que c'est vers ton Seigneur qu'est le terme final."},
];
QURAN_LOCAL[54]=[
{n:17,ar:"وَلَقَدْ يَسَّرْنَا الْقُرْآنَ لِلذِّكْرِ فَهَلْ مِن مُّدَّكِرٍ",fr:"Nous avons certes rendu le Coran facile pour la méditation. Y a-t-il quelqu'un pour méditer ?"},
];
QURAN_LOCAL[56]=[
{n:1,ar:"إِذَا وَقَعَتِ الْوَاقِعَةُ",fr:"Quand l'Événement arrivera,"},
{n:2,ar:"لَيْسَ لِوَقْعَتِهَا كَاذِبَةٌ",fr:"rien ne pourra nier son arrivée,"},
{n:3,ar:"خَافِضَةٌ رَّافِعَةٌ",fr:"elle abaissera [les uns] et élèvera [les autres]."},
{n:77,ar:"إِنَّهُ لَقُرْآنٌ كَرِيمٌ",fr:"C'est un Coran très noble,"},
{n:78,ar:"فِي كِتَابٍ مَّكْنُونٍ",fr:"dans un Livre bien gardé."},
{n:79,ar:"لَّا يَمَسُّهُ إِلَّا الْمُطَهَّرُونَ",fr:"Que seuls les purifiés touchent."},
];
QURAN_LOCAL[57]=[
{n:3,ar:"هُوَ الْأَوَّلُ وَالْآخِرُ وَالظَّاهِرُ وَالْبَاطِنُ وَهُوَ بِكُلِّ شَيْءٍ عَلِيمٌ",fr:"Il est le Premier et le Dernier, l'Apparent et le Caché, et Il est Omniscient."},
{n:4,ar:"وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ وَاللَّهُ بِمَا تَعْمَلُونَ بَصِيرٌ",fr:"Il est avec vous où que vous soyez, et Allah voit bien tout ce que vous faites."},
{n:20,ar:"اعْلَمُوا أَنَّمَا الْحَيَاةُ الدُّنْيَا لَعِبٌ وَلَهْوٌ وَزِينَةٌ وَتَفَاخُرٌ بَيْنَكُمْ",fr:"Sachez que la vie d'ici-bas n'est que jeu, amusement, parure, et sujet de gloriole entre vous."},
];
QURAN_LOCAL[58]=[
{n:11,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا قِيلَ لَكُمْ تَفَسَّحُوا فِي الْمَجَالِسِ فَافْسَحُوا يَفْسَحِ اللَّهُ لَكُمْ",fr:"Ô les croyants ! Quand on vous dit : «Faites de la place dans les assemblées», faites-en ; Allah en fera pour vous."},
];
QURAN_LOCAL[59]=[
{n:18,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَلْتَنظُرْ نَفْسٌ مَّا قَدَّمَتْ لِغَدٍ",fr:"Ô les croyants ! Craignez Allah et que chaque âme regarde ce qu'elle a préparé pour demain."},
{n:22,ar:"هُوَ اللَّهُ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ عَالِمُ الْغَيْبِ وَالشَّهَادَةِ هُوَ الرَّحْمَٰنُ الرَّحِيمُ",fr:"C'est Lui Allah. Point de divinité que Lui. Connaisseur du monde invisible et du monde visible. C'est Lui le Tout Miséricordieux, le Très Miséricordieux."},
{n:23,ar:"هُوَ اللَّهُ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ الْمَلِكُ الْقُدُّوسُ السَّلَامُ الْمُؤْمِنُ الْمُهَيْمِنُ الْعَزِيزُ الْجَبَّارُ الْمُتَكَبِّرُ",fr:"C'est Lui Allah. Point de divinité que Lui. Le Souverain, le Très Saint, la Source de Paix, le Gardien de la Foi, le Préservateur, le Puissant, le Fort, le Très Grand."},
{n:24,ar:"هُوَ اللَّهُ الْخَالِقُ الْبَارِئُ الْمُصَوِّرُ لَهُ الْأَسْمَاءُ الْحُسْنَىٰ",fr:"C'est Lui Allah, le Créateur, le Faiseur, le Façonneur. À Lui les beaux noms."},
];
QURAN_LOCAL[60]=[
{n:4,ar:"قَدْ كَانَتْ لَكُمْ أُسْوَةٌ حَسَنَةٌ فِي إِبْرَاهِيمَ",fr:"Ibrahim vous est certes un beau modèle."},
];
QURAN_LOCAL[61]=[
{n:2,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا لِمَ تَقُولُونَ مَا لَا تَفْعَلُونَ",fr:"Ô les croyants ! Pourquoi dites-vous ce que vous ne faites pas ?"},
{n:10,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا هَلْ أَدُلُّكُمْ عَلَىٰ تِجَارَةٍ تُنجِيكُم مِّنْ عَذَابٍ أَلِيمٍ",fr:"Ô les croyants ! Voulez-vous que je vous indique un commerce qui vous sauvera d'un châtiment douloureux ?"},
];
QURAN_LOCAL[62]=[
{n:9,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا نُودِيَ لِلصَّلَاةِ مِن يَوْمِ الْجُمُعَةِ فَاسْعَوْا إِلَىٰ ذِكْرِ اللَّهِ",fr:"Ô les croyants ! Quand on appelle à la Salât du vendredi, accourez à l'invocation d'Allah."},
];
QURAN_LOCAL[63]=[
{n:9,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا لَا تُلْهِكُمْ أَمْوَالُكُمْ وَلَا أَوْلَادُكُمْ عَن ذِكْرِ اللَّهِ",fr:"Ô les croyants ! Que ni vos biens ni vos enfants ne vous distraient du rappel d'Allah."},
];
QURAN_LOCAL[64]=[
{n:11,ar:"مَا أَصَابَ مِن مُّصِيبَةٍ إِلَّا بِإِذْنِ اللَّهِ وَمَن يُؤْمِن بِاللَّهِ يَهْدِ قَلْبَهُ",fr:"Nulle calamité ne survient qu'avec la permission d'Allah. Quiconque croit en Allah, Il guide son cœur."},
];
QURAN_LOCAL[65]=[
{n:2,ar:"وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا",fr:"Quiconque craint Allah, Il lui trouvera une issue,"},
{n:3,ar:"وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ",fr:"et lui accordera une subsistance d'où il ne s'y attend pas. Celui qui met sa confiance en Allah, Il lui suffit."},
];
QURAN_LOCAL[66]=[
{n:6,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا قُوا أَنفُسَكُمْ وَأَهْلِيكُمْ نَارًا وَقُودُهَا النَّاسُ وَالْحِجَارَةُ",fr:"Ô les croyants ! Préservez-vous et préservez vos familles d'un Feu dont le combustible est les hommes et les pierres."},
{n:8,ar:"يَا أَيُّهَا الَّذِينَ آمَنُوا تُوبُوا إِلَى اللَّهِ تَوْبَةً نَّصُوحًا",fr:"Ô les croyants ! Repentez-vous à Allah d'un repentir sincère."},
];


