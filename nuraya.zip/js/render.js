// ─── RENDER ─────────────────────────────────────────────────────
function render() {
  var pa = document.getElementById('PA');
  if (!pa) return;

  // Synchronisation du thème sur la coquille (barre haut, fond, nav, classe body, barre navigateur)
  document.body.classList.toggle('dark', !!S.dark);
  document.body.classList.add('theme-fade');
  document.body.classList.add('theme-fade');
  var th = activeTheme();
  var shellBg = S.dark ? th.dark.bg : th.light.bg;   // statusbar fond identique à la page (pas de bande chromée)
  var shellTx = S.dark ? hexA(th.dark.gold,.85) : hexA(th.light.gold,.85);
  pa.style.backgroundColor = bg();
  pa.style.zoom = S.profil.fontScale || 1;
  document.body.style.backgroundColor = bg();
  var sb = document.getElementById('SB');
  if (sb) { sb.style.background = shellBg; sb.style.borderBottom = 'none'; }
  var sbt = document.getElementById('SB_TIME');
  if (sbt) sbt.style.color = shellTx;
  // Variables CSS pilotant la nav et le bouton Nûr
  var rs = document.documentElement.style;
  rs.setProperty('--accent', gold());
  rs.setProperty('--accent-strong', goldStrong());
  rs.setProperty('--accent-soft', S.dark ? hexA(gold(),.85) : hexA(gold(),.7));
  rs.setProperty('--accent-glow', hexA(gold(), S.dark ? .18 : .14));
  rs.setProperty('--shell-edge', S.dark ? th.dark.bg2 : th.light.bg2);
  rs.setProperty('--nt-off', S.dark ? hexA(th.dark.tx,.42) : hexA(th.light.tx,.42));
  rs.setProperty('--nt-on-bg', S.dark ? hexA(gold(),.12) : hexA(gold(),.10));
  rs.setProperty('--skel-base', hexA(gold(), S.dark ? .05 : .06));
  rs.setProperty('--skel-hi', hexA(gold(), S.dark ? .14 : .13));
  var tc = document.querySelector('meta[name="theme-color"]');
  if (tc) tc.setAttribute('content', shellBg);

  var pillsDiv = document.getElementById('PILLS');

  // 1. PIN EN PREMIER — toujours
  if (S.locked) {
    pa.innerHTML = pageLock();
    hideNav();
    if (pillsDiv) { pillsDiv.innerHTML = ''; pillsDiv.style.display = 'none'; }
    return;
  }

  // 2. Consentement si pas encore donné
  var consent = localStorage.getItem(CONS_KEY);
  if (!consent) {
    pa.innerHTML = pageConsent();
    hideNav();
    if (pillsDiv) { pillsDiv.innerHTML = ''; pillsDiv.style.display = 'none'; }
    return;
  }

  // 3. Onboarding au premier lancement
  if (!S.profil.onboarded) {
    pa.innerHTML = pageOnboarding();
    hideNav();
    if (pillsDiv) { pillsDiv.innerHTML = ''; pillsDiv.style.display = 'none'; }
    if (typeof initOnboardingClock === 'function') initOnboardingClock();
    return;
  }

  // 4. App normale
  showNav();

  var map = {
    accueil: pageAccueil,
    coran: pageCoran,
    apprendre: pageApprendre,
    adorer: pageAdorer,
    quotidien: pageQuotidien,
    sunnafood: pageSunnaFood,
    foyer: pageFoyer,
    orga: pageOrga,
    cours: pageCours,
    aqida: pageAqida,
    tawhid: pageTawhid,
    sira: pageSira,
    prophetes: pageProphetes,
    asma: pageAsma,
    hajj: pageHajj,
    dhikr: pageDhikr,
    routine: pageRoutine,
    zakat: pageZakat,
    profil: pageProfil,
    femme: pageFemme,
    tarbiya: pageTarbiya,
    hifz: pageHifz,
    planning: pagePlanning,
    adhkar: pageAdhkar,
    ai: pageAI,
    salat: pageSalat,
    niyya: pageNiyya,
    qibla: pageQibla,
  };

  var tab = TAB_MAP[S.page] || 'accueil';

  // Update nav tabs
  ['accueil','coran','nur','apprendre','adorer','quotidien'].forEach(function(t) {
    var el = document.getElementById('nt-'+t);
    if (el) el.className = 'nt' + (t === 'nur' ? ' nt-nur' : '') + (t === tab ? ' on' : '');
  });

  // Update pills
  
  if (pillsDiv) {
    var list = (PILLS[tab] || []).filter(function(p){ return !(p[0]==='femme' && S.profil.genre==='homme'); });
    if (list.length > 0) {
      pillsDiv.innerHTML = pills(list, S.page, 'N');
      pillsDiv.style.display = '';
    } else {
      pillsDiv.innerHTML = '';
      pillsDiv.style.display = 'none';
    }
  }

  pa.innerHTML = (map[S.page] || pageAccueil)();
  pa.scrollTop = 0;
  if (S.page === 'qibla' && typeof initQibla === 'function') initQibla();
}

function hideNav() {
  var nav = document.getElementById('NAV');
  if (nav) nav.style.display = 'none';
}

function showNav() {
  var nav = document.getElementById('NAV');
  if (nav) nav.style.display = '';
}

// ─── PERSISTANCE ────────────────────────────────────────────────
function save() {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify({
      streak: S.streak,
      routineDots: S.routineDots,
      dhikrHistory: S.dhikrHistory,
      profil: S.profil,
      quranMemory: S.quranMemory,
      quranBookmarks: S.quranBookmarks,
    }));
  } catch(e) {}
}

// Cache du Coran stocké à part (volumineux) — écrit uniquement quand il change
var QURAN_KEY = SAVE_KEY + '_QURAN';
function saveQuran() {
  try {
    localStorage.setItem(QURAN_KEY, JSON.stringify(S.cachedSurahs));
    return true;
  } catch(e) {
    // Quota dépassé : on garde le cache en mémoire pour la session
    return false;
  }
}

function load() {
  try {
    var raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      var d = JSON.parse(raw);
      if (d.streak !== undefined) S.streak = d.streak;
      if (d.routineDots) S.routineDots = d.routineDots;
      if (d.dhikrHistory) S.dhikrHistory = d.dhikrHistory;
      if (d.profil) S.profil = Object.assign(S.profil, d.profil);
      if (d.quranMemory) S.quranMemory = d.quranMemory;
      if (d.quranBookmarks) S.quranBookmarks = d.quranBookmarks;
      if (d.cachedSurahs) S.cachedSurahs = d.cachedSurahs; // migration anciennes versions
    }
    if (typeof computeNiyyaStreak === 'function') computeNiyyaStreak();
    // Migration des anciens identifiants de récitateur (format incompatible) → everyayah
    var RECITER_MIGRATE = {
      'ar.alafasy':'Alafasy_128kbps', 'ar.abdurrahmaansudais':'Abdurrahmaan_As-Sudais_192kbps',
      'ar.mahermuaiqly':'MaherAlMuaiqly128kbps', 'ar.husary':'Husary_128kbps'
    };
    if (RECITER_MIGRATE[S.quranReciter]) S.quranReciter = RECITER_MIGRATE[S.quranReciter];
    if (!S.quranReciter || S.quranReciter.indexOf('.') !== -1) S.quranReciter = 'Alafasy_128kbps';
    var rq = localStorage.getItem(QURAN_KEY);
    if (rq) S.cachedSurahs = Object.assign(S.cachedSurahs, JSON.parse(rq));
  } catch(e) {}
}

// ─── PIN & CONSENTEMENT ─────────────────────────────────────────
async function hashPin(pin) {
  var buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(pin + SALT));
  return Array.from(new Uint8Array(buf)).map(function(b) { return b.toString(16).padStart(2,'0'); }).join('');
}


// ─── FONCTIONS PIN ──────────────────────────────────────────────
function pinKey(k) {
  if (isPinLocked()) return;
  if (k === '⌫') {
    S.pinEntry = S.pinEntry.slice(0, -1);
    updatePinDots();
    return;
  }
  if (S.pinEntry.length >= 4) return;
  S.pinEntry += String(k);
  if (navigator.vibrate) navigator.vibrate(10);
  updatePinDots();
  if (S.pinEntry.length === 4) {
    setTimeout(function() { checkPinSecure(S.pinEntry); }, 120);
  }
}

function updatePinDots() {
  for (var i = 0; i < 4; i++) {
    var dot = document.getElementById('PIN_DOT_' + i);
    if (dot) {
      dot.style.background = S.pinEntry.length > i ? '#E2D38C' : 'rgba(226,211,140,.2)';
      dot.style.transform = S.pinEntry.length === i + 1 ? 'scale(1.3)' : 'scale(1)';
    }
  }
}

function pageLock() {
  var lockMsg = isPinLocked() ? 'Accès bloqué — ' + getLockRemaining() : '';
  var hasPin = !!localStorage.getItem(PIN_KEY);
  // Mode création ou saisie
  var isCreating = !hasPin;
  var th = activeTheme();
  var darkBg = th.dark.bg, darkBg2 = th.dark.bg2, darkGold = th.dark.gold, darkTx = th.dark.tx, darkTx2 = th.dark.tx2;
  return '<div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:80px 28px 32px;background:radial-gradient(140% 90% at 50% 30%,'+darkBg2+' 0%,'+darkBg+' 65%,#000 130%);position:relative">'
    + '<svg width="46" height="46" viewBox="0 0 100 100" fill="none" style="opacity:.5;margin-bottom:38px"><path d="M50 6l8 16 16-4-4 16 16 8-16 8 4 16-16-4-8 16-8-16-16 4 4-16-16-8 16-8-4-16 16 4z" stroke="'+darkGold+'" stroke-width=".9"/><circle cx="50" cy="50" r="3" fill="'+darkGold+'"/></svg>'
    + '<p class="display" style="font-size:42px;font-weight:300;color:'+darkTx+';margin-bottom:10px;letter-spacing:-.02em;line-height:1">'+(isCreating?'Créer votre code':'Bienvenue')+'</p>'
    + '<p class="display-italic" style="font-size:17px;color:'+hexA(darkTx2,.9)+';margin-bottom:44px;font-weight:300;text-align:center">'+(isCreating?'Choisissez un PIN à 4 chiffres':'Entrez votre PIN pour accéder')+'</p>'
    + '<div style="display:flex;gap:14px;margin-bottom:48px">'
      + [0,1,2,3].map(function(i) {
          var filled = S.pinEntry.length>i;
          return '<div id="PIN_DOT_'+i+'" style="width:10px;height:10px;border-radius:50%;background:'+(filled?darkGold:hexA(darkGold,.18))+';transition:all .2s cubic-bezier(.34,1.56,.64,1);transform:scale('+(filled?1.2:1)+')"></div>';
        }).join('')
    + '</div>'
    + (lockMsg ? '<p style="font-size:14px;color:#E58A6F;margin-bottom:18px;font-family:inherit;text-align:center;letter-spacing:-.005em">'+esc(lockMsg)+'</p>' : '')
    + (S.pinError ? '<p style="font-size:14px;color:#E58A6F;margin-bottom:18px;font-family:inherit;text-align:center;letter-spacing:-.005em">'+esc(S.pinError)+'</p>' : '')
    + '<div style="display:grid;grid-template-columns:repeat(3,72px);gap:18px;margin-top:auto;margin-bottom:24px">'
      + [1,2,3,4,5,6,7,8,9,'',0,'⌫'].map(function(k) {
          if (k === '') return '<div></div>';
          var isBs = k === '⌫';
          return '<button onclick="pinKey(\''+k+'\')" class="press" style="width:72px;height:72px;border-radius:50%;border:.5px solid '+hexA(darkGold,.14)+';background:'+hexA(darkGold,.04)+';font-family:Fraunces,Georgia,serif;font-weight:300;font-size:'+(isBs?'20':'30')+'px;color:'+(isBs?hexA(darkTx,.7):darkTx)+';cursor:pointer;font-variant-numeric:tabular-nums;letter-spacing:-.01em;display:flex;align-items:center;justify-content:center;transition:background .15s,transform .12s">'+k+'</button>';
        }).join('')
    + '</div>'
    + (hasPin ? '<button onclick="forgotPin()" class="display-italic" style="margin-bottom:24px;background:none;border:none;color:'+hexA(darkTx2,.55)+';font-size:14px;cursor:pointer;font-weight:300;letter-spacing:.01em">Mot de passe oublié ?</button>' : '')
  + '</div>';
}

function pageConsent() {
  return '<div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;background:'+bg()+'">'
    + logoSVG(72)
    + '<p style="font-size:26px;font-family:Fraunces,Georgia,serif;color:'+tx()+';margin:12px 0 4px">Bienvenue sur Nûraya</p>'
    + '<p style="font-size:19px;color:'+tx2()+';margin-bottom:18px;letter-spacing:.04em;font-family:system-ui">نورايا · Compagnon islamique</p>'
    + card(
        '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:12px">🔒 Vos données, votre contrôle</p>'
        + [
          ['📱','Données locales','Tout reste sur votre appareil. Rien n\'est envoyé à un serveur.'],
          ['🌐','APIs externes','Texte du Coran : api.alquran.cloud · Tafsir Ibn Kathir : cdn.jsdelivr.net (lecture seule, aucune donnée perso).'],
          ['🗑️','Effacement','Supprimez tout depuis Profil → Sécurité à tout moment.'],
        ].map(function(r) {
          return '<div style="display:flex;gap:8px;align-items:flex-start;margin-bottom:8px">'
            + '<span style="font-size:21px;flex-shrink:0">'+r[0]+'</span>'
            + '<div><p style="font-size:18px;font-weight:600;color:'+tx()+'">'+r[1]+'</p>'
            + '<p style="font-size:17px;color:'+tx2()+';font-family:system-ui">'+r[2]+'</p></div>'
          + '</div>';
        }).join('')
      )
    + '<button onclick="giveConsent()" style="width:100%;max-width:340px;padding:14px;border-radius:16px;border:none;background:'+bx()+';color:#E2D38C;font-size:19px;font-family:Fraunces,Georgia,serif;cursor:pointer;margin-bottom:8px">J\'accepte et je commence ✦</button>'
    + '<button onclick="refuseConsent()" style="width:100%;max-width:340px;padding:10px;border-radius:16px;border:1px solid '+br()+';background:transparent;color:'+tx2()+';font-size:18px;font-family:system-ui;cursor:pointer">Refuser (fonctionnalités limitées)</button>'
    + '<p style="font-size:17px;color:rgba(26,58,42,.35);margin-top:10px;font-family:system-ui">Nûraya · RGPD conforme · Données locales</p>'
  + '</div>';
}

function giveConsent() { localStorage.setItem(CONS_KEY, 'true'); S.consentGiven = true; if (localStorage.getItem(PIN_KEY)) { S.locked = true; } render(); }
function refuseConsent() { localStorage.setItem(CONS_KEY, 'refused'); S.consentGiven = false; S.locked = false; render(); }

