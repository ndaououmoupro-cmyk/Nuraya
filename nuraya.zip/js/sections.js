// ─── Grille de section réutilisable (cohérence visuelle totale) ───
function sectionGrid(titre, sousTitre, sections) {
  var acc = gold();
  return '<div class="stagger" style="padding:14px 16px 24px">'
    + '<div style="text-align:center;margin-bottom:6px">'
      + '<p style="font-size:27px;font-family:Fraunces,Georgia,serif;color:'+tx()+'">'+esc(titre)+'</p>'
      + '<p style="font-size:16px;color:'+tx2()+';margin-top:2px">'+esc(sousTitre)+'</p>'
    + '</div>'
    + ornSep()
    + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">'
      + sections.map(function(s){
          return '<button class="press" onclick="N(\''+s.id+'\')" style="background:'+bg2()+';border:1px solid '+br()+';border-radius:18px;padding:16px 13px;display:flex;flex-direction:column;align-items:flex-start;gap:8px;cursor:pointer;text-align:left;position:relative;overflow:hidden;box-shadow:0 3px 12px '+(S.dark?'rgba(0,0,0,.3)':hexA(acc,.06))+'">'
            + '<div style="position:absolute;right:-12px;bottom:-12px;pointer-events:none">'+ornStar(58, acc, .06)+'</div>'
            + '<div style="background:'+hexA(acc,.1)+';border:1px solid '+hexA(acc,.2)+';border-radius:13px;width:46px;height:46px;display:flex;align-items:center;justify-content:center;font-size:24px">'+s.e+'</div>'
            + '<div><p style="font-size:18px;font-weight:700;color:'+tx()+';font-family:Fraunces,Georgia,serif">'+s.t+'</p>'
            + '<p style="font-size:14px;color:'+tx2()+';line-height:1.35;margin-top:1px">'+s.d+'</p></div>'
          + '</button>';
        }).join('')
    + '</div>'
  + '</div>';
}

// 📖 APPRENDRE — le savoir religieux pur
function pageApprendre() {
  var S2 = [
    {id:'aqida',     e:'⭐', t:'Aqida',      d:'Les fondements de la croyance'},
    {id:'tawhid',    e:'☝️', t:'Tawhid',     d:'L\'unicité d\'Allah'},
    {id:'sira',      e:'🕌', t:'Sîra ﷺ',     d:'La vie du Prophète'},
    {id:'prophetes', e:'📜', t:'Prophètes',  d:'Les messagers d\'Allah'},
    {id:'asma',      e:'☾',  t:'99 Noms',    d:'Les beaux noms d\'Allah'},
    {id:'cours',     e:'🎓', t:'Mes cours',  d:'Suivi des sciences religieuses'},
    {id:'hifz',      e:'📖', t:'Hifz',       d:'Mémorisation du Coran'},
    {id:'tarbiya',   e:'🌱', t:'Tarbiya',    d:'Éducation des enfants'},
  ];
  return sectionGrid('Apprendre', 'Le savoir, pas à pas', S2);
}

// 🕌 ADORER — les actes d'adoration
function pageAdorer() {
  var S2 = [
    {id:'salat',  e:'🕌', t:'Prière',  d:'Horaires & guide de la salât'},
    {id:'qibla',  e:'🧭', t:'Qibla',   d:'Direction de la Kaaba'},
    {id:'dhikr',  e:'📿', t:'Dhikr',   d:'Compteur & invocations'},
    {id:'adhkar', e:'🌙', t:'Adhkâr',  d:'Du matin et du soir'},
    {id:'hajj',   e:'🕋', t:'Hajj',    d:'Le pèlerinage, étape par étape'},
    {id:'zakat',  e:'💰', t:'Zakât',   d:'Calcul de l\'aumône'},
  ];
  return sectionGrid('Adorer', 'Tes actes d\'adoration', S2);
}

// 🌿 MON QUOTIDIEN — les outils de vie
function pageQuotidien() {
  var S2 = [
    {id:'niyya',     e:'🌅', t:'Niyya du jour', d:'Intention & bilan du soir'},
    {id:'routine',   e:'☑',  t:'Routine',       d:'Tes habitudes quotidiennes'},
    {id:'planning',  e:'🗓️', t:'Planning',      d:'Compose ta journée'},
    {id:'sunnafood', e:'🫒', t:'Sunna alimentaire', d:'Aliments bénis & adab'},
    {id:'foyer',     e:'🏡', t:'Foyer',         d:'Tâches & baraka du foyer'},
  ];
  if (S.profil.genre !== 'homme') {
    S2.push({id:'orga',  e:'🌷', t:'Organisation', d:'Équilibre dîn & quotidien'});
    S2.push({id:'femme', e:'🌸', t:'Espace Femme', d:'Cycle, fiqh & bien-être'});
  }
  return sectionGrid('Mon quotidien', 'Organise ta vie avec ihsân', S2);
}

function pageAqida() {
  if (S.aqidaCours !== null) return pageAqidaDetail();
  return hdr("Aqida · عَقِيدَة", "Cours 01→11 · Institut Al-Ihsan", "N('apprendre')")
    + '<div style="padding:10px 14px">'
    + AQIDA_COURS.map(function(c) {
        return '<button onclick="S.aqidaCours=\''+c.id+'\';render()" style="width:100%;background:'+bg2()+';border:1px solid '+br()+';border-radius:14px;padding:12px 14px;margin-bottom:8px;display:flex;align-items:center;gap:10px;cursor:pointer;text-align:left">'
          + '<div style="width:36px;height:36px;border-radius:10px;background:rgba(26,58,42,.12);display:flex;align-items:center;justify-content:center;flex-shrink:0"><span style="font-size:17px;font-weight:700;color:'+bxT()+'">'+c.num+'</span></div>'
          + '<div style="flex:1;min-width:0">'
            + '<p style="font-size:17px;font-weight:600;color:'+tx()+'">'+esc(c.titre)+'</p>'
            + '<p style="font-size:17px;color:'+tx2()+';margin-top:2px">'+esc(c.resume)+'</p>'
            + '<p style="font-size:17px;color:'+bxT()+';margin-top:3px">'+esc(c.date)+'</p>'
          + '</div>'
          + '<span style="color:rgba(191,174,85,.5);font-size:21px">›</span>'
        + '</button>';
      }).join('')
    + '</div>';
}

function pageAqidaDetail() {
  var c = AQIDA_COURS.find(function(x) { return x.id === S.aqidaCours; });
  if (!c) { S.aqidaCours = null; return pageAqida(); }
  return hdr(c.titre, 'Aqida Niveau 1 · Cours '+c.num, 'S.aqidaCours=null;render()')
    + '<div style="padding:10px 14px">'
    + c.blocs.map(function(b) {
        if (b.t === 'def') return card(
          '<p style="font-size:18px;font-weight:700;color:'+bxT()+';margin-bottom:4px">'+esc(b.ti)+'</p>'
          + '<p style="font-size:19px;color:'+tx()+';line-height:1.75">'+esc(b.tx)+'</p>',
          'border-left:3px solid '+bxT()
        );
        if (b.t === 'titre') return '<p style="font-size:19px;font-weight:700;color:'+gold()+';margin:10px 0 6px;text-transform:uppercase;letter-spacing:.06em">'+esc(b.tx)+'</p>';
        if (b.t === 'item') return card(
          '<div style="display:flex;gap:8px;align-items:flex-start">'
            + '<div style="width:20px;height:20px;border-radius:6px;background:'+bx()+';display:flex;align-items:center;justify-content:center;flex-shrink:0"><span style="font-size:18px;font-weight:700;color:#E2D38C">'+b.n+'</span></div>'
            + '<div><p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(b.ti)+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(b.tx)+'</p></div>'
          + '</div>'
        );
        if (b.t === 'verset') return '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:8px">'
          + '<p style="font-family:Fraunces,Georgia,serif;font-size:22px;color:'+gold()+';text-align:right;direction:rtl;line-height:2">'+b.ar+'</p>'
          + '<p style="font-size:18px;color:'+tx()+';font-style:italic;margin:4px 0 2px">'+esc(b.fr)+'</p>'
          + '<p style="font-size:17px;color:'+bxT()+';font-weight:700">'+esc(b.ref)+'</p>'
        + '</div>';
        if (b.t === 'hadith') return gcard(
          '<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:4px">Hadith</p>'
          + '<p style="font-size:19px;color:'+tx()+';line-height:1.75;font-style:italic">« '+esc(b.tx)+' »</p>'
          + '<p style="font-size:17px;color:'+gold()+';margin-top:4px">'+esc(b.src)+'</p>'
        );
        if (b.t === 'warn') return '<div style="background:rgba(229,115,115,.08);border:1px solid rgba(229,115,115,.25);border-radius:12px;padding:10px 12px;margin-bottom:8px">'
          + '<p style="font-size:19px;color:'+tx()+';line-height:1.7">⚠️ '+esc(b.tx)+'</p>'
        + '</div>';
        if (b.t === 'methode') return card(
          '<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:5px">'+esc(b.ti)+'</p>'
          + b.etapes.map(function(e) { return '<p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(e)+'</p>'; }).join('')
          + '<p style="font-size:18px;color:'+bxT()+';margin-top:5px;font-style:italic">Ex: '+esc(b.ex)+'</p>',
          'border-left:3px solid '+gold()
        );
        if (b.t === 'point') return card(
          '<div style="display:flex;gap:8px;align-items:flex-start">'
            + '<div style="width:22px;height:22px;border-radius:7px;background:'+bx()+';display:flex;align-items:center;justify-content:center;flex-shrink:0"><span style="font-size:19px;font-weight:700;color:#E2D38C">'+b.n+'</span></div>'
            + '<div><p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:4px">'+esc(b.ti)+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(b.tx)+'</p></div>'
          + '</div>',
          'border-left:3px solid '+gold()
        );
        return '';
      }).join('')
    + '</div>';
}

// ─── TAWHID ─────────────────────────────────────────────────────
function pageTawhid() {
  var tabs = [['intro','Définition'],['cats','3 Catégories'],['bienfaits','Bienfaits'],['shirk','Shirk'],['dawah',"Da'wa"]];
  var d = TAWHID_DATA;
  var content = '';

  if (S.tawhidTab === 'intro') {
    content = card('<p style="font-size:19px;color:'+tx()+';line-height:1.8">'+esc(d.intro.def)+'</p>', 'border-left:3px solid '+bxT())
      + gcard('<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:4px">Hadith</p><p style="font-size:19px;color:'+tx()+';font-style:italic;line-height:1.75">« '+esc(d.intro.hadith)+' »</p><p style="font-size:17px;color:'+gold()+';margin-top:3px">'+esc(d.intro.src)+'</p>')
      + '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:12px;margin-bottom:8px">'
        + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:6px">'+d.intro.talbiya+'</p>'
        + '<p style="font-size:18px;color:'+tx()+';font-style:italic">'+esc(d.intro.talbiya_fr)+'</p>'
      + '</div>';
  } else if (S.tawhidTab === 'cats') {
    content = d.cats.map(function(c) {
      return card('<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;margin-bottom:4px">'+c.ar+'</p>'
        + '<p style="font-size:17px;font-weight:700;color:'+tx()+'">'+esc(c.fr)+'</p>'
        + '<p style="font-size:18px;color:'+bxT()+';font-weight:600;margin-bottom:4px">'+esc(c.sub)+'</p>'
        + '<p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(c.desc)+'</p>', 'border-left:3px solid '+bxT());
    }).join('');
  } else if (S.tawhidTab === 'bienfaits') {
    content = '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:10px">'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:5px">الَّذِينَ آمَنُوا وَلَمْ يَلْبِسُوا إِيمَانَهُم بِظُلْمٍ أُولَٰئِكَ لَهُمُ الْأَمْنُ وَهُم مُّهْتَدُونَ</p>'
      + '<p style="font-size:18px;color:'+tx()+';font-style:italic">Ceux qui ont cru et n\'ont point troublé leur foi par quelqu\'inéquité — ceux-là ont la sécurité.</p>'
      + '<p style="font-size:17px;color:'+bxT()+';font-weight:700;margin-top:3px">Al-An\'âm 6:82</p>'
    + '</div>'
    + d.bienfaits.map(function(b) {
        return card('<div style="display:flex;gap:8px"><div style="width:20px;height:20px;border-radius:6px;background:'+bx()+';display:flex;align-items:center;justify-content:center;flex-shrink:0"><span style="font-size:18px;font-weight:700;color:#E2D38C">'+b.n+'</span></div><div><p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(b.ti)+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(b.tx)+'</p></div></div>');
      }).join('');
  } else if (S.tawhidTab === 'shirk') {
    var s = d.shirk;
    content = [
      {data:s.akbar, color:'#E57373'},
      {data:s.asghar, color:'#FFB74D'},
    ].map(function(item) {
      return '<div style="background:'+bg2()+';border:1.5px solid '+item.color+'30;border-radius:14px;padding:12px 14px;margin-bottom:8px">'
        + '<p style="font-size:19px;font-weight:700;color:'+item.color+';margin-bottom:6px">'+esc(item.data.titre)+'</p>'
        + '<p style="font-size:18px;font-weight:600;color:'+tx()+';margin-bottom:4px">Effets :</p>'
        + item.data.effets.map(function(e) { return '<p style="font-size:18px;color:'+tx2()+';line-height:1.7">• '+esc(e)+'</p>'; }).join('')
        + '<p style="font-size:18px;font-weight:600;color:'+tx()+';margin:6px 0 4px">Exemples :</p>'
        + item.data.ex.map(function(e) { return '<p style="font-size:18px;color:'+tx2()+'">• '+esc(e)+'</p>'; }).join('')
      + '</div>';
    }).join('')
    + '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:8px">'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:4px">'+s.verset.ar+'</p>'
      + '<p style="font-size:18px;color:'+tx()+';font-style:italic">'+esc(s.verset.fr)+'</p>'
      + '<p style="font-size:17px;color:'+bxT()+';font-weight:700;margin-top:3px">'+esc(s.verset.ref)+'</p>'
    + '</div>'
    + gcard('<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:4px">Duʿâ de protection</p>'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:19px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:5px">'+s.dua.ar+'</p>'
      + '<p style="font-size:18px;color:'+tx()+';line-height:1.7">'+esc(s.dua.fr)+'</p>');
  } else if (S.tawhidTab === 'dawah') {
    var daw = d.dawah;
    content = '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:8px">'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:4px">'+daw.verset.ar+'</p>'
      + '<p style="font-size:18px;color:'+tx()+';font-style:italic">'+esc(daw.verset.fr)+'</p>'
      + '<p style="font-size:17px;color:'+bxT()+';font-weight:700;margin-top:3px">'+esc(daw.verset.ref)+'</p>'
    + '</div>'
    + daw.conds.map(function(c) {
        return card('<p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(c.ti)+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(c.desc)+'</p>');
      }).join('')
    + gcard('<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:4px">Méthode de Mu\'âdh</p><p style="font-size:18px;color:'+tx()+';line-height:1.75">'+esc(daw.hadith)+'</p>');
  }

  return hdr("Tawhid · التَّوْحِيد", "Fiqh Maliki Niveau 2 · Kitab At-Tawhid", "N('apprendre')")
    + pills(tabs, S.tawhidTab, 'setTawhidTab')
    + '<div style="padding:10px 14px">' + content + '</div>';
}

function setTawhidTab(t) { S.tawhidTab = t; render(); }

