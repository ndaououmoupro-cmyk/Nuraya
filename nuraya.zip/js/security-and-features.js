// ═══════════════════════════════════════════════════════════════
// NOUVELLES FONCTIONNALITÉS NÛRAYA
// 1. Sécurité PIN renforcée
// 2. Espace Femme
// 3. Éducation islamique
// 4. Planning mémorisation Coran
// ═══════════════════════════════════════════════════════════════

// ─── 1. SÉCURITÉ RENFORCÉE ──────────────────────────────────────
var MAX_PIN_ATTEMPTS = 5;
var PIN_LOCKOUT_KEY = 'nuraya_pin_lockout';
var PIN_ATTEMPTS_KEY = 'nuraya_pin_attempts';

function getPinAttempts() {
  return parseInt(localStorage.getItem(PIN_ATTEMPTS_KEY) || '0');
}

function isPinLocked() {
  var lockUntil = parseInt(localStorage.getItem(PIN_LOCKOUT_KEY) || '0');
  return Date.now() < lockUntil;
}

function getLockRemaining() {
  var lockUntil = parseInt(localStorage.getItem(PIN_LOCKOUT_KEY) || '0');
  var remaining = Math.ceil((lockUntil - Date.now()) / 1000);
  if (remaining <= 0) return 0;
  if (remaining > 60) return Math.ceil(remaining/60) + ' min';
  return remaining + ' sec';
}

function recordPinFailure() {
  var attempts = getPinAttempts() + 1;
  localStorage.setItem(PIN_ATTEMPTS_KEY, attempts);
  if (attempts >= MAX_PIN_ATTEMPTS) {
    // Blocage progressif : 5min, 15min, 30min...
    var block = [5,15,30,60][Math.min(Math.floor((attempts-MAX_PIN_ATTEMPTS)/2), 3)];
    localStorage.setItem(PIN_LOCKOUT_KEY, Date.now() + block * 60000);
    localStorage.setItem(PIN_ATTEMPTS_KEY, '0');
    return true;
  }
  return false;
}

function resetPinAttempts() {
  localStorage.removeItem(PIN_ATTEMPTS_KEY);
  localStorage.removeItem(PIN_LOCKOUT_KEY);
}

// Remplacer checkPin avec version renforcée
async function checkPinSecure(pin) {
  if (isPinLocked()) {
    S.pinError = 'Trop de tentatives. Réessayez dans ' + getLockRemaining();
    render(); return;
  }
  var stored = localStorage.getItem(PIN_KEY);
  var h = await hashPin(pin);
  if (!stored) {
    localStorage.setItem(PIN_KEY, h);
    resetPinAttempts();
    S.locked = false; S.pinEntry = ''; S.pinError = '';
    if (localStorage.getItem('nuraya_v1_consent') === 'true') { load(); }
    render();
  } else if (h === stored) {
    resetPinAttempts();
    S.locked = false; S.pinEntry = ''; S.pinError = '';
    if (!localStorage.getItem('nuraya_v1_consent')) {
      // Pas encore de consentement, charger quand même
    } else {
      load();
    }
    render();
  } else {
    var blocked = recordPinFailure();
    S.pinEntry = '';
    var remaining = MAX_PIN_ATTEMPTS - getPinAttempts();
    if (blocked) {
      S.pinError = 'Accès bloqué ' + getLockRemaining() + ' (trop de tentatives)';
    } else {
      S.pinError = 'PIN incorrect — ' + remaining + ' essai(s) restant(s)';
    }
    if (navigator.vibrate) navigator.vibrate([50,30,50,30,50]);
    render();
  }
}

// ─── 2. DONNÉES ESPACE FEMME ────────────────────────────────────
var FEMME_DATA = {
  cycle: {
    titre: "Cycle féminin — أحكام الحيض",
    intro: "Repères de fiqh pour la femme musulmane. Base : madhhab Maliki, avec mention des autres écoles lorsqu'elles diffèrent.",
    haid: {
      titre: "Haid — الحيض (Menstrues)",
      def: "Le haid est le sang qui coule naturellement de l'utérus d'une femme en bonne santé, sans cause de maladie ni d'accouchement. Durée min : 1 jour/nuit. Durée max : 15 jours (Maliki). Habituelle : 6-7 jours.",
      interdits: [
        "La Salât (prière) — ni accomplie ni à rattraper",
        "Le Siyam (jeûne) — interrompu, mais à rattraper",
        "Le Tawâf autour de la Ka'ba",
        "Réciter le Coran à voix haute : interdit chez la majorité ; les Maliki l'autorisent, surtout de mémoire ou pour l'enseignement",
        "Toucher le Mushaf directement sans purification (un écran ou une barrière reste permis)",
        "Les relations conjugales",
        "Séjourner dans la salle de prière (musallâ) de la mosquée — point discuté dans toutes les écoles ; cela ne vise pas toute l'enceinte de la mosquée"
      ],
      permis: [
        "Le dhikr, les salawât, les du'as",
        "Écouter le Coran",
        "Lire le Coran des yeux / en silence : permis chez la majorité des écoles ; le réciter de mémoire chez les Maliki",
        "Lire les livres islamiques, apprendre, enseigner",
        "Accéder à la mosquée en dehors de la salle de prière (cour, espaces annexes) selon le besoin — valable pour toutes les écoles",
        "La sadaqa et les bonnes œuvres"
      ],
      taharah: "La purification est complète à l'arrêt total du sang, suivi du Ghusl (lavage intégral du corps). Dès qu'elle est pure, elle reprend la prière.",
      rattrapage: "Si le sang s'arrête alors qu'il reste encore un peu du temps d'une prière — même seulement quelques minutes avant que ce temps n'expire — cette prière lui devient due : elle fait le Ghusl puis l'accomplit. Pour les prières « jumelables » : chez la majorité (Maliki, Shafi'i, Hanbali), se purifier dans le temps du 'Asr rend dues Dhuhr + 'Asr, et dans le temps du 'Ishâ rend dues Maghrib + 'Ishâ ; les Hanafi limitent à la seule prière du temps en cours. Le Fajr reste toujours seul. Pour un cas précis qui te laisse un doute, demande à une personne de science.",
    },
    nifas: {
      titre: "Nifâs — النفاس (Lochies post-partum)",
      def: "Sang expulsé par l'utérus à cause de l'accouchement. Il peut apparaître pendant, après, ou 2-3 jours avant l'accouchement (accompagné de contractions).",
      points: [
        "Un liquide blanc — avec ou sans contractions — n'est pas du nifâs : il annule seulement les ablutions (même jugement que les pertes jaunes/brunes).",
        "C'est du nifâs si le sang suit l'expulsion d'un fœtus formé, dont on distingue au moins une partie du corps (≈ 81 jours ou plus). Avant ce stade, ce n'est pas du nifâs.",
        "Durée habituelle : 40 jours. Maximum : 40 jours selon le séminaire de Médine (position Hanafi/Hanbali) ; jusqu'à 60 jours chez les Maliki. Au-delà du maximum retenu, le sang devient de la métrorragie.",
        "Si elle devient pure avant la fin du délai : Ghusl, puis elle prie et jeûne. Si le sang reprend ensuite dans le délai, c'est encore du nifâs — et les prières/jeûnes faits entre-temps restent valides.",
        "Pertes jaunes/brunes juste après le sang, dans le délai : considérées comme nifâs. Vues après la purification : traitées comme métrorragie.",
        "Fausse couche d'un sac vide / œuf clair (sans fœtus) : un sang d'au moins 1 jour + 1 nuit est du haid ; moins que cela n'est pas des menstrues (elle lave et fait ses ablutions)."
      ],
    },
    istihada: {
      titre: "Istihâdha — الاستحاضة (Saignement irrégulier · métrorragies)",
      def: "Sang qui coule sans s'interrompre — ou ne s'arrête que très peu (un jour ou deux) — en dehors du haid/nifâs, dû à une faiblesse ou une maladie : les métrorragies. La femme n'est pas dispensée : elle prie et jeûne. Réf. : hadith de Fâtima bint Abî Hubaysh (Bukhârî & Muslim).",
      caracteres: {
        menstrues: "Menstrues : rouge tirant vers le noir · épais · à l'odeur marquée · sort du col de l'utérus.",
        metrorragie: "Métrorragie : rouge vif (comme le sang d'une coupure) · léger, fluide · inodore · sort du haut de l'utérus.",
        note: "Une seule de ces caractéristiques suffit à reconnaître le sang ; nul besoin de les réunir toutes."
      },
      situations: [
        { t: "1 · Cycle habituel connu", d: "Elle se base sur la durée et la période de son cycle habituel. Tout sang au-delà de cette période est de la métrorragie. Ex. : cycle de 6 jours en début de mois → au-delà, Ghusl puis prière, malgré le sang." },
        { t: "2 · Distinction par les caractères (tamyîz)", d: "Sans cycle régulier mais avec un sang reconnaissable : tant que le sang a l'aspect des menstrues (foncé, épais, odeur), c'est haid ; dès qu'il devient rouge vif et fluide, c'est métrorragie → Ghusl." },
        { t: "3 · Ni cycle connu ni distinction possible", d: "Elle retient la durée de la majorité des femmes : 6 à 7 jours (en s'inspirant de ses proches par l'âge / la parenté). Le reste est de la métrorragie." }
      ],
      regles: [
        "Faire les ablutions (wudû') à chaque prière, une fois son heure entrée. Le Ghusl à chaque prière n'est pas obligatoire (seulement recommandé pour certains Hanbalites, car c'est une difficulté).",
        "Avant les ablutions : laver les traces de sang et mettre une protection (coton / serviette hygiénique). Si, malgré la précaution, le sang coule, ce n'est pas grave.",
        "Obligatoire à chaque prière : refaire les ablutions, laver le sang et changer la protection.",
        "Relations conjugales : sujet de divergence — certains les autorisent (par crainte de la débauche), d'autres sans condition ; Al-Baqara (2:222) ne demande de s'écarter que pendant les menstrues, pas la métrorragie."
      ]
    },
    secretions: {
      titre: "Pertes jaunes & brunes (kudra / sufra)",
      def: "Pertes jaunes : un liquide jaunâtre ressemblant à du pus. Pertes brunes : la couleur d'une eau trouble/tachée, sans la teinte franche du sang.",
      regles: [
        "Vues pendant les règles, ou immédiatement après sans interruption : considérées comme des menstrues.",
        "Vues après la purification (liquide blanc ou dessèchement déjà constatés) : ce ne sont pas des menstrues → métrorragie. Hadith d'Umm 'Atiyya : « Nous ne comptions pas les traces troubles et jaunâtres après la pureté. »",
        "Avant l'écoulement du sang : intermittentes → métrorragie ; continues puis suivies aussitôt du sang des règles → menstrues."
      ]
    },
    purification: {
      titre: "Signes de purification & Ghusl",
      signes: [
        "Le liquide blanc (al-qassa al-bayda') : une sécrétion blanche qui s'écoule juste après le sang, ou après les pertes rattachées aux règles.",
        "Le dessèchement (jufûf) : en s'essuyant (coton / papier), constater une propreté nette, sans trace de sang ni de pertes."
      ],
      signes_note: "Si elle constate le dessèchement sans voir le liquide blanc (cas de certaines femmes) : l'avis retenu par la cheikha est d'attendre un jour et une nuit ; si rien ne change, elle se considère pure depuis le moment du constat, et rattrape la prière / le jeûne de l'intervalle si besoin.",
      ghusl: [
        "Intention de lever l'impureté majeure (janâba), puis nommer Allah (bismillâh).",
        "Laver les mains, puis les parties intimes.",
        "Faire les ablutions comme pour la prière.",
        "Verser l'eau sur la tête en la faisant pénétrer jusqu'à la racine des cheveux (3 fois), puis sur tout le corps.",
        "Le Ghusl complet (ablutions intégrées) est recommandé et préférable."
      ]
    },
  },
  parure: {
    titre: "Parure — الزينة",
    intro: "La parure (zîna) englobe tout ce avec quoi la femme s'embellit : vêtement, bijou, coloration, khôl… Le principe de base en fiqh : tout est permis tant qu'aucune preuve n'indique le contraire. « Ô enfants d'Adam ! Portez votre parure en chaque lieu de prière… » (Al-A'râf 31-32).",
    principes: [
      "Ne pas contredire un texte religieux.",
      "Ne pas imiter les femmes mécréantes ou dépravées, ni les hommes.",
      "Ne pas modifier la création d'Allah ni s'opposer à la fitra.",
      "Pas d'excès, de gaspillage ni de perte de temps (le temps est précieux).",
      "Aucun élément illicite (vol, orgueil…), impur (porc, alcool, sang…) ni néfaste (ce qui cause un tort, ex. allergie)."
    ],
    vetements_titre: "Les vêtements — la ‘awra selon la personne présente",
    vetements: [
      { t: "Devant une autre musulmane", d: "Couvrir tout le corps sauf ce qui apparaît habituellement : cou, cheveux, mains, pieds, une partie des jambes (fatwa de la Lajna ad-Dâ'ima). Mais rien de moulant qui mette les formes en valeur, même si cela couvre. Et ne pas regarder des femmes dénudées ou très moulantes (réseaux, etc.)." },
      { t: "Devant une non-musulmane", d: "Divergence ; l'avis retenu par la cheikha : elle peut montrer les mêmes parties que devant une musulmane." },
      { t: "Devant un mahram", d: "Comme devant les femmes : ce qui apparaît habituellement (An-Nûr 31). Un mahram reste un mahram, qu'il soit musulman ou non." },
      { t: "Devant un homme non-mahram (étranger)", d: "Tout cacher, y compris le visage et les mains : avis de la majorité des Hanafites et Shafi'ites, avis le plus juste chez les Hanbalites et d'une partie des Malikites (Al-Ahzâb 59)." }
    ],
    regles_vetement: [
      "Ne pas ressembler au vêtement de la femme mécréante (« qui imite un peuple en fait partie »).",
      "Ne pas ressembler au vêtement de l'homme (le Prophète ﷺ a maudit l'imitation entre les deux).",
      "Ni transparent, ni serré, ni moulant : sinon « vêtue mais dévêtue » (Muslim).",
      "Pas de vêtement de chouhra (ostentation) par lequel on se distingue ou s'exhibe.",
      "Pas d'images d'êtres vivants, surtout bien visibles (les anges n'entrent pas dans une maison qui en contient)."
    ],
    visage_permis: [
      "Maquillage — attention au waterproof qui empêche l'eau d'atteindre la peau (ablutions invalides).",
      "Lentilles de couleur",
      "Se blanchir les dents",
      "Manucure / vernis — à retirer pour les ablutions",
      "Se couper les cheveux",
      "Masques avec des aliments permis (ex. miel)",
      "Se faire percer les oreilles / le nez",
      "Enlever les poils en trop du corps et du visage"
    ],
    visage_interdit: [
      "Faux cils (assimilés aux extensions)",
      "Faux ongles (analogie avec les extensions ; contraires à la fitra)",
      "Extensions de cheveux / perruque (harâm)",
      "Épiler ou redessiner les sourcils"
    ],
    parfums: "La base : tout ce qui parfume est permis (parfum, 'oud, eau de rose, musc…). Si le parfum contient de l'alcool en quantité enivrante, il est impur et la prière faite avec est invalide ; si la quantité est infime, non détectable et non enivrante, il est permis."
  },
  grossesse: {
    titre: "Grossesse & Islam — الحمل",
    items: [
      { titre: "Statut de l'enfant à naître", desc: "L'enfant conçu dans un mariage licite est musulman de naissance. Le Prophète ﷺ a dit : 'Chaque enfant naît dans la fitra (nature islamique originelle).' [Bukhâri]" },
      { titre: "Du'a durant la grossesse", ar: "رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا", fr: "Seigneur, accorde-nous, de nos époux et de nos descendants, ce qui réjouit nos yeux, et fais de nous un modèle pour les pieux.", ref: "Al-Furqan 25:74" },
      { titre: "Dispense de jeûne", desc: "La femme enceinte ou allaitante peut ne pas jeûner si elle craint pour elle-même ou son enfant. Elle doit rattraper les jours." },
      { titre: "Prière durant la grossesse", desc: "La femme enceinte peut prier assise si la station debout est difficile. Allah ne charge personne au-delà de ses capacités." },
    ],
  },
  duas_femme: [
    { titre: "Du'a pour un époux pieux", ar: "رَبِّ هَبْ لِي مِن لَّدُنكَ زَوْجًا طَيِّبًا", fr: "Seigneur, accorde-moi de Ta part un époux pieux.", src: "Inspiré de la Sunnah" },
    { titre: "Du'a pour les enfants", ar: "رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِن ذُرِّيَّتِي", fr: "Seigneur, fais que j'accomplisse la Salât ainsi que ma descendance.", src: "Ibrahim 14:40" },
    { titre: "Du'a de Maryam", ar: "رَبِّ إِنِّي وَضَعْتُهَا أُنثَىٰ وَاللَّهُ أَعْلَمُ بِمَا وَضَعَتْ", fr: "Seigneur, je l'ai mise au monde — une fille. Allah sait mieux ce qu'elle a mis au monde.", src: "Al-Imran 3:36" },
    { titre: "Du'a pour la protection", ar: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّةِ مِن كُلِّ شَيْطَانٍ وَهَامَّةٍ", fr: "Je cherche refuge dans les Paroles parfaites d'Allah contre tout diable et bête nuisible.", src: "Al-Bukhâri 3371 — hadith du Prophète ﷺ pour ses petits-enfants" },
    { titre: "Pour la facilité en tout", ar: "اللَّهُمَّ لَا سَهْلَ إِلَّا مَا جَعَلْتَهُ سَهْلًا وَأَنتَ تَجْعَلُ الْحَزْنَ إِذَا شِئْتَ سَهْلًا", fr: "Ô Allah, rien n'est facile sauf ce que Tu rends facile, et Tu peux rendre la difficulté facile quand Tu veux.", src: "Ibn Hibban" },
    { titre: "Salawat abondante", ar: "اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ", fr: "Ô Allah, prie sur Muhammad et sur la famille de Muhammad.", src: "Al-Bukhâri & Muslim" },
  ],
  modeles: [
    { nom: "Khadîja bint Khuwaylid رضي الله عنها", titre: "Première épouse du Prophète ﷺ", desc: "Première croyante de l'Islam. Femme d'affaires accomplie, mère de 6 enfants du Prophète ﷺ. Elle le soutint de ses biens et de sa personne. Le Prophète ﷺ dit : 'Elle m'a cru quand les autres me traitaient de menteur, elle m'a aidé de ses biens quand les autres me privaient.' [Bukhâri]" },
    { nom: "Âïsha bint Abi Bakr رضي الله عنها", titre: "Mère des croyants — source de la Sunnah", desc: "La plus savante des femmes de l'Islam. Un quart du Fiqh islamique est transmis par elle. Les Compagnons venaient la consulter. Le Prophète ﷺ dit : 'Prenez la moitié de votre religion de cette Humayra.' Elle transmit plus de 2000 hadiths." },
    { nom: "Fatima az-Zahra رضي الله عنها", titre: "Fille du Prophète ﷺ, maîtresse des femmes du Paradis", desc: "La plus chère au Prophète ﷺ. Modèle de piété, de patience et de contentement. Elle s'occupait de sa maison malgré la fatigue. Le Prophète ﷺ dit : 'Fatima est une partie de moi — ce qui la blesse me blesse.' [Bukhâri]" },
    { nom: "Maryam bint Imran عليها السلام", titre: "La meilleure des femmes du monde", desc: "Allah lui révéla directement par les anges. Elle consacra sa vie à l'adoration. 'Ô Maryam ! Allah t'a choisie, t'a purifiée et t'a choisie parmi toutes les femmes du monde.' [Al-Imran 3:42]" },
    { nom: "Asma bint Abi Bakr رضي الله عنها", titre: "Dhât an-Nitaqayn — la femme aux deux ceintures", desc: "Fille d'Abu Bakr رضي الله عنه. Apporta de la nourriture au Prophète ﷺ et à son père cachés dans la grotte lors de la Hijra. Courageuse, savante, généreuse. Vécut jusqu'à 100 ans." },
  ],
};

