// ─── SIRA ───────────────────────────────────────────────────────
function pageSira() {
  var tabs = [['physique','Description'],['sceau','Sceau'],['cheveux','Cheveux'],['canitie','Canitie']];
  var d = SIRA_DATA[S.siraTab];
  return hdr("Sira · الشَّمَائِل", "As-Shamâ'il al-Muhammadiyya · At-Tirmidhî", "N('apprendre')")
    + pills(tabs, S.siraTab, 'setSiraTab')
    + '<div style="padding:10px 14px">'
    + '<p style="font-size:17px;font-weight:700;color:'+tx()+';margin-bottom:6px">'+esc(d.titre)+'</p>'
    + (d.intro ? card('<p style="font-size:19px;color:'+tx()+';line-height:1.75;font-style:italic">'+esc(d.intro)+'</p>', 'border-left:3px solid '+gold()) : '')
    + d.items.map(function(item) {
        return card('<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px">'+esc(item.cat)+'</p><p style="font-size:19px;color:'+tx()+';line-height:1.75">'+esc(item.desc)+'</p>');
      }).join('')
    + '</div>';
}

function setSiraTab(t) { S.siraTab = t; render(); }

// ─── PROPHÈTES ──────────────────────────────────────────────────
function pageProphetes() {
  if (S.propheteIdx !== null) return pagePropheteDetail();
  var tagFilter = S.propheteTag || 'all';
  var list = tagFilter === 'all' ? PROPHETES : PROPHETES.filter(function(p) { return p.tags.indexOf(tagFilter) !== -1; });
  return hdr("25 Prophètes du Coran", "Histoires · Leçons · Références", "N('apprendre')")
    + pills([['all','Tous'],['patience','Patience'],['tawhid','Tawhid'],['repentir','Repentir'],['miracle','Miracle']], tagFilter, 'setPropheteTag')
    + '<div style="padding:10px 14px">'
    + list.map(function(p, i) {
        var realIdx = PROPHETES.indexOf(p);
        return '<button onclick="S.propheteIdx='+realIdx+';render()" style="width:100%;background:'+bg2()+';border:1px solid '+br()+';border-radius:12px;padding:10px 12px;margin-bottom:6px;display:flex;align-items:center;gap:8px;cursor:pointer;text-align:left">'
          + '<div style="width:32px;height:32px;border-radius:9px;background:rgba(26,58,42,.1);display:flex;align-items:center;justify-content:center;flex-shrink:0"><span style="font-size:18px;font-weight:700;color:'+bxT()+'">'+(realIdx+1)+'</span></div>'
          + '<div style="flex:1">'
            + '<div style="display:flex;justify-content:space-between;align-items:center">'
              + '<span style="font-size:17px;font-weight:600;color:'+tx()+'">'+esc(p.fr)+'</span>'
              + '<span style="font-family:Fraunces,Georgia,serif;font-size:19px;color:'+bxT()+'">'+p.ar+'</span>'
            + '</div>'
            + '<p style="font-size:18px;color:'+tx2()+';margin-top:2px">'+esc(p.titre)+'</p>'
          + '</div>'
          + '<span style="color:rgba(191,174,85,.5);font-size:21px">›</span>'
        + '</button>';
      }).join('')
    + '</div>';
}

function setPropheteTag(t) { S.propheteTag = t; render(); }

function pagePropheteDetail() {
  var p = PROPHETES[S.propheteIdx];
  return hdr(p.fr + ' — ' + p.ar, p.titre, 'S.propheteIdx=null;render()')
    + '<div style="padding:10px 14px">'
    + '<p style="font-size:17px;color:'+tx2()+';margin-bottom:8px">⏳ '+esc(p.epoque)+' · 📖 '+esc(p.ref)+'</p>'
    + card('<p style="font-size:18px;color:'+bxT()+';font-weight:600;margin-bottom:5px">Histoire</p><p style="font-size:19px;color:'+tx()+';line-height:1.8">'+esc(p.resume)+'</p>', 'border-left:3px solid '+bxT())
    + gcard('<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:4px">✦ Leçon essentielle</p><p style="font-size:19px;color:'+tx()+';line-height:1.75;font-style:italic">'+esc(p.lecon)+'</p>')
    + '<div style="display:flex;flex-wrap:wrap;gap:4px">'
      + p.tags.map(function(t) { return '<span style="font-size:17px;background:rgba(26,58,42,.1);color:'+bxT()+';border-radius:8px;padding:3px 9px">'+esc(t)+'</span>'; }).join('')
    + '</div>'
    + '</div>';
}

// ─── 99 NOMS ────────────────────────────────────────────────────
function pageAsma() {
  if (S.asmaIdx !== null) return pageAsmaDetail();
  var q = (S.asmaSearch || '').toLowerCase();
  var list = q ? ASMA.filter(function(n) {
    return n.fr.toLowerCase().includes(q) || n.tr.toLowerCase().includes(q) || String(n.n) === q;
  }) : ASMA;

  return hdr("99 Noms d'Allah", "Al-Asmâ' al-Husnâ · Méditation", "N('apprendre')")
    + '<div style="padding:8px 14px 4px">'
      + '<input value="'+esc(S.asmaSearch||'')+'" oninput="S.asmaSearch=this.value;render()" placeholder="Rechercher un nom…" style="width:100%;padding:7px 10px;border-radius:11px;border:1.5px solid '+br()+';background:'+bg2()+';color:'+tx()+';font-size:18px;font-family:inherit;box-sizing:border-box;margin-bottom:6px">'
    + '</div>'
    + '<div style="padding:0 14px 8px;display:grid;grid-template-columns:1fr 1fr;gap:6px">'
      + list.map(function(n, i) {
          return '<button onclick="S.asmaIdx='+ASMA.indexOf(n)+';render()" style="background:'+bg2()+';border:1px solid '+br()+';border-radius:12px;padding:8px;text-align:center;cursor:pointer">'
            + '<p style="font-size:17px;color:'+tx2()+';margin-bottom:2px">#'+n.n+'</p>'
            + '<p style="font-family:Fraunces,Georgia,serif;font-size:22px;color:'+bxT()+';direction:rtl;margin-bottom:2px;line-height:1.4">'+n.ar+'</p>'
            + '<p style="font-size:18px;font-weight:600;color:'+gold()+';margin-bottom:1px">'+esc(n.fr)+'</p>'
            + '<p style="font-size:17px;color:'+tx2()+'">'+esc(n.tr)+'</p>'
          + '</button>';
        }).join('')
    + '</div>';
}

function pageAsmaDetail() {
  var n = ASMA[S.asmaIdx];
  return hdr(n.fr + ' — ' + n.ar, '#' + n.n + ' · ' + n.tr, 'S.asmaIdx=null;render()')
    + '<div style="padding:10px 14px">'
    + card('<p style="font-family:Fraunces,Georgia,serif;font-size:30px;color:'+gold()+';text-align:center;direction:rtl;margin-bottom:6px;line-height:1.5">'+n.ar+'</p>'
      + '<p style="font-size:19px;font-weight:700;color:'+tx()+';text-align:center;margin-bottom:3px">'+esc(n.fr)+'</p>'
      + '<p style="font-size:19px;color:'+tx2()+';text-align:center">'+esc(n.tr)+'</p>')
    + gcard('<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:4px">✦ Méditation</p><p style="font-size:19px;color:'+tx()+';line-height:1.8">'+esc(n.med)+'</p>')
    + card('<p style="font-size:18px;color:'+tx2()+';font-weight:600;margin-bottom:3px">Référence</p><p style="font-size:18px;color:'+tx()+'">'+esc(n.ref)+'</p>')
    + '</div>';
}

// ─── HAJJ ───────────────────────────────────────────────────────
function pageHajj() {
  var d = HAJJ_DATA;
  return hdr("Hajj · الحَجّ", "5ème pilier de l'Islam · Étapes", "N('adorer')")
    + '<div style="padding:10px 14px">'
    + '<p style="font-size:19px;color:'+tx()+';line-height:1.7;margin-bottom:8px">'+esc(d.def)+'</p>'
    + '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:10px">'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:4px">'+d.verset.ar+'</p>'
      + '<p style="font-size:18px;color:'+tx()+';font-style:italic;margin-bottom:2px">'+esc(d.verset.fr)+'</p>'
      + '<p style="font-size:17px;color:'+bxT()+';font-weight:700">'+esc(d.verset.ref)+'</p>'
    + '</div>'
    + '<p style="font-size:18px;font-weight:700;color:'+gold()+';text-transform:uppercase;letter-spacing:.08em;margin-bottom:7px">Les 10 étapes du Hajj</p>'
    + d.etapes.map(function(e) {
        return '<div style="display:flex;gap:0;margin-bottom:8px">'
          + '<div style="width:28px;display:flex;flex-direction:column;align-items:center">'
            + '<div style="width:22px;height:22px;border-radius:7px;background:'+bx()+';display:flex;align-items:center;justify-content:center;flex-shrink:0"><span style="font-size:19px;font-weight:700;color:#E2D38C">'+e.num+'</span></div>'
            + (e.num < 10 ? '<div style="width:2px;flex:1;background:rgba(26,58,42,.15);margin:2px auto"></div>' : '')
          + '</div>'
          + '<div style="flex:1;padding-left:10px;padding-bottom:4px">'
            + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:3px">'
              + '<p style="font-size:17px;font-weight:700;color:'+tx()+'">'+esc(e.nom)+'</p>'
              + '<span style="font-family:Fraunces,Georgia,serif;font-size:19px;color:'+bxT()+'">'+e.ar+'</span>'
            + '</div>'
            + '<p style="font-size:18px;color:'+bxT()+';margin-bottom:3px">📍 '+esc(e.lieu)+'</p>'
            + '<p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(e.desc)+'</p>'
          + '</div>'
        + '</div>';
      }).join('')
    + gcard('<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:5px">Talbiya</p>'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:21px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:4px">'+d.talbiya.ar+'</p>'
      + '<p style="font-size:18px;color:'+tx()+';line-height:1.7">'+esc(d.talbiya.fr)+'</p>')
    + '</div>';
}


