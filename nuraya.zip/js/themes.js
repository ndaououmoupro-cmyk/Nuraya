// ─── THÈME ──────────────────────────────────────────────────────
// ─── Thèmes sélectionnables (espace Profil) ───
var THEMES = {
  emeraude: {
    nom:'Émeraude', emoji:'❦',
    light:{ bg:'#EDE7D6', bg2:'#F6F1E2', tx:'#0F1C16', tx2:'#506B57', br:'#D4C9A8', gold:'#94733A', goldS:'#6B4E20', goldT:'#7C5F2A', bxT:'#0F2A1E' },
    dark: { bg:'#0A0F0C', bg2:'#121A14', tx:'#F1EBDA', tx2:'#94B39C', br:'#1F2A22', gold:'#D9B66E', goldS:'#E5C788', goldT:'#E5C788', bxT:'#A3D2B0' },
    bx:'#0F2A1E', grad:['#143A2A','#08130D']
  },
  rose: {
    nom:'Rose poudré', emoji:'❀',
    light:{ bg:'#EFE6D8', bg2:'#F6EEDF', tx:'#2E1A20', tx2:'#8A5A65', br:'#D4C0AE', gold:'#A86A48', goldS:'#7A4630', goldT:'#8A5232', bxT:'#5C2638' },
    dark: { bg:'#0F0A0C', bg2:'#1A1014', tx:'#F1E2DC', tx2:'#C99CAB', br:'#2A1A20', gold:'#E5B49A', goldS:'#EFC8B0', goldT:'#EFC8B0', bxT:'#E5B49A' },
    bx:'#5C2638', grad:['#7A3046','#3F1422']
  },
  lavande: {
    nom:'Lavande', emoji:'❖',
    light:{ bg:'#EAE3D2', bg2:'#F2EBDB', tx:'#1F1830', tx2:'#5E5278', br:'#CCC0AC', gold:'#7355A0', goldS:'#523778', goldT:'#5E4282', bxT:'#2E1F52' },
    dark: { bg:'#0B0810', bg2:'#13101A', tx:'#EBDCC8', tx2:'#A99CC9', br:'#1F1828', gold:'#C2A6E0', goldS:'#D0BAE8', goldT:'#D0BAE8', bxT:'#C2A6E0' },
    bx:'#2E1F52', grad:['#3E2870','#1F1240']
  },
  pivoine: {
    nom:'Pivoine & or', emoji:'❉',
    light:{ bg:'#EFE4D2', bg2:'#F7EBD7', tx:'#2E1C18', tx2:'#8A5A4A', br:'#D4BFA2', gold:'#A86838', goldS:'#7A4620', goldT:'#86501E', bxT:'#5C2812' },
    dark: { bg:'#0F0A07', bg2:'#1A100A', tx:'#F1DEC0', tx2:'#C9A593', br:'#2A1812', gold:'#E0B486', goldS:'#E8C8A0', goldT:'#E8C8A0', bxT:'#E0B486' },
    bx:'#5C2812', grad:['#7A3018','#3F1408']
  },
  nuit: {
    nom:'Nuit & lumière', emoji:'✧',
    light:{ bg:'#EBE5CE', bg2:'#F4EDD3', tx:'#15182C', tx2:'#5C5A6E', br:'#D2C896', gold:'#86691C', goldS:'#65500F', goldT:'#7A5F18', bxT:'#161E38' },
    dark: { bg:'#06091C', bg2:'#0F1430', tx:'#F0DEAC', tx2:'#A39F8E', br:'#1A2042', gold:'#E7C778', goldS:'#F2D998', goldT:'#F2D998', bxT:'#B4BEE4' },
    bx:'#161E38', grad:['#1F2848','#08091F']
  },
  sable: {
    nom:'Sable doux', emoji:'✦',
    light:{ bg:'#EDE3CC', bg2:'#F5EBCE', tx:'#241C12', tx2:'#7A6E5C', br:'#D8BE92', gold:'#8A6418', goldS:'#65480F', goldT:'#75520F', bxT:'#4A371C' },
    dark: { bg:'#0A0805', bg2:'#13100A', tx:'#F0DEB4', tx2:'#B5A88F', br:'#22180E', gold:'#D9BE84', goldS:'#E5CE9C', goldT:'#E5CE9C', bxT:'#D9BE84' },
    bx:'#4A371C', grad:['#5C401E','#28180A']
  },
};
function hexA(hex, a) {
  var h = hex.replace('#',''); if (h.length===3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
  var r=parseInt(h.slice(0,2),16), g=parseInt(h.slice(2,4),16), b=parseInt(h.slice(4,6),16);
  return 'rgba('+r+','+g+','+b+','+a+')';
}

// ─── Ornements (très restreints, juste un filet et un glyphe) ───
function ornSep() {
  var g = gold();
  return '<div style="display:flex;align-items:center;justify-content:center;gap:14px;margin:18px 0;opacity:.9">'
    + '<span style="height:.5px;width:48px;background:'+g+';opacity:.42"></span>'
    + '<span style="font-family:Fraunces,serif;font-size:11px;color:'+g+';opacity:.7;letter-spacing:.3em">✦</span>'
    + '<span style="height:.5px;width:48px;background:'+g+';opacity:.42"></span>'
  + '</div>';
}
function ornStar(size, color, op) {
  size = size || 120; op = op == null ? .05 : op;
  var c = color || gold();
  return '<svg width="'+size+'" height="'+size+'" viewBox="0 0 100 100" fill="none" style="opacity:'+op+'">'
    + '<path d="M50 6l8 16 16-4-4 16 16 8-16 8 4 16-16-4-8 16-8-16-16 4 4-16-16-8 16-8-4-16 16 4z" stroke="'+c+'" stroke-width=".9" fill="none"/>'
    + '<circle cx="50" cy="50" r="3" fill="'+c+'"/>'
    + '</svg>';
}

function activeTheme() { return THEMES[S.profil && S.profil.theme] || THEMES.emeraude; }
function pal() { var t = activeTheme(); return S.dark ? t.dark : t.light; }

function bg()   { return pal().bg; }
function bg2()  { return pal().bg2; }
function tx()   { return pal().tx; }
function tx2()  { return pal().tx2; }
function br()   { return pal().br; }
function gold() { return pal().gold; }
function goldStrong() { return pal().goldS; }
function goldT(){ return pal().goldT; }
function bx()   { return activeTheme().bx; }
function bxT()  { return S.dark ? pal().bxT : activeTheme().bx; }

// ─── UTILITAIRES HTML ────────────────────────────────────────────
function esc(s) {
  if (typeof s !== 'string') return '';
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function card(content, extra) {
  var sh = S.dark
    ? '0 1px 0 rgba(241,235,218,.04), 0 8px 24px rgba(0,0,0,.30)'
    : '0 1px 0 rgba(255,255,255,.5), 0 8px 24px '+hexA(activeTheme().bx,.06)+', 0 1px 2px '+hexA(activeTheme().bx,.04);
  return '<div style="background:'+bg2()+';border:.5px solid '+br()+';border-radius:18px;padding:18px 18px;margin-bottom:12px;box-shadow:'+sh+(extra?';'+extra:'')+'">'
    + content + '</div>';
}

function gcard(content) {
  var g = gold();
  var bgc = S.dark ? hexA(g,.06) : hexA(g,.05);
  return '<div style="background:'+bgc+';border:.5px solid '+hexA(g,.22)+';border-radius:18px;padding:18px 18px;margin-bottom:12px">'
    + content + '</div>';
}

function hdr(title, sub, backFn) {
  var th = activeTheme();
  var g = gold();
  var grad = S.dark
    ? 'linear-gradient(180deg,'+hexA(th.dark.bg2,1)+','+hexA(th.dark.bg,1)+')'
    : 'linear-gradient(180deg,'+hexA(th.light.bg2,1)+','+hexA(th.light.bg,1)+')';
  var txCol = S.dark ? th.dark.tx : th.light.tx;
  var subCol = S.dark ? hexA(th.dark.tx2,.9) : hexA(th.light.tx2,.9);
  return '<div style="background:'+grad+';padding:18px 22px 20px;flex-shrink:0;position:relative">'
    + (backFn ? '<button onclick="'+backFn+'" style="background:none;border:none;color:'+hexA(txCol,.65)+';font-size:14px;cursor:pointer;padding:4px 0;margin:0 0 10px -2px;font-family:inherit;min-height:32px;display:flex;align-items:center;gap:6px;letter-spacing:-.005em">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>'
        + 'Retour</button>' : '')
    + '<p class="small-caps" style="color:'+hexA(g,.85)+';margin-bottom:8px;font-size:10.5px">'+esc(sub)+'</p>'
    + '<p class="display" style="font-size:30px;font-weight:300;color:'+txCol+';line-height:1.05;margin-bottom:0;letter-spacing:-.02em">'+esc(title)+'</p>'
    + '<div style="position:absolute;left:22px;right:22px;bottom:0;height:.5px;background:'+br()+';opacity:.6"></div>'
    + '</div>';
}

function pills(list, current, fn) {
  var g = gold();
  return '<div style="display:flex;gap:6px;padding:14px 18px 10px;overflow-x:auto;scrollbar-width:none;background:'+bg()+'">'
    + list.map(function(p) {
        var on = current === p[0];
        return '<button onclick="'+fn+"('"+p[0]+"')"
          + '" style="padding:7px 14px;border-radius:100px;border:.5px solid '
          + (on ? hexA(g,.45) : br())+';background:'+(on ? hexA(g,.10) : 'transparent')
          + ';color:'+(on ? g : tx2())+';font-size:13px;font-weight:'+(on?'600':'500')+';cursor:pointer;font-family:inherit;letter-spacing:-.005em;white-space:nowrap;flex-shrink:0;min-height:32px">'
          + esc(p[1]) + '</button>';
      }).join('')
    + '</div>';
}


// ─── NAVIGATION ─────────────────────────────────────────────────
// ─── Retour haptique (moments importants uniquement) ───
function haptic(type) {
  if (!window.navigator || !navigator.vibrate) return;
  if (S.profil && S.profil.noHaptic) return;
  var patterns = { light:[8], success:[12,40,12], soft:[6], celebrate:[10,30,10,30,18] };
  try { navigator.vibrate(patterns[type] || patterns.light); } catch(e) {}
}

// ─── Ordre des onglets pour deviner la direction de transition ───
var NAV_ORDER = ['accueil','coran','nur','apprendre','adorer','quotidien'];

// ─── Changement de thème / mode avec fondu de couleurs doux ───
function applyThemeFade() {
  var app = document.getElementById('APP') || document.body;
  app.classList.add('theme-fade');
  clearTimeout(window._tf);
  window._tf = setTimeout(function(){ app.classList.remove('theme-fade'); }, 450);
}
function setTheme(key) { S.profil.theme = key; haptic('light'); applyThemeFade(); save(); render(); }
function toggleDark() { S.dark = !S.dark; haptic('light'); applyThemeFade(); save(); render(); }

function N(page) {
  if (page !== 'niyya') S.muhasabaEdit = false;
  var isMainTab = NAV_ORDER.indexOf(TAB_MAP[page]||page) >= 0 && (TAB_MAP[page]||page) !== (TAB_MAP[S.page]||S.page);
  S.page = page;
  try { history.pushState({page:page}, ''); } catch(e) {}
  if (isMainTab) haptic('light'); // vibration légère au changement de section
  render();
  var pa = document.getElementById('PA');
  if (pa && pa.animate && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    pa.scrollTop = 0;
    pa.animate(
      [{opacity:0, transform:'translateY(10px)'},{opacity:1, transform:'none'}],
      {duration:340, easing:'cubic-bezier(.16,1,.3,1)'}
    );
  }
}

// Le bouton retour (Android / navigateur) remonte dans l'app au lieu de la fermer
window.addEventListener('popstate', function(e) {
  // Lecteur de sourate ouvert → retour à la liste
  if (S.page === 'coran' && S.quranSurah !== null) {
    S.quranSurah = null; S.quranVerses = []; S.ikOpen = null;
    if (S.quranAudio) { S.quranAudio.pause(); S.quranAudio = null; S.quranAudioVerse = null; }
    render(); return;
  }
  var st = e.state || {};
  S.page = st.page || 'accueil';
  render();
});


