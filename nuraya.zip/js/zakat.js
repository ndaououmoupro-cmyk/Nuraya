// ─── ZAKÂT ──────────────────────────────────────────────────────
var ZAKAT_DATA = {
  def: "La Zakat (الزكاة) est le 3ème pilier de l'Islam, rendue obligatoire la 2ème année de l'hégire. Obligation sur les biens dépassant le nissab pendant une année lunaire complète (hawl).",
  verset: {ar:"وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ", fr:"Et accomplissez la Salat et acquittez la Zakat.", ref:"Al-Baqara 2:110"},
  bienfaits: [
    {n:1, ti:"Amour et fraternité", tx:"L'aumône enlève la jalousie et rapproche les cœurs entre croyants."},
    {n:2, ti:"Purification de l'âme", tx:"At-Tawba 9:103 — Prélève de leurs biens une Sadaqa par laquelle tu les purifies. La Zakat purifie le cœur de l'avarice."},
    {n:3, ti:"Bénédiction des biens", tx:"Hadith : Celui qui s'acquitte de la zakat sur son argent — ce qu'il y avait dedans comme mal en est sorti."},
    {n:4, ti:"Éteindre la colère d'Allah", tx:"Hadith : L'aumône éteint les péchés comme l'eau éteint le feu. (At-Tirmidhi)"},
    {n:5, ti:"Protection dans la tombe", tx:"La Zakat se place à la gauche du croyant dans sa tombe — protection des tourments."},
    {n:6, ti:"Ombre du Trône", tx:"L'homme qui donne si discrètement que sa main gauche ne sait pas ce que la main droite a dépensé. (Bukhâri, Muslim)"},
    {n:7, ti:"Agrément d'Allah", tx:"Al-Baqara 2:271 — Si vous donnez discrètement aux indigents, c'est meilleur pour vous. Allah efface vos méfaits."},
  ],
  conditions: [
    {n:1, ti:"Être MUSULMAN", tx:"La zakat n'est obligatoire que pour les musulmans."},
    {n:2, ti:"Être LIBRE", tx:"Être maître de ses biens — libre de toute contrainte sur son patrimoine."},
    {n:3, ti:"Dépasser le NISSAB", tx:"Or : 85g | Argent : 595g. Les biens doivent appartenir totalement à la personne."},
    {n:4, ti:"HAWL complet", tx:"Les biens restent au-dessus du Nissab pendant 1 an lunaire complet. Taux : 2,5%"},
  ],
  nissab: "Or : 85g (taux 2,5%) · Argent : 595g (taux 2,5%) · Monnaie : seuil le plus petit entre les deux en euros. Récoltes : 10% (pluie) ou 5% (irrigation).",
  beneficiaires: [
    {ar:"الفقراء", nom:"Al-Fuqarâ' — Les PAUVRES", desc:"Ont moins de la moitié de ce qu'il leur faut pour vivre."},
    {ar:"المساكين", nom:"Al-Masâkîn — Les INDIGENTS", desc:"Ont plus de la moitié mais pas la totalité. Peuvent travailler mais restent dans le besoin."},
    {ar:"العاملين عليها", nom:"Al-'Âmilîn — Les TRAVAILLEURS de la Zakat", desc:"Collecteurs mandatés. Même riches, ils peuvent recevoir pour ce travail."},
    {ar:"المؤلفة قلوبهم", nom:"Al-Mu'allafa — CŒURS À GAGNER", desc:"Proches de l'Islam ou musulman dont la foi a baissé. Situation financière non prise en compte."},
    {ar:"في الرقاب", nom:"Fî r-Riqâb — AFFRANCHISSEMENT", desc:"Affranchissement des esclaves. Peu applicable aujourd'hui."},
    {ar:"الغارمين", nom:"Al-Ghârimîn — ENDETTÉS", desc:"Dette pour besoin personnel licite ou pour réconcilier des gens."},
    {ar:"في سبيل الله", nom:"Fî Sabîlillâh — SENTIER D'ALLAH", desc:"Combattants et étudiants en science religieuse à plein temps."},
    {ar:"ابن السبيل", nom:"Ibn as-Sabîl — VOYAGEUR EN DÉTRESSE", desc:"Voyageur bloqué sans ressources, même s'il est riche chez lui."},
  ],
};

function pageZakat() {
  var tabs = [['def','Définition'],['bienfaits','Bienfaits'],['conditions','Conditions'],['nissab','Nissab'],['bénéficiaires','Bénéficiaires'],['calcul','Calculateur']];
  var d = ZAKAT_DATA;
  var content = '';

  if (S.zakatTab === 'def') {
    content = card('<p style="font-size:19px;color:'+tx()+';line-height:1.8">'+esc(d.def)+'</p>', 'border-left:3px solid '+bxT())
      + '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:8px">'
        + '<p style="font-family:Fraunces,Georgia,serif;font-size:22px;color:'+gold()+';text-align:right;direction:rtl;line-height:2;margin-bottom:4px">'+d.verset.ar+'</p>'
        + '<p style="font-size:18px;color:'+tx()+';font-style:italic;margin-bottom:2px">'+esc(d.verset.fr)+'</p>'
        + '<p style="font-size:17px;color:'+bxT()+';font-weight:700">'+esc(d.verset.ref)+'</p>'
      + '</div>'
      + gcard('<p style="font-size:18px;color:'+gold()+';font-weight:600;margin-bottom:4px">Les 3 attitudes</p>'
        + [
          ['Dit que la zakat n\'est PAS obligatoire', '❌ MÉCRÉANT — sort de l\'Islam', '#E57373'],
          ['Croit obligatoire mais ne la sort PAS', '⚠️ Musulman pécheur — grand péché', '#FFB74D'],
          ['Croit ET s\'acquitte de la zakat', '✅ Musulman obéissant — récompense immense', '#81C784'],
        ].map(function(r) {
          return '<div style="padding:6px 0;border-bottom:1px solid rgba(191,174,85,.1)">'
            + '<p style="font-size:18px;color:'+tx2()+'">'+esc(r[0])+'</p>'
            + '<p style="font-size:18px;font-weight:600;color:'+r[2]+'">'+esc(r[1])+'</p>'
          + '</div>';
        }).join(''));
  } else if (S.zakatTab === 'bienfaits') {
    content = d.bienfaits.map(function(b) {
      return card('<div style="display:flex;gap:8px"><div style="width:20px;height:20px;border-radius:6px;background:'+bx()+';display:flex;align-items:center;justify-content:center;flex-shrink:0"><span style="font-size:18px;font-weight:700;color:#E2D38C">'+b.n+'</span></div><div><p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(b.ti)+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(b.tx)+'</p></div></div>');
    }).join('');
  } else if (S.zakatTab === 'conditions') {
    content = d.conditions.map(function(c) {
      return card('<div style="display:flex;gap:8px;align-items:flex-start"><div style="width:22px;height:22px;border-radius:7px;background:'+bx()+';display:flex;align-items:center;justify-content:center;flex-shrink:0"><span style="font-size:19px;font-weight:700;color:#E2D38C">'+c.n+'</span></div><div><p style="font-size:19px;font-weight:700;color:'+tx()+';margin-bottom:3px">'+esc(c.ti)+'</p><p style="font-size:18px;color:'+tx2()+';line-height:1.7">'+esc(c.tx)+'</p></div></div>');
    }).join('');
  } else if (S.zakatTab === 'nissab') {
    content = '<div style="display:flex;gap:7px;margin-bottom:8px">'
      + [['💛','Or 24 carats','85g','~9 010€'],['⚪','Argent','595g','~928€ ⭐']].map(function(r) {
          return '<div style="flex:1;background:'+bg2()+';border:1px solid '+br()+';border-radius:12px;padding:10px;text-align:center"><p style="font-size:26px;margin-bottom:4px">'+r[0]+'</p><p style="font-size:18px;font-weight:600;color:'+tx()+'">'+r[1]+'</p><p style="font-size:21px;font-weight:700;color:'+gold()+';margin:3px 0">'+r[2]+'</p><p style="font-size:17px;color:'+tx2()+'">'+esc(r[3])+'</p></div>';
        }).join('')
    + '</div>'
    + card('<p style="font-size:18px;color:'+tx()+';line-height:1.7">'+esc(d.nissab)+'</p>')
    + card('<p style="font-size:18px;font-weight:700;color:'+tx()+';margin-bottom:4px">Taux 2,5%</p><p style="font-size:18px;color:'+tx2()+'">Ex. : 6 000€ × 2,5% = <strong style="color:'+gold()+'">150€</strong> de zakat</p>');
  } else if (S.zakatTab === 'bénéficiaires') {
    content = '<div style="background:rgba(191,174,85,.07);border:1px solid rgba(191,174,85,.2);border-radius:12px;padding:10px 12px;margin-bottom:10px">'
      + '<p style="font-family:Fraunces,Georgia,serif;font-size:18px;color:'+gold()+';text-align:right;direction:rtl;line-height:1.9;margin-bottom:4px">إِنَّمَا الصَّدَقَاتُ لِلْفُقَرَاءِ وَالْمَسَاكِينِ وَالْعَامِلِينَ عَلَيْهَا وَالْمُؤَلَّفَةِ قُلُوبُهُمْ وَفِي الرِّقَابِ وَالْغَارِمِينَ وَفِي سَبِيلِ اللَّهِ وَابْنِ السَّبِيلِ</p>'
      + '<p style="font-size:17px;color:'+bxT()+';font-weight:700">At-Tawba 9:60</p>'
    + '</div>'
    + d.beneficiaires.map(function(b) {
        return card('<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px"><p style="font-size:19px;font-weight:600;color:'+tx()+'">'+esc(b.nom)+'</p><span style="font-family:Fraunces,Georgia,serif;font-size:19px;color:'+gold()+';direction:rtl">'+b.ar+'</span></div><p style="font-size:18px;color:'+tx2()+';line-height:1.65">'+esc(b.desc)+'</p>');
      }).join('');
  } else if (S.zakatTab === 'calcul') {
    content = card('<p style="font-size:19px;font-weight:600;color:'+tx()+';margin-bottom:8px">Valeur de tes biens zakâtables (€)</p>'
      + '<input type="number" id="ZAKAT_IN" placeholder="Ex: 5000" oninput="calcZakat(this.value)" style="width:100%;padding:10px;border-radius:10px;border:1.5px solid '+br()+';background:'+bg2()+';color:'+tx()+';font-size:22px;text-align:center;font-family:inherit;box-sizing:border-box;margin-bottom:8px">'
      + '<p style="font-size:18px;color:'+tx2()+';margin-bottom:8px">Nissab de référence (argent) : ~928€</p>'
      + '<div style="border-top:1px solid '+br()+';padding-top:10px">'
        + '<p style="font-size:18px;color:'+tx2()+';margin-bottom:4px">Zakât à payer</p>'
        + '<p id="ZAKAT_OUT" style="font-size:34px;font-weight:700;color:'+gold()+';text-align:center">0.00 €</p>'
      + '</div>');
  }

  return hdr('Zakât · الزَّكَاة', "3ème pilier de l'Islam · Fiqh Maliki")
    + pills(tabs, S.zakatTab, 'setZakatTab')
    + '<div style="padding:10px 14px">' + content + '</div>';
}

function setZakatTab(t) { S.zakatTab = t; render(); }

function calcZakat(val) {
  var v = parseFloat(val) || 0;
  var result = v >= 928 ? (v * 0.025).toFixed(2) + ' €' : '0.00 € (en dessous du nissab)';
  var el = document.getElementById('ZAKAT_OUT');
  if (el) el.textContent = result;
}


