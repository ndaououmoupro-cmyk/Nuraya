/* Nûraya service worker — offline app shell + cached API responses. */
const VERSION = 'nuraya-v1';
const SHELL = [
  "./",
  "index.html",
  "manifest.webmanifest",
  "icons/icon.svg",
  "css/styles.css",
  "js/data/adhkar-and-state.js",
  "js/themes.js",
  "js/render.js",
  "js/home.js",
  "js/data/quran-enriched.js",
  "js/quran-reader.js",
  "js/data/quran-text-part1.js",
  "js/data/quran-text-part2.js",
  "js/quran-page.js",
  "js/quran-list.js",
  "js/quran-download.js",
  "js/data/ilm.js",
  "js/niyya-muhasaba.js",
  "js/ilm-pages.js",
  "js/organisation.js",
  "js/sections.js",
  "js/sira-names-hajj.js",
  "js/ibada-dhikr-routine.js",
  "js/zakat.js",
  "js/profil.js",
  "js/security-and-features.js",
  "js/data/tarbiya.js",
  "js/planning.js",
  "js/ai-assistant.js",
  "js/prayer-times.js",
  "js/main.js"
];
const API_SWR = ['api.alquran.cloud', 'cdn.jsdelivr.net'];   // Quran text, tafsir: stable → serve cache, refresh in background
const API_NET = ['api.aladhan.com'];                         // prayer times: network first, cache as fallback

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  if (API_NET.includes(url.hostname)) { e.respondWith(networkFirst(req)); return; }
  if (API_SWR.includes(url.hostname) || url.hostname === 'fonts.gstatic.com' || url.hostname === 'fonts.googleapis.com') {
    e.respondWith(staleWhileRevalidate(req)); return;
  }
  if (url.origin === location.origin) e.respondWith(cacheFirst(req));
  // everything else (e.g. everyayah.com audio) goes straight to the network
});

async function put(req, res) {
  if (res && (res.ok || res.type === 'opaque')) (await caches.open(VERSION)).put(req, res.clone());
  return res;
}
async function cacheFirst(req) {
  return (await caches.match(req)) || put(req, await fetch(req));
}
async function networkFirst(req) {
  try { return await put(req, await fetch(req)); }
  catch (err) { const hit = await caches.match(req); if (hit) return hit; throw err; }
}
async function staleWhileRevalidate(req) {
  const hit = await caches.match(req);
  const refresh = fetch(req).then(res => put(req, res)).catch(() => hit);
  return hit || refresh;
}
