// Run with: npm test
// Loads the real app in jsdom (served over a local HTTP server) and checks data integrity and startup.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const vm = require('node:vm');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.join(__dirname, '..');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json' };
let server, win, errors = [];

before(async () => {
  server = http.createServer((req, res) => {
    const file = path.join(ROOT, req.url === '/' ? 'index.html' : decodeURIComponent(req.url.split('?')[0]));
    fs.readFile(file, (err, buf) => {
      if (err) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
      res.end(buf);
    });
  }).listen(0);
  await new Promise(r => server.once('listening', r));
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => { const m = String(e.message || e); if (!/fonts\.|Could not load link|ENOTFOUND|EAI_AGAIN|ECONNREFUSED/.test(m)) errors.push(m); });
  const dom = await JSDOM.fromURL(`http://localhost:${server.address().port}/index.html`,
    { runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc,
      // jsdom does not implement matchMedia; the app uses it to detect standalone (installed) mode
      beforeParse(w) { w.matchMedia = () => ({ matches: false, addEventListener() {}, addListener() {} }); } });
  win = dom.window;
  await new Promise(r => setTimeout(r, 1500));
});
after(() => { win.close(); server.close(); }); // win.close() stops the app's setInterval timers so the process can exit

const listJs = d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => path.join(d, f));
const allJs = [...listJs('js'), ...listJs('js/data')];

test('every JS file is syntactically valid', () => {
  for (const f of [...allJs, 'sw.js']) assert.doesNotThrow(() => new vm.Script(fs.readFileSync(path.join(ROOT, f), 'utf8')), f);
});

test('index.html loads every JS file once, with main.js last', () => {
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  const srcs = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]);
  assert.equal(new Set(srcs).size, srcs.length, 'duplicate script tag');
  assert.deepEqual([...srcs].sort(), [...allJs].sort(), 'script tags differ from files in js/');
  assert.equal(srcs.at(-1), 'js/main.js');
});

test('service worker precaches exactly the files the app needs', () => {
  const sw = fs.readFileSync(path.join(ROOT, 'sw.js'), 'utf8');
  const shell = JSON.parse(sw.match(/const SHELL = (\[[\s\S]*?\]);/)[1]);
  for (const f of shell) if (f !== './') assert.ok(fs.existsSync(path.join(ROOT, f)), `missing: ${f}`);
  for (const f of allJs) assert.ok(shell.includes(f), `not precached: ${f}`);
});

test('app starts without runtime errors and opens locked', () => {
  assert.deepEqual(errors, []);
  assert.equal(win.S.locked, true);
});

test('SURAHS lists 114 sequential surahs totalling 6236 verses', () => {
  assert.equal(win.SURAHS.length, 114);
  win.SURAHS.forEach((s, i) => assert.equal(s.n, i + 1));
  assert.equal(win.SURAHS.reduce((a, s) => a + s.v, 0), 6236);
});

test('embedded Quran excerpts are well formed (full text is fetched from the API)', () => {
  let embedded = 0;
  for (const s of win.SURAHS) {
    const verses = win.QURAN_LOCAL[s.n];
    assert.ok(Array.isArray(verses) && verses.length > 0, `surah ${s.n} has no embedded verses`);
    assert.ok(verses.length <= s.v, `surah ${s.n}: ${verses.length} embedded verses > ${s.v}`);
    verses.forEach((v, i) => {
      assert.ok(v.n >= 1 && v.n <= s.v, `surah ${s.n}: verse number ${v.n} out of range`);
      if (i > 0) assert.ok(v.n > verses[i - 1].n, `surah ${s.n}: verses not in increasing order at ${v.n}`);
      assert.ok(v.ar && v.ar.trim() && v.fr && v.fr.trim(), `surah ${s.n}:${v.n} empty text`);
    });
    embedded += verses.length;
  }
  console.log(`# embedded verses: ${embedded} / 6236`);
});

test('99 names of Allah are complete and unique', () => {
  assert.equal(win.ASMA.length, 99);
  assert.equal(new Set(win.ASMA.map(a => a.n)).size, 99);
  for (const a of win.ASMA) for (const k of ['ar', 'fr', 'tr', 'med', 'ref']) assert.ok(a[k], `name ${a.n} missing ${k}`);
});

test('morning and evening adhkar have all required fields', () => {
  for (const list of [win.ADHKAR_SABAH, win.ADHKAR_MASAA]) {
    assert.ok(list.length > 0);
    for (const d of list) for (const k of ['titre', 'ar', 'fr', 'ref', 'rep']) assert.ok(d[k], `${d.titre || '?'} missing ${k}`);
  }
});

test('reciters and calculation methods are well formed', () => {
  assert.equal(new Set(win.RECITERS.map(r => r.id)).size, win.RECITERS.length);
  win.SALAT_METHODS.forEach(([id, label]) => { assert.equal(typeof id, 'number'); assert.ok(label); });
});

test('esc() neutralises HTML before it is injected into templates', () => {
  assert.equal(win.esc('<img src=x onerror="a()">'), '&lt;img src=x onerror=&quot;a()&quot;&gt;');
});
